﻿using System;

namespace PalHaxv1_1
{
	// Token: 0x02000011 RID: 17
	public static class MenuFeaturesButtonClicks
	{
		// Token: 0x06000246 RID: 582 RVA: 0x00010189 File Offset: 0x0000E389
		public static void GiveTechPointsButton_Click(object sender, EventArgs e)
		{
			Offsets.TechnologyPoint = 1000;
			Offsets.bossTechnologyPoint = 1000;
			Offsets.SPUnusedStatusPoints = 1000;
		}

		// Token: 0x06000247 RID: 583 RVA: 0x000101A9 File Offset: 0x0000E3A9
		public static void MaxStomachButton_Click(object sender, EventArgs e)
		{
			Offsets.MaxStomach = 100f;
			Offsets.MaxStomachValue = 100f;
		}

		// Token: 0x06000248 RID: 584 RVA: 0x000101BF File Offset: 0x0000E3BF
		public static void MaxLevelButton_Click(object sender, EventArgs e)
		{
			Offsets.SPLevel = 100;
			Offsets.SPRank = 100;
		}

		// Token: 0x06000249 RID: 585 RVA: 0x000101D0 File Offset: 0x0000E3D0
		public static void ModWeaponButton_Click(object sender, EventArgs e)
		{
			Offsets.Durability = 214748370f;
			Offsets.MaxDurability = 214748370f;
			Offsets.OldDurability = 214748370f;
			Offsets.RemainingBullets = 214748364;
			Offsets.StaticDefenseValue = 214748364;
			Offsets.StaticAttackValue = 214748364;
			Offsets.MagazineSize = 214748370f;
			Offsets.StaticDurability = 214748370f;
			Offsets.StaticWeight = 0f;
			Offsets.StaticRarity = 5;
		}

		// Token: 0x0600024A RID: 586 RVA: 0x0001023D File Offset: 0x0000E43D
		public static void GiveGoldButton_Click(object sender, EventArgs e)
		{
			Offsets.ItemIdStaticId3 = Offsets.GoldID;
			Offsets.StackCount3 = 999999;
		}

		// Token: 0x0600024B RID: 587 RVA: 0x00010253 File Offset: 0x0000E453
		public static void BaseResetBuildRange_Click(object sender, EventArgs e)
		{
			Offsets.BaseCampAreaRange = 3500f;
		}

		// Token: 0x0600024C RID: 588 RVA: 0x0001025F File Offset: 0x0000E45F
		public static void BaseInfBuildRange_Click(object sender, EventArgs e)
		{
			Offsets.BaseCampAreaRange = 2.1474836E+09f;
		}

		// Token: 0x0600024D RID: 589 RVA: 0x0001026B File Offset: 0x0000E46B
		public static void GiveWoodButton_Click(object sender, EventArgs e)
		{
			Offsets.ItemIdStaticId1 = Offsets.WoodID;
			Offsets.StackCount1 = 9999;
		}

		// Token: 0x0600024E RID: 590 RVA: 0x00010281 File Offset: 0x0000E481
		public static void GiveSoulsButton_Click(object sender, EventArgs e)
		{
			Offsets.ItemIdStaticId2 = Offsets.PalSoulID;
			Offsets.StackCount2 = 9999;
		}

		// Token: 0x0600024F RID: 591 RVA: 0x00010297 File Offset: 0x0000E497
		public static void HealPlayerButton_Click(object sender, EventArgs e)
		{
			Offsets.PlayerHealth = Offsets.PlayerMaxHealth;
		}

		// Token: 0x06000250 RID: 592 RVA: 0x000102A3 File Offset: 0x0000E4A3
		public static void PalMaxLevelButton_Click(object sender, EventArgs e)
		{
			Offsets.PalSPLevel = 999;
			Offsets.PalSPRank = 999;
		}

		// Token: 0x06000251 RID: 593 RVA: 0x000102B9 File Offset: 0x0000E4B9
		public static void PalMaleButton_Click(object sender, EventArgs e)
		{
			Offsets.PalSPGender = 1;
		}

		// Token: 0x06000252 RID: 594 RVA: 0x000102C1 File Offset: 0x0000E4C1
		public static void PalFemaleButton_Click(object sender, EventArgs e)
		{
			Offsets.PalSPGender = 2;
		}

		// Token: 0x06000253 RID: 595 RVA: 0x000102C9 File Offset: 0x0000E4C9
		public static void SetRarePalButton_Click(object sender, EventArgs e)
		{
			Offsets.IsRarePal = 1;
		}

		// Token: 0x06000254 RID: 596 RVA: 0x000102D1 File Offset: 0x0000E4D1
		public static void PalMaxHPButton_Click(object sender, EventArgs e)
		{
			Offsets.SPMaxHPValue = 2147483646;
			Offsets.SPMHP = 2147483646;
		}

		// Token: 0x06000255 RID: 597 RVA: 0x000102E7 File Offset: 0x0000E4E7
		public static void PalMaxStomachButton_Click(object sender, EventArgs e)
		{
			Offsets.PalxMaxStomach = 100f;
			Offsets.PalxMaxStomachValue = 100f;
			Offsets.SPHungerType = 0;
			Offsets.StomachDecreaceperSecondMonster = 0f;
		}

		// Token: 0x06000256 RID: 598 RVA: 0x0001030D File Offset: 0x0000E50D
		public static void PalSanityButton_Click(object sender, EventArgs e)
		{
			Offsets.SPSanityValue = 100f;
		}
	}
}
