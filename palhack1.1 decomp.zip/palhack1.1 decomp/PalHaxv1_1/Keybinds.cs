﻿using System;

namespace PalHaxv1_1
{
	// Token: 0x0200000F RID: 15
	public class Keybinds
	{
		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000238 RID: 568 RVA: 0x00010104 File Offset: 0x0000E304
		// (set) Token: 0x06000239 RID: 569 RVA: 0x0001010C File Offset: 0x0000E30C
		public string ExitCheat { get; set; }

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x0600023A RID: 570 RVA: 0x00010115 File Offset: 0x0000E315
		// (set) Token: 0x0600023B RID: 571 RVA: 0x0001011D File Offset: 0x0000E31D
		public string ShowMenu { get; set; }

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x0600023C RID: 572 RVA: 0x00010126 File Offset: 0x0000E326
		// (set) Token: 0x0600023D RID: 573 RVA: 0x0001012E File Offset: 0x0000E32E
		public string SpoofPosition { get; set; }

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x0600023E RID: 574 RVA: 0x00010137 File Offset: 0x0000E337
		// (set) Token: 0x0600023F RID: 575 RVA: 0x0001013F File Offset: 0x0000E33F
		public string Flymode { get; set; }

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x06000240 RID: 576 RVA: 0x00010148 File Offset: 0x0000E348
		// (set) Token: 0x06000241 RID: 577 RVA: 0x00010150 File Offset: 0x0000E350
		public string Speedhack { get; set; }

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x06000242 RID: 578 RVA: 0x00010159 File Offset: 0x0000E359
		// (set) Token: 0x06000243 RID: 579 RVA: 0x00010161 File Offset: 0x0000E361
		public string SuperJump { get; set; }
	}
}
