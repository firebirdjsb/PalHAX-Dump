﻿using System;

namespace PalHaxv1_1
{
	// Token: 0x02000008 RID: 8
	internal static class Offsets
	{
		// Token: 0x17000008 RID: 8
		// (get) Token: 0x060000B2 RID: 178 RVA: 0x0000CF58 File Offset: 0x0000B158
		// (set) Token: 0x060000B3 RID: 179 RVA: 0x0000CF69 File Offset: 0x0000B169
		public static float PalEggTempHatchRate1
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "4", value);
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x060000B4 RID: 180 RVA: 0x0000CF7B File Offset: 0x0000B17B
		// (set) Token: 0x060000B5 RID: 181 RVA: 0x0000CF8C File Offset: 0x0000B18C
		public static float PalEggTempHatchRate2
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "14");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "14", value);
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x060000B6 RID: 182 RVA: 0x0000CF9E File Offset: 0x0000B19E
		// (set) Token: 0x060000B7 RID: 183 RVA: 0x0000CFAF File Offset: 0x0000B1AF
		public static float PalEggTempHatchRate3
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "24");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "24", value);
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x060000B8 RID: 184 RVA: 0x0000CFC1 File Offset: 0x0000B1C1
		// (set) Token: 0x060000B9 RID: 185 RVA: 0x0000CFD2 File Offset: 0x0000B1D2
		public static float PalEggTempHatchRate4
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "34");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "34", value);
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x060000BA RID: 186 RVA: 0x0000CFE4 File Offset: 0x0000B1E4
		// (set) Token: 0x060000BB RID: 187 RVA: 0x0000CFF5 File Offset: 0x0000B1F5
		public static float PalEggTempHatchRate5
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "44");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "44", value);
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x060000BC RID: 188 RVA: 0x0000D007 File Offset: 0x0000B207
		// (set) Token: 0x060000BD RID: 189 RVA: 0x0000D018 File Offset: 0x0000B218
		public static float PalEggTempHatchRate6
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "54");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "54", value);
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x060000BE RID: 190 RVA: 0x0000D02A File Offset: 0x0000B22A
		// (set) Token: 0x060000BF RID: 191 RVA: 0x0000D03B File Offset: 0x0000B23B
		public static float PalEggTempHatchRate7
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "64");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "64", value);
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x060000C0 RID: 192 RVA: 0x0000D04D File Offset: 0x0000B24D
		// (set) Token: 0x060000C1 RID: 193 RVA: 0x0000D05E File Offset: 0x0000B25E
		public static float PalEggTempHatchRate8
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "74");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "74", value);
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x060000C2 RID: 194 RVA: 0x0000D070 File Offset: 0x0000B270
		// (set) Token: 0x060000C3 RID: 195 RVA: 0x0000D081 File Offset: 0x0000B281
		public static float PalEggTempHatchRate9
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "84");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggHatchingSpeedRateByTemperature.Address, "84", value);
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x060000C4 RID: 196 RVA: 0x0000D093 File Offset: 0x0000B293
		// (set) Token: 0x060000C5 RID: 197 RVA: 0x0000D0A4 File Offset: 0x0000B2A4
		public static float HatchingSpeedDivisionRate5
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggRankInfoArray.Address, "38");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggRankInfoArray.Address, "38", value);
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x060000C6 RID: 198 RVA: 0x0000D0B6 File Offset: 0x0000B2B6
		// (set) Token: 0x060000C7 RID: 199 RVA: 0x0000D0C7 File Offset: 0x0000B2C7
		public static float EggScale5
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggRankInfoArray.Address, "34");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggRankInfoArray.Address, "34", value);
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x060000C8 RID: 200 RVA: 0x0000D0D9 File Offset: 0x0000B2D9
		// (set) Token: 0x060000C9 RID: 201 RVA: 0x0000D0EA File Offset: 0x0000B2EA
		public static int PalRarity5
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalEggRankInfoArray.Address, "30");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalEggRankInfoArray.Address, "30", value);
			}
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x060000CA RID: 202 RVA: 0x0000D0FC File Offset: 0x0000B2FC
		// (set) Token: 0x060000CB RID: 203 RVA: 0x0000D10D File Offset: 0x0000B30D
		public static float HatchingSpeedDivisionRate4
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggRankInfoArray.Address, "2C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggRankInfoArray.Address, "2C", value);
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x060000CC RID: 204 RVA: 0x0000D11F File Offset: 0x0000B31F
		// (set) Token: 0x060000CD RID: 205 RVA: 0x0000D130 File Offset: 0x0000B330
		public static float EggScale4
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggRankInfoArray.Address, "28");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggRankInfoArray.Address, "28", value);
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x060000CE RID: 206 RVA: 0x0000D142 File Offset: 0x0000B342
		// (set) Token: 0x060000CF RID: 207 RVA: 0x0000D153 File Offset: 0x0000B353
		public static int PalRarity4
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalEggRankInfoArray.Address, "24");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalEggRankInfoArray.Address, "24", value);
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x060000D0 RID: 208 RVA: 0x0000D165 File Offset: 0x0000B365
		// (set) Token: 0x060000D1 RID: 209 RVA: 0x0000D176 File Offset: 0x0000B376
		public static float HatchingSpeedDivisionRate3
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggRankInfoArray.Address, "20");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggRankInfoArray.Address, "20", value);
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x060000D2 RID: 210 RVA: 0x0000D188 File Offset: 0x0000B388
		// (set) Token: 0x060000D3 RID: 211 RVA: 0x0000D199 File Offset: 0x0000B399
		public static float EggScale3
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggRankInfoArray.Address, "1C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggRankInfoArray.Address, "1C", value);
			}
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x060000D4 RID: 212 RVA: 0x0000D1AB File Offset: 0x0000B3AB
		// (set) Token: 0x060000D5 RID: 213 RVA: 0x0000D1BC File Offset: 0x0000B3BC
		public static int PalRarity3
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalEggRankInfoArray.Address, "18");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalEggRankInfoArray.Address, "18", value);
			}
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x060000D6 RID: 214 RVA: 0x0000D1CE File Offset: 0x0000B3CE
		// (set) Token: 0x060000D7 RID: 215 RVA: 0x0000D1DF File Offset: 0x0000B3DF
		public static float HatchingSpeedDivisionRate2
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggRankInfoArray.Address, "14");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggRankInfoArray.Address, "14", value);
			}
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x060000D8 RID: 216 RVA: 0x0000D1F1 File Offset: 0x0000B3F1
		// (set) Token: 0x060000D9 RID: 217 RVA: 0x0000D202 File Offset: 0x0000B402
		public static float EggScale2
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggRankInfoArray.Address, "10");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggRankInfoArray.Address, "10", value);
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060000DA RID: 218 RVA: 0x0000D214 File Offset: 0x0000B414
		// (set) Token: 0x060000DB RID: 219 RVA: 0x0000D225 File Offset: 0x0000B425
		public static int PalRarity2
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalEggRankInfoArray.Address, "C");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalEggRankInfoArray.Address, "C", value);
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060000DC RID: 220 RVA: 0x0000D237 File Offset: 0x0000B437
		// (set) Token: 0x060000DD RID: 221 RVA: 0x0000D248 File Offset: 0x0000B448
		public static float HatchingSpeedDivisionRate1
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggRankInfoArray.Address, "8");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggRankInfoArray.Address, "8", value);
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060000DE RID: 222 RVA: 0x0000D25A File Offset: 0x0000B45A
		// (set) Token: 0x060000DF RID: 223 RVA: 0x0000D26B File Offset: 0x0000B46B
		public static float EggScale1
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalEggRankInfoArray.Address, "4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalEggRankInfoArray.Address, "4", value);
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000E0 RID: 224 RVA: 0x0000D27D File Offset: 0x0000B47D
		// (set) Token: 0x060000E1 RID: 225 RVA: 0x0000D28E File Offset: 0x0000B48E
		public static int PalRarity1
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalEggRankInfoArray.Address, "0");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalEggRankInfoArray.Address, "0", value);
			}
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060000E2 RID: 226 RVA: 0x0000D2A0 File Offset: 0x0000B4A0
		// (set) Token: 0x060000E3 RID: 227 RVA: 0x0000D2B1 File Offset: 0x0000B4B1
		public static int DefaultEi
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.ItemIDManager.Address, "38");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.ItemIDManager.Address, "38", value);
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060000E4 RID: 228 RVA: 0x0000D2C3 File Offset: 0x0000B4C3
		// (set) Token: 0x060000E5 RID: 229 RVA: 0x0000D2D4 File Offset: 0x0000B4D4
		public static int PlayerHealth
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalIndividiualParameter.Address, "2E8");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalIndividiualParameter.Address, "2E8", value);
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060000E6 RID: 230 RVA: 0x0000D2E6 File Offset: 0x0000B4E6
		// (set) Token: 0x060000E7 RID: 231 RVA: 0x0000D2F7 File Offset: 0x0000B4F7
		public static int PlayerMaxHealth
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalIndividiualParameter.Address, "358");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalIndividiualParameter.Address, "358", value);
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060000E8 RID: 232 RVA: 0x0000D309 File Offset: 0x0000B509
		// (set) Token: 0x060000E9 RID: 233 RVA: 0x0000D31A File Offset: 0x0000B51A
		public static int ItemIdStaticId1
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PlayerInventoryItemSlot1.Address, "DC");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PlayerInventoryItemSlot1.Address, "DC", value);
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060000EA RID: 234 RVA: 0x0000D32C File Offset: 0x0000B52C
		// (set) Token: 0x060000EB RID: 235 RVA: 0x0000D33D File Offset: 0x0000B53D
		public static int ItemIdStaticId2
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PlayerInventoryItemSlot2.Address, "DC");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PlayerInventoryItemSlot2.Address, "DC", value);
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060000EC RID: 236 RVA: 0x0000D34F File Offset: 0x0000B54F
		// (set) Token: 0x060000ED RID: 237 RVA: 0x0000D360 File Offset: 0x0000B560
		public static int ItemIdStaticId3
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PlayerInventoryItemSlot3.Address, "DC");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PlayerInventoryItemSlot3.Address, "DC", value);
			}
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060000EE RID: 238 RVA: 0x0000D372 File Offset: 0x0000B572
		// (set) Token: 0x060000EF RID: 239 RVA: 0x0000D383 File Offset: 0x0000B583
		public static int ItemIdStaticId4
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PlayerInventoryItemSlot4.Address, "DC");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PlayerInventoryItemSlot4.Address, "DC", value);
			}
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060000F0 RID: 240 RVA: 0x0000D395 File Offset: 0x0000B595
		// (set) Token: 0x060000F1 RID: 241 RVA: 0x0000D3A6 File Offset: 0x0000B5A6
		public static int WoodID
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.ItemIDManager.Address, "30");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.ItemIDManager.Address, "30", value);
			}
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060000F2 RID: 242 RVA: 0x0000D3B8 File Offset: 0x0000B5B8
		// (set) Token: 0x060000F3 RID: 243 RVA: 0x0000D3C9 File Offset: 0x0000B5C9
		public static int PalSoulID
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.ItemIDManager.Address, "40");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.ItemIDManager.Address, "40", value);
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060000F4 RID: 244 RVA: 0x0000D3DB File Offset: 0x0000B5DB
		// (set) Token: 0x060000F5 RID: 245 RVA: 0x0000D3EC File Offset: 0x0000B5EC
		public static int GoldID
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.ItemIDManager.Address, "48");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.ItemIDManager.Address, "48", value);
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060000F6 RID: 246 RVA: 0x0000D3FE File Offset: 0x0000B5FE
		// (set) Token: 0x060000F7 RID: 247 RVA: 0x0000D40F File Offset: 0x0000B60F
		public static int StaticRarity
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalownItemDataStaticData.Address, "68");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalownItemDataStaticData.Address, "68", value);
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060000F8 RID: 248 RVA: 0x0000D421 File Offset: 0x0000B621
		// (set) Token: 0x060000F9 RID: 249 RVA: 0x0000D432 File Offset: 0x0000B632
		public static int StaticDefenseValue
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalownItemDataStaticData.Address, "160");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalownItemDataStaticData.Address, "160", value);
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x060000FA RID: 250 RVA: 0x0000D444 File Offset: 0x0000B644
		// (set) Token: 0x060000FB RID: 251 RVA: 0x0000D455 File Offset: 0x0000B655
		public static int StaticAttackValue
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalownItemDataStaticData.Address, "160");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalownItemDataStaticData.Address, "160", value);
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x060000FC RID: 252 RVA: 0x0000D467 File Offset: 0x0000B667
		// (set) Token: 0x060000FD RID: 253 RVA: 0x0000D478 File Offset: 0x0000B678
		public static float MagazineSize
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalownItemDataStaticData.Address, "158");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalownItemDataStaticData.Address, "158", value);
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x060000FE RID: 254 RVA: 0x0000D48A File Offset: 0x0000B68A
		// (set) Token: 0x060000FF RID: 255 RVA: 0x0000D49B File Offset: 0x0000B69B
		public static float StaticDurability
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalownItemDataStaticData.Address, "120");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalownItemDataStaticData.Address, "120", value);
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000100 RID: 256 RVA: 0x0000D4AD File Offset: 0x0000B6AD
		// (set) Token: 0x06000101 RID: 257 RVA: 0x0000D4BE File Offset: 0x0000B6BE
		public static float StaticWeight
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalownItemDataStaticData.Address, "11C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalownItemDataStaticData.Address, "11C", value);
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000102 RID: 258 RVA: 0x0000D4D0 File Offset: 0x0000B6D0
		// (set) Token: 0x06000103 RID: 259 RVA: 0x0000D4E1 File Offset: 0x0000B6E1
		public static float BaseCampAreaRange
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.BaseCamp.Address, "E0");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.BaseCamp.Address, "E0", value);
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000104 RID: 260 RVA: 0x0000D4F3 File Offset: 0x0000B6F3
		// (set) Token: 0x06000105 RID: 261 RVA: 0x0000D504 File Offset: 0x0000B704
		public static float InstallDinstanceFromOwner
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.BuilderComponent.Address, "D0");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.BuilderComponent.Address, "D0", value);
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000106 RID: 262 RVA: 0x0000D516 File Offset: 0x0000B716
		// (set) Token: 0x06000107 RID: 263 RVA: 0x0000D527 File Offset: 0x0000B727
		public static byte PassiveSkillSize
		{
			get
			{
				return PropertyAccessors.ReadByteProperty(Addresses.OtomoPalIndividualParameter.Address, "310");
			}
			set
			{
				PropertyAccessors.WriteByteProperty(Addresses.OtomoPalIndividualParameter.Address, "310", value);
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06000108 RID: 264 RVA: 0x0000D539 File Offset: 0x0000B739
		// (set) Token: 0x06000109 RID: 265 RVA: 0x0000D54A File Offset: 0x0000B74A
		public static byte PassiveSkillSizeMax
		{
			get
			{
				return PropertyAccessors.ReadByteProperty(Addresses.OtomoPalIndividualParameter.Address, "314");
			}
			set
			{
				PropertyAccessors.WriteByteProperty(Addresses.OtomoPalIndividualParameter.Address, "314", value);
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x0600010A RID: 266 RVA: 0x0000D55C File Offset: 0x0000B75C
		// (set) Token: 0x0600010B RID: 267 RVA: 0x0000D56D File Offset: 0x0000B76D
		public static uint IDInstanceIdA
		{
			get
			{
				return PropertyAccessors.ReadUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "48");
			}
			set
			{
				PropertyAccessors.WriteUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "48", value);
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x0600010C RID: 268 RVA: 0x0000D57F File Offset: 0x0000B77F
		// (set) Token: 0x0600010D RID: 269 RVA: 0x0000D590 File Offset: 0x0000B790
		public static uint IDInstanceIdB
		{
			get
			{
				return PropertyAccessors.ReadUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "4C");
			}
			set
			{
				PropertyAccessors.WriteUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "4C", value);
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x0600010E RID: 270 RVA: 0x0000D5A2 File Offset: 0x0000B7A2
		// (set) Token: 0x0600010F RID: 271 RVA: 0x0000D5B3 File Offset: 0x0000B7B3
		public static uint IDInstanceIdC
		{
			get
			{
				return PropertyAccessors.ReadUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "50");
			}
			set
			{
				PropertyAccessors.WriteUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "50", value);
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000110 RID: 272 RVA: 0x0000D5C5 File Offset: 0x0000B7C5
		// (set) Token: 0x06000111 RID: 273 RVA: 0x0000D5D6 File Offset: 0x0000B7D6
		public static uint IDInstanceIdD
		{
			get
			{
				return PropertyAccessors.ReadUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "54");
			}
			set
			{
				PropertyAccessors.WriteUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "54", value);
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000112 RID: 274 RVA: 0x0000D5E8 File Offset: 0x0000B7E8
		// (set) Token: 0x06000113 RID: 275 RVA: 0x0000D5F9 File Offset: 0x0000B7F9
		public static int EquipWazaAttackSlot1
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.SaveParameterEquipWaza.Address, "0");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.SaveParameterEquipWaza.Address, "0", value);
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06000114 RID: 276 RVA: 0x0000D60B File Offset: 0x0000B80B
		// (set) Token: 0x06000115 RID: 277 RVA: 0x0000D61C File Offset: 0x0000B81C
		public static int EquipWazaAttackSlot2
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.SaveParameterEquipWaza.Address, "1");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.SaveParameterEquipWaza.Address, "1", value);
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000116 RID: 278 RVA: 0x0000D62E File Offset: 0x0000B82E
		// (set) Token: 0x06000117 RID: 279 RVA: 0x0000D63F File Offset: 0x0000B83F
		public static int EquipWazaAttackSlot3
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.SaveParameterEquipWaza.Address, "2");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.SaveParameterEquipWaza.Address, "2", value);
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000118 RID: 280 RVA: 0x0000D651 File Offset: 0x0000B851
		// (set) Token: 0x06000119 RID: 281 RVA: 0x0000D662 File Offset: 0x0000B862
		public static float SPSanityValue
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.OtomoPalIndividualParameter.Address, "39C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.OtomoPalIndividualParameter.Address, "39C", value);
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x0600011A RID: 282 RVA: 0x0000D674 File Offset: 0x0000B874
		// (set) Token: 0x0600011B RID: 283 RVA: 0x0000D685 File Offset: 0x0000B885
		public static int SPHungerType
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.OtomoPalIndividualParameter.Address, "398");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.OtomoPalIndividualParameter.Address, "398", value);
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x0600011C RID: 284 RVA: 0x0000D697 File Offset: 0x0000B897
		// (set) Token: 0x0600011D RID: 285 RVA: 0x0000D6A8 File Offset: 0x0000B8A8
		public static float PalxMaxStomachValue
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.OtomoPalIndividualParameter.Address, "3DC");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.OtomoPalIndividualParameter.Address, "3DC", value);
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x0600011E RID: 286 RVA: 0x0000D6BA File Offset: 0x0000B8BA
		// (set) Token: 0x0600011F RID: 287 RVA: 0x0000D6CB File Offset: 0x0000B8CB
		public static float PalxMaxStomach
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.OtomoPalIndividualParameter.Address, "300");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.OtomoPalIndividualParameter.Address, "300", value);
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000120 RID: 288 RVA: 0x0000D6DD File Offset: 0x0000B8DD
		// (set) Token: 0x06000121 RID: 289 RVA: 0x0000D6EE File Offset: 0x0000B8EE
		public static int SPMHP
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.OtomoPalIndividualParameter.Address, "2E8");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.OtomoPalIndividualParameter.Address, "2E8", value);
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000122 RID: 290 RVA: 0x0000D700 File Offset: 0x0000B900
		// (set) Token: 0x06000123 RID: 291 RVA: 0x0000D711 File Offset: 0x0000B911
		public static int SPMaxHPValue
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.OtomoPalIndividualParameter.Address, "358");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.OtomoPalIndividualParameter.Address, "358", value);
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000124 RID: 292 RVA: 0x0000D723 File Offset: 0x0000B923
		// (set) Token: 0x06000125 RID: 293 RVA: 0x0000D734 File Offset: 0x0000B934
		public static int IsRarePal
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.OtomoPalIndividualParameter.Address, "2C0");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.OtomoPalIndividualParameter.Address, "2C0", value);
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000126 RID: 294 RVA: 0x0000D746 File Offset: 0x0000B946
		// (set) Token: 0x06000127 RID: 295 RVA: 0x0000D757 File Offset: 0x0000B957
		public static int SPSupport
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.OtomoPalIndividualParameter.Address, "360");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.OtomoPalIndividualParameter.Address, "360", value);
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000128 RID: 296 RVA: 0x0000D769 File Offset: 0x0000B969
		// (set) Token: 0x06000129 RID: 297 RVA: 0x0000D77A File Offset: 0x0000B97A
		public static int SPRankAttack
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.OtomoPalIndividualParameter.Address, "29C");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.OtomoPalIndividualParameter.Address, "29C", value);
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x0600012A RID: 298 RVA: 0x0000D78C File Offset: 0x0000B98C
		// (set) Token: 0x0600012B RID: 299 RVA: 0x0000D79D File Offset: 0x0000B99D
		public static int SPRankDefence
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.OtomoPalIndividualParameter.Address, "2A0");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.OtomoPalIndividualParameter.Address, "2A0", value);
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x0600012C RID: 300 RVA: 0x0000D7AF File Offset: 0x0000B9AF
		// (set) Token: 0x0600012D RID: 301 RVA: 0x0000D7C0 File Offset: 0x0000B9C0
		public static int SPRankCraftSpeed
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.OtomoPalIndividualParameter.Address, "2A4");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.OtomoPalIndividualParameter.Address, "2A4", value);
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x0600012E RID: 302 RVA: 0x0000D7D2 File Offset: 0x0000B9D2
		// (set) Token: 0x0600012F RID: 303 RVA: 0x0000D7E3 File Offset: 0x0000B9E3
		public static int PalSPGender
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.OtomoPalIndividualParameter.Address, "280");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.OtomoPalIndividualParameter.Address, "280", value);
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000130 RID: 304 RVA: 0x0000D7F5 File Offset: 0x0000B9F5
		// (set) Token: 0x06000131 RID: 305 RVA: 0x0000D806 File Offset: 0x0000BA06
		public static int PalSPLevel
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.OtomoPalIndividualParameter.Address, "290");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.OtomoPalIndividualParameter.Address, "290", value);
			}
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06000132 RID: 306 RVA: 0x0000D818 File Offset: 0x0000BA18
		// (set) Token: 0x06000133 RID: 307 RVA: 0x0000D829 File Offset: 0x0000BA29
		public static int PalSPRank
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.OtomoPalIndividualParameter.Address, "294");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.OtomoPalIndividualParameter.Address, "294", value);
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x06000134 RID: 308 RVA: 0x0000D83B File Offset: 0x0000BA3B
		// (set) Token: 0x06000135 RID: 309 RVA: 0x0000D84C File Offset: 0x0000BA4C
		public static int DamageValueMinMapObject
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "1E0");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "1E0", value);
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06000136 RID: 310 RVA: 0x0000D85E File Offset: 0x0000BA5E
		// (set) Token: 0x06000137 RID: 311 RVA: 0x0000D86F File Offset: 0x0000BA6F
		public static int BossOrRarePal_TalentMin
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "60");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "60", value);
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06000138 RID: 312 RVA: 0x0000D881 File Offset: 0x0000BA81
		// (set) Token: 0x06000139 RID: 313 RVA: 0x0000D892 File Offset: 0x0000BA92
		public static int CharacterMaxRank
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "28");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "28", value);
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x0600013A RID: 314 RVA: 0x0000D8A4 File Offset: 0x0000BAA4
		// (set) Token: 0x0600013B RID: 315 RVA: 0x0000D8B5 File Offset: 0x0000BAB5
		public static float RarePal_LevelMultiply
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "5C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "5C", value);
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x0600013C RID: 316 RVA: 0x0000D8C7 File Offset: 0x0000BAC7
		// (set) Token: 0x0600013D RID: 317 RVA: 0x0000D8D8 File Offset: 0x0000BAD8
		public static float CaptureJudgeRate1
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.CaptureJudgeRateArray.Address, "0");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.CaptureJudgeRateArray.Address, "0", value);
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x0600013E RID: 318 RVA: 0x0000D8EA File Offset: 0x0000BAEA
		// (set) Token: 0x0600013F RID: 319 RVA: 0x0000D8FB File Offset: 0x0000BAFB
		public static float CaptureJudgeRate2
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.CaptureJudgeRateArray.Address, "4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.CaptureJudgeRateArray.Address, "4", value);
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06000140 RID: 320 RVA: 0x0000D90D File Offset: 0x0000BB0D
		// (set) Token: 0x06000141 RID: 321 RVA: 0x0000D91E File Offset: 0x0000BB1E
		public static float CaptureJudgeRate3
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.CaptureJudgeRateArray.Address, "8");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.CaptureJudgeRateArray.Address, "8", value);
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x06000142 RID: 322 RVA: 0x0000D930 File Offset: 0x0000BB30
		// (set) Token: 0x06000143 RID: 323 RVA: 0x0000D941 File Offset: 0x0000BB41
		public static float RarePalAppearanceProbability
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "58");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "58", value);
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x06000144 RID: 324 RVA: 0x0000D953 File Offset: 0x0000BB53
		// (set) Token: 0x06000145 RID: 325 RVA: 0x0000D964 File Offset: 0x0000BB64
		public static int MapObjectDestroyProceedExp
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "3AC");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "3AC", value);
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000146 RID: 326 RVA: 0x0000D976 File Offset: 0x0000BB76
		// (set) Token: 0x06000147 RID: 327 RVA: 0x0000D987 File Offset: 0x0000BB87
		public static int PickupItemOnLevelExp
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "3A8");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "3A8", value);
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000148 RID: 328 RVA: 0x0000D999 File Offset: 0x0000BB99
		// (set) Token: 0x06000149 RID: 329 RVA: 0x0000D9AA File Offset: 0x0000BBAA
		public static int CraftXP
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "3A4");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "3A4", value);
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x0600014A RID: 330 RVA: 0x0000D9BC File Offset: 0x0000BBBC
		// (set) Token: 0x0600014B RID: 331 RVA: 0x0000D9CD File Offset: 0x0000BBCD
		public static int BuildXP
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "3A0");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "3A0", value);
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x0600014C RID: 332 RVA: 0x0000D9DF File Offset: 0x0000BBDF
		// (set) Token: 0x0600014D RID: 333 RVA: 0x0000D9F0 File Offset: 0x0000BBF0
		public static float AddWorkSpeedPerWorkSpeedRank
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "1488");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "1488", value);
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x0600014E RID: 334 RVA: 0x0000DA02 File Offset: 0x0000BC02
		// (set) Token: 0x0600014F RID: 335 RVA: 0x0000DA13 File Offset: 0x0000BC13
		public static float AddDefencePerDefenceRank
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "1484");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "1484", value);
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000150 RID: 336 RVA: 0x0000DA25 File Offset: 0x0000BC25
		// (set) Token: 0x06000151 RID: 337 RVA: 0x0000DA36 File Offset: 0x0000BC36
		public static float AddAttackPerAttackRank
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "1480");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "1480", value);
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06000152 RID: 338 RVA: 0x0000DA48 File Offset: 0x0000BC48
		// (set) Token: 0x06000153 RID: 339 RVA: 0x0000DA59 File Offset: 0x0000BC59
		public static float AddMaxHPPerHPRank
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "147C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "147C", value);
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000154 RID: 340 RVA: 0x0000DA6B File Offset: 0x0000BC6B
		// (set) Token: 0x06000155 RID: 341 RVA: 0x0000DA7C File Offset: 0x0000BC7C
		public static float AddWorkSpeedPerStatusPoint
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "1478");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "1478", value);
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000156 RID: 342 RVA: 0x0000DA8E File Offset: 0x0000BC8E
		// (set) Token: 0x06000157 RID: 343 RVA: 0x0000DA9F File Offset: 0x0000BC9F
		public static float AddCaptureLevelPerStatusPoint
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "1474");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "1474", value);
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x06000158 RID: 344 RVA: 0x0000DAB1 File Offset: 0x0000BCB1
		// (set) Token: 0x06000159 RID: 345 RVA: 0x0000DAC2 File Offset: 0x0000BCC2
		public static float AddMaxInventoryWeightPerStatusPoint
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "1470");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "1470", value);
			}
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x0600015A RID: 346 RVA: 0x0000DAD4 File Offset: 0x0000BCD4
		// (set) Token: 0x0600015B RID: 347 RVA: 0x0000DAE5 File Offset: 0x0000BCE5
		public static float AddPowerPerStatusPoint
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "146C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "146C", value);
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x0600015C RID: 348 RVA: 0x0000DAF7 File Offset: 0x0000BCF7
		// (set) Token: 0x0600015D RID: 349 RVA: 0x0000DB08 File Offset: 0x0000BD08
		public static float AddMaxSPPerStatusPoint
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "1468");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "1468", value);
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x0600015E RID: 350 RVA: 0x0000DB1A File Offset: 0x0000BD1A
		// (set) Token: 0x0600015F RID: 351 RVA: 0x0000DB2B File Offset: 0x0000BD2B
		public static float AddMaxHPPerStatusPoint
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "1464");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "1464", value);
			}
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x06000160 RID: 352 RVA: 0x0000DB3D File Offset: 0x0000BD3D
		// (set) Token: 0x06000161 RID: 353 RVA: 0x0000DB4E File Offset: 0x0000BD4E
		public static int TechnologyPointUnlockFastTravel
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "E2C");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "E2C", value);
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x06000162 RID: 354 RVA: 0x0000DB60 File Offset: 0x0000BD60
		// (set) Token: 0x06000163 RID: 355 RVA: 0x0000DB71 File Offset: 0x0000BD71
		public static int StackCount1
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PlayerInventoryItemSlot1.Address, "104");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PlayerInventoryItemSlot1.Address, "104", value);
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000164 RID: 356 RVA: 0x0000DB83 File Offset: 0x0000BD83
		// (set) Token: 0x06000165 RID: 357 RVA: 0x0000DB94 File Offset: 0x0000BD94
		public static int StackCount2
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PlayerInventoryItemSlot2.Address, "104");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PlayerInventoryItemSlot2.Address, "104", value);
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000166 RID: 358 RVA: 0x0000DBA6 File Offset: 0x0000BDA6
		// (set) Token: 0x06000167 RID: 359 RVA: 0x0000DBB7 File Offset: 0x0000BDB7
		public static int StackCount3
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PlayerInventoryItemSlot3.Address, "104");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PlayerInventoryItemSlot3.Address, "104", value);
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x06000168 RID: 360 RVA: 0x0000DBC9 File Offset: 0x0000BDC9
		// (set) Token: 0x06000169 RID: 361 RVA: 0x0000DBDA File Offset: 0x0000BDDA
		public static int StackCount4
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PlayerInventoryItemSlot4.Address, "104");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PlayerInventoryItemSlot4.Address, "104", value);
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x0600016A RID: 362 RVA: 0x0000DBEC File Offset: 0x0000BDEC
		// (set) Token: 0x0600016B RID: 363 RVA: 0x0000DBFD File Offset: 0x0000BDFD
		public static int StackCount5
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PlayerInventoryItemSlot5.Address, "104");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PlayerInventoryItemSlot5.Address, "104", value);
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x0600016C RID: 364 RVA: 0x0000DC0F File Offset: 0x0000BE0F
		// (set) Token: 0x0600016D RID: 365 RVA: 0x0000DC20 File Offset: 0x0000BE20
		public static float Durability
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalownItemDataDynamicData.Address, "70");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalownItemDataDynamicData.Address, "70", value);
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x0600016E RID: 366 RVA: 0x0000DC32 File Offset: 0x0000BE32
		// (set) Token: 0x0600016F RID: 367 RVA: 0x0000DC43 File Offset: 0x0000BE43
		public static float MaxDurability
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalownItemDataDynamicData.Address, "74");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalownItemDataDynamicData.Address, "74", value);
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06000170 RID: 368 RVA: 0x0000DC55 File Offset: 0x0000BE55
		// (set) Token: 0x06000171 RID: 369 RVA: 0x0000DC66 File Offset: 0x0000BE66
		public static float OldDurability
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalownItemDataDynamicData.Address, "78");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalownItemDataDynamicData.Address, "78", value);
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x06000172 RID: 370 RVA: 0x0000DC78 File Offset: 0x0000BE78
		// (set) Token: 0x06000173 RID: 371 RVA: 0x0000DC89 File Offset: 0x0000BE89
		public static int RemainingBullets
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalownItemDataDynamicData.Address, "7C");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalownItemDataDynamicData.Address, "7C", value);
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06000174 RID: 372 RVA: 0x0000DC9B File Offset: 0x0000BE9B
		// (set) Token: 0x06000175 RID: 373 RVA: 0x0000DCAC File Offset: 0x0000BEAC
		public static float ClimbingStaminaMove
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "25C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "25C", value);
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x06000176 RID: 374 RVA: 0x0000DCBE File Offset: 0x0000BEBE
		// (set) Token: 0x06000177 RID: 375 RVA: 0x0000DCCF File Offset: 0x0000BECF
		public static float ClimbingStaminaJump
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "260");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "260", value);
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x06000178 RID: 376 RVA: 0x0000DCE1 File Offset: 0x0000BEE1
		// (set) Token: 0x06000179 RID: 377 RVA: 0x0000DCF2 File Offset: 0x0000BEF2
		public static float FlyHoverSP
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "274");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "274", value);
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x0600017A RID: 378 RVA: 0x0000DD04 File Offset: 0x0000BF04
		// (set) Token: 0x0600017B RID: 379 RVA: 0x0000DD15 File Offset: 0x0000BF15
		public static float FlyHorizonSP
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "278");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "278", value);
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x0600017C RID: 380 RVA: 0x0000DD27 File Offset: 0x0000BF27
		// (set) Token: 0x0600017D RID: 381 RVA: 0x0000DD38 File Offset: 0x0000BF38
		public static float FlyHorizonDashSP
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "27C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "27C", value);
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x0600017E RID: 382 RVA: 0x0000DD4A File Offset: 0x0000BF4A
		// (set) Token: 0x0600017F RID: 383 RVA: 0x0000DD5B File Offset: 0x0000BF5B
		public static float FlyVerticalSP
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "280");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "280", value);
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000180 RID: 384 RVA: 0x0000DD6D File Offset: 0x0000BF6D
		// (set) Token: 0x06000181 RID: 385 RVA: 0x0000DD7E File Offset: 0x0000BF7E
		public static int JumpSP
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "28C");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "28C", value);
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000182 RID: 386 RVA: 0x0000DD90 File Offset: 0x0000BF90
		// (set) Token: 0x06000183 RID: 387 RVA: 0x0000DDA1 File Offset: 0x0000BFA1
		public static int StepSP
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "290");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "290", value);
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000184 RID: 388 RVA: 0x0000DDB3 File Offset: 0x0000BFB3
		// (set) Token: 0x06000185 RID: 389 RVA: 0x0000DDC4 File Offset: 0x0000BFC4
		public static int MeleeAttackSP
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "294");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "294", value);
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x06000186 RID: 390 RVA: 0x0000DDD6 File Offset: 0x0000BFD6
		// (set) Token: 0x06000187 RID: 391 RVA: 0x0000DDE7 File Offset: 0x0000BFE7
		public static float SprintSP
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "298");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "298", value);
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06000188 RID: 392 RVA: 0x0000DDF9 File Offset: 0x0000BFF9
		// (set) Token: 0x06000189 RID: 393 RVA: 0x0000DE0A File Offset: 0x0000C00A
		public static float GliderSP
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "29C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "29C", value);
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x0600018A RID: 394 RVA: 0x0000DE1C File Offset: 0x0000C01C
		// (set) Token: 0x0600018B RID: 395 RVA: 0x0000DE2D File Offset: 0x0000C02D
		public static float SwimmingSPIdle
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "2A4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "2A4", value);
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x0600018C RID: 396 RVA: 0x0000DE3F File Offset: 0x0000C03F
		// (set) Token: 0x0600018D RID: 397 RVA: 0x0000DE50 File Offset: 0x0000C050
		public static float SwimmingSPSwim
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "2A8");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "2A8", value);
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x0600018E RID: 398 RVA: 0x0000DE62 File Offset: 0x0000C062
		// (set) Token: 0x0600018F RID: 399 RVA: 0x0000DE73 File Offset: 0x0000C073
		public static float SwimmingSPDashSwim
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "2AC");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "2AC", value);
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x06000190 RID: 400 RVA: 0x0000DE85 File Offset: 0x0000C085
		// (set) Token: 0x06000191 RID: 401 RVA: 0x0000DE96 File Offset: 0x0000C096
		public static float BlockRespawnTime
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "CC4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "CC4", value);
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06000192 RID: 402 RVA: 0x0000DEA8 File Offset: 0x0000C0A8
		// (set) Token: 0x06000193 RID: 403 RVA: 0x0000DEB9 File Offset: 0x0000C0B9
		public static int DefenseUp
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalCharacterParameterComponent.Address, "130");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalCharacterParameterComponent.Address, "130", value);
			}
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06000194 RID: 404 RVA: 0x0000DECB File Offset: 0x0000C0CB
		// (set) Token: 0x06000195 RID: 405 RVA: 0x0000DEDC File Offset: 0x0000C0DC
		public static int AttackUp
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalCharacterParameterComponent.Address, "12C");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalCharacterParameterComponent.Address, "12C", value);
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x06000196 RID: 406 RVA: 0x0000DEEE File Offset: 0x0000C0EE
		// (set) Token: 0x06000197 RID: 407 RVA: 0x0000DEFF File Offset: 0x0000C0FF
		public static float TimeDilation
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.WorldSettings.Address, "3C8");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.WorldSettings.Address, "3C8", value);
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x06000198 RID: 408 RVA: 0x0000DF11 File Offset: 0x0000C111
		// (set) Token: 0x06000199 RID: 409 RVA: 0x0000DF22 File Offset: 0x0000C122
		public static int SPRank
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalIndividiualParameter.Address, "294");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalIndividiualParameter.Address, "294", value);
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x0600019A RID: 410 RVA: 0x0000DF34 File Offset: 0x0000C134
		// (set) Token: 0x0600019B RID: 411 RVA: 0x0000DF45 File Offset: 0x0000C145
		public static int SPLevel
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalIndividiualParameter.Address, "290");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalIndividiualParameter.Address, "290", value);
			}
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x0600019C RID: 412 RVA: 0x0000DF57 File Offset: 0x0000C157
		// (set) Token: 0x0600019D RID: 413 RVA: 0x0000DF68 File Offset: 0x0000C168
		public static float MaxStomach
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalIndividiualParameter.Address, "300");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalIndividiualParameter.Address, "300", value);
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x0600019E RID: 414 RVA: 0x0000DF7A File Offset: 0x0000C17A
		// (set) Token: 0x0600019F RID: 415 RVA: 0x0000DF8B File Offset: 0x0000C18B
		public static float MaxStomachValue
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.PalIndividiualParameter.Address, "3DC");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.PalIndividiualParameter.Address, "3DC", value);
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x060001A0 RID: 416 RVA: 0x0000DF9D File Offset: 0x0000C19D
		// (set) Token: 0x060001A1 RID: 417 RVA: 0x0000DFAE File Offset: 0x0000C1AE
		public static int SPUnusedStatusPoints
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalIndividiualParameter.Address, "3E4");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalIndividiualParameter.Address, "3E4", value);
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x060001A2 RID: 418 RVA: 0x0000DFC0 File Offset: 0x0000C1C0
		// (set) Token: 0x060001A3 RID: 419 RVA: 0x0000DFD1 File Offset: 0x0000C1D1
		public static int TechnologyPoint
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalTechnologyData.Address, "140");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalTechnologyData.Address, "140", value);
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x060001A4 RID: 420 RVA: 0x0000DFE3 File Offset: 0x0000C1E3
		// (set) Token: 0x060001A5 RID: 421 RVA: 0x0000DFF4 File Offset: 0x0000C1F4
		public static int bossTechnologyPoint
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalTechnologyData.Address, "144");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalTechnologyData.Address, "144", value);
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x060001A6 RID: 422 RVA: 0x0000E006 File Offset: 0x0000C206
		// (set) Token: 0x060001A7 RID: 423 RVA: 0x0000E017 File Offset: 0x0000C217
		public static float CombatEndDistance1
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "578");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "578", value);
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x060001A8 RID: 424 RVA: 0x0000E029 File Offset: 0x0000C229
		// (set) Token: 0x060001A9 RID: 425 RVA: 0x0000E03A File Offset: 0x0000C23A
		public static float CombatEndDistance2
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "57C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "57C", value);
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x060001AA RID: 426 RVA: 0x0000E04C File Offset: 0x0000C24C
		// (set) Token: 0x060001AB RID: 427 RVA: 0x0000E05D File Offset: 0x0000C25D
		public static float CombatEndDistance3
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "580");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "580", value);
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x060001AC RID: 428 RVA: 0x0000E06F File Offset: 0x0000C26F
		// (set) Token: 0x060001AD RID: 429 RVA: 0x0000E080 File Offset: 0x0000C280
		public static float PlayerShieldRecoverStartTime
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "374");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "374", value);
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x060001AE RID: 430 RVA: 0x0000E092 File Offset: 0x0000C292
		// (set) Token: 0x060001AF RID: 431 RVA: 0x0000E0A3 File Offset: 0x0000C2A3
		public static float PlayerShieldRecoverPercentPerSecond
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "378");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "378", value);
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060001B0 RID: 432 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		// (set) Token: 0x060001B1 RID: 433 RVA: 0x0000E0C6 File Offset: 0x0000C2C6
		public static float AutoHPRegenePercentperSecond
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "2D8");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "2D8", value);
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x060001B2 RID: 434 RVA: 0x0000E0D8 File Offset: 0x0000C2D8
		// (set) Token: 0x060001B3 RID: 435 RVA: 0x0000E0E9 File Offset: 0x0000C2E9
		public static float AutoHPRegenePercentperSecondSleeping
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "2DC");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "2DC", value);
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x060001B4 RID: 436 RVA: 0x0000E0FB File Offset: 0x0000C2FB
		// (set) Token: 0x060001B5 RID: 437 RVA: 0x0000E10C File Offset: 0x0000C30C
		public static float RideWazaStaminaRate
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "264");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "264", value);
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x060001B6 RID: 438 RVA: 0x0000E11E File Offset: 0x0000C31E
		// (set) Token: 0x060001B7 RID: 439 RVA: 0x0000E12F File Offset: 0x0000C32F
		public static float StarvationDecreaseHPPercentperSecond
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "2E4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "2E4", value);
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x060001B8 RID: 440 RVA: 0x0000E141 File Offset: 0x0000C341
		// (set) Token: 0x060001B9 RID: 441 RVA: 0x0000E152 File Offset: 0x0000C352
		public static float StomachDecreaceperSecondMonster
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "2EC");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "2EC", value);
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x060001BA RID: 442 RVA: 0x0000E164 File Offset: 0x0000C364
		// (set) Token: 0x060001BB RID: 443 RVA: 0x0000E175 File Offset: 0x0000C375
		public static float StomachDecreaceperSecondPlayer
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "2F0");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "2F0", value);
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x060001BC RID: 444 RVA: 0x0000E187 File Offset: 0x0000C387
		// (set) Token: 0x060001BD RID: 445 RVA: 0x0000E198 File Offset: 0x0000C398
		public static float StomachDecreaceAutoHealing
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "2F4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "2F4", value);
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x060001BE RID: 446 RVA: 0x0000E1AA File Offset: 0x0000C3AA
		// (set) Token: 0x060001BF RID: 447 RVA: 0x0000E1BB File Offset: 0x0000C3BB
		public static float StomachDecreaceWorkingRate
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "2F8");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "2F8", value);
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x060001C0 RID: 448 RVA: 0x0000E1CD File Offset: 0x0000C3CD
		// (set) Token: 0x060001C1 RID: 449 RVA: 0x0000E1DE File Offset: 0x0000C3DE
		public static int HungerStartStomachValue
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "2FC");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "2FC", value);
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060001C2 RID: 450 RVA: 0x0000E1F0 File Offset: 0x0000C3F0
		// (set) Token: 0x060001C3 RID: 451 RVA: 0x0000E201 File Offset: 0x0000C401
		public static float StomachDecreaceRateGroundRideSprint
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "358");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "358", value);
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x060001C4 RID: 452 RVA: 0x0000E213 File Offset: 0x0000C413
		// (set) Token: 0x060001C5 RID: 453 RVA: 0x0000E224 File Offset: 0x0000C424
		public static float StomachDecreaceRateWaterRide
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "35C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "35C", value);
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x060001C6 RID: 454 RVA: 0x0000E236 File Offset: 0x0000C436
		// (set) Token: 0x060001C7 RID: 455 RVA: 0x0000E247 File Offset: 0x0000C447
		public static float StomachDecreaceRateWaterRideSprint
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "360");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "360", value);
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x060001C8 RID: 456 RVA: 0x0000E259 File Offset: 0x0000C459
		// (set) Token: 0x060001C9 RID: 457 RVA: 0x0000E26A File Offset: 0x0000C46A
		public static float StomachDecreaceRateFlyRide
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "364");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "364", value);
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x060001CA RID: 458 RVA: 0x0000E27C File Offset: 0x0000C47C
		// (set) Token: 0x060001CB RID: 459 RVA: 0x0000E28D File Offset: 0x0000C48D
		public static float StomachDecreaceRateFlyRideSprint
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "368");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "368", value);
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x060001CC RID: 460 RVA: 0x0000E29F File Offset: 0x0000C49F
		// (set) Token: 0x060001CD RID: 461 RVA: 0x0000E2B0 File Offset: 0x0000C4B0
		public static float BodyTemperatureStomachDecreaceRate1
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.BodyTemperatureStomachDecreaseRateArray.Address, "4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.BodyTemperatureStomachDecreaseRateArray.Address, "4", value);
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x060001CE RID: 462 RVA: 0x0000E2C2 File Offset: 0x0000C4C2
		// (set) Token: 0x060001CF RID: 463 RVA: 0x0000E2D3 File Offset: 0x0000C4D3
		public static float BodyTemperatureStomachDecreaceRate2
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.BodyTemperatureStomachDecreaseRateArray.Address, "C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.BodyTemperatureStomachDecreaseRateArray.Address, "C", value);
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x060001D0 RID: 464 RVA: 0x0000E2E5 File Offset: 0x0000C4E5
		// (set) Token: 0x060001D1 RID: 465 RVA: 0x0000E2F6 File Offset: 0x0000C4F6
		public static float BodyTemperatureStomachDecreaceRate3
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.BodyTemperatureStomachDecreaseRateArray.Address, "14");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.BodyTemperatureStomachDecreaseRateArray.Address, "14", value);
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x060001D2 RID: 466 RVA: 0x0000E308 File Offset: 0x0000C508
		// (set) Token: 0x060001D3 RID: 467 RVA: 0x0000E319 File Offset: 0x0000C519
		public static float BodyTemperatureSlipDamagePercent1
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.BodyTemperatureSlipDamagePercent.Address, "4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.BodyTemperatureSlipDamagePercent.Address, "4", value);
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x060001D4 RID: 468 RVA: 0x0000E32B File Offset: 0x0000C52B
		// (set) Token: 0x060001D5 RID: 469 RVA: 0x0000E33C File Offset: 0x0000C53C
		public static float BodyTemperatureSlipDamagePercent2
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.BodyTemperatureSlipDamagePercent.Address, "C");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.BodyTemperatureSlipDamagePercent.Address, "C", value);
			}
		}

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x060001D6 RID: 470 RVA: 0x0000E34E File Offset: 0x0000C54E
		// (set) Token: 0x060001D7 RID: 471 RVA: 0x0000E35F File Offset: 0x0000C55F
		public static float BodyTemperatureSlipDamagePercent3
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.BodyTemperatureSlipDamagePercent.Address, "14");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.BodyTemperatureSlipDamagePercent.Address, "14", value);
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x060001D8 RID: 472 RVA: 0x0000E371 File Offset: 0x0000C571
		// (set) Token: 0x060001D9 RID: 473 RVA: 0x0000E382 File Offset: 0x0000C582
		public static float JumpZVelocity
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "178");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "178", value);
			}
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x060001DA RID: 474 RVA: 0x0000E394 File Offset: 0x0000C594
		// (set) Token: 0x060001DB RID: 475 RVA: 0x0000E3A5 File Offset: 0x0000C5A5
		public static float AirControl
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "220");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "220", value);
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x060001DC RID: 476 RVA: 0x0000E3B7 File Offset: 0x0000C5B7
		// (set) Token: 0x060001DD RID: 477 RVA: 0x0000E3C8 File Offset: 0x0000C5C8
		public static float SlidingStartSpeed
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "FC8");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "FC8", value);
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x060001DE RID: 478 RVA: 0x0000E3DA File Offset: 0x0000C5DA
		// (set) Token: 0x060001DF RID: 479 RVA: 0x0000E3EB File Offset: 0x0000C5EB
		public static float SlidingMaxSpeed
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "FCC");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "FCC", value);
			}
		}

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060001E0 RID: 480 RVA: 0x0000E3FD File Offset: 0x0000C5FD
		// (set) Token: 0x060001E1 RID: 481 RVA: 0x0000E40E File Offset: 0x0000C60E
		public static float ClimbMaxSpeed
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "FE0");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "FE0", value);
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060001E2 RID: 482 RVA: 0x0000E420 File Offset: 0x0000C620
		// (set) Token: 0x060001E3 RID: 483 RVA: 0x0000E431 File Offset: 0x0000C631
		public static float RollingMaxSpeed
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "FE4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "FE4", value);
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060001E4 RID: 484 RVA: 0x0000E443 File Offset: 0x0000C643
		// (set) Token: 0x060001E5 RID: 485 RVA: 0x0000E454 File Offset: 0x0000C654
		public static float MaxWalkSpeed
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "1E8");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "1E8", value);
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060001E6 RID: 486 RVA: 0x0000E466 File Offset: 0x0000C666
		// (set) Token: 0x060001E7 RID: 487 RVA: 0x0000E477 File Offset: 0x0000C677
		public static float MaxWalkSpeedCrouched
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "1EC");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "1EC", value);
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060001E8 RID: 488 RVA: 0x0000E489 File Offset: 0x0000C689
		// (set) Token: 0x060001E9 RID: 489 RVA: 0x0000E49A File Offset: 0x0000C69A
		public static float MaxSwimSpeed
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "1F0");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "1F0", value);
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060001EA RID: 490 RVA: 0x0000E4AC File Offset: 0x0000C6AC
		// (set) Token: 0x060001EB RID: 491 RVA: 0x0000E4BD File Offset: 0x0000C6BD
		public static float MaxFlySpeed
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "1F4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "1F4", value);
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x060001EC RID: 492 RVA: 0x0000E4CF File Offset: 0x0000C6CF
		// (set) Token: 0x060001ED RID: 493 RVA: 0x0000E4E0 File Offset: 0x0000C6E0
		public static float MaxCustomMovementSpeed
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "1F8");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "1F8", value);
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060001EE RID: 494 RVA: 0x0000E4F2 File Offset: 0x0000C6F2
		// (set) Token: 0x060001EF RID: 495 RVA: 0x0000E503 File Offset: 0x0000C703
		public static float MaxAcceleration
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "1FC");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "1FC", value);
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060001F0 RID: 496 RVA: 0x0000E515 File Offset: 0x0000C715
		// (set) Token: 0x060001F1 RID: 497 RVA: 0x0000E526 File Offset: 0x0000C726
		public static float FatigueMaxSpeed
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "FAC");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "FAC", value);
			}
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060001F2 RID: 498 RVA: 0x0000E538 File Offset: 0x0000C738
		// (set) Token: 0x060001F3 RID: 499 RVA: 0x0000E549 File Offset: 0x0000C749
		public static float SprintMaxSpeed
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "FB0");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "FB0", value);
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060001F4 RID: 500 RVA: 0x0000E55B File Offset: 0x0000C75B
		// (set) Token: 0x060001F5 RID: 501 RVA: 0x0000E56C File Offset: 0x0000C76C
		public static float SprintMaxAcceleration
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UCharacterMovementComponent.Address, "FB4");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UCharacterMovementComponent.Address, "FB4", value);
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060001F6 RID: 502 RVA: 0x0000E57E File Offset: 0x0000C77E
		// (set) Token: 0x060001F7 RID: 503 RVA: 0x0000E58F File Offset: 0x0000C78F
		public static float CustomTimeDilation
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.APalCharacter.Address, "64");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.APalCharacter.Address, "64", value);
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x060001F8 RID: 504 RVA: 0x0000E5A1 File Offset: 0x0000C7A1
		// (set) Token: 0x060001F9 RID: 505 RVA: 0x0000E5B2 File Offset: 0x0000C7B2
		public static double VelocityZ
		{
			get
			{
				return PropertyAccessors.ReadDoubleProperty(Addresses.UCharacterMovementComponent.Address, "C8");
			}
			set
			{
				PropertyAccessors.WriteDoubleProperty(Addresses.UCharacterMovementComponent.Address, "C8", value);
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x060001FA RID: 506 RVA: 0x0000E5C4 File Offset: 0x0000C7C4
		// (set) Token: 0x060001FB RID: 507 RVA: 0x0000E5D5 File Offset: 0x0000C7D5
		public static byte bReplicateMovement
		{
			get
			{
				return PropertyAccessors.ReadByteProperty(Addresses.APalCharacter.Address, "58");
			}
			set
			{
				PropertyAccessors.WriteByteProperty(Addresses.APalCharacter.Address, "58", value);
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x060001FC RID: 508 RVA: 0x0000E5E7 File Offset: 0x0000C7E7
		// (set) Token: 0x060001FD RID: 509 RVA: 0x0000E5F8 File Offset: 0x0000C7F8
		public static float MaxInventoryWeight
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalPlayerInventoryData.Address, "154");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalPlayerInventoryData.Address, "154", value);
			}
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x060001FE RID: 510 RVA: 0x0000E60A File Offset: 0x0000C80A
		// (set) Token: 0x060001FF RID: 511 RVA: 0x0000E61B File Offset: 0x0000C81B
		public static float NowItemWeight
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalPlayerInventoryData.Address, "150");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalPlayerInventoryData.Address, "150", value);
			}
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06000200 RID: 512 RVA: 0x0000E62D File Offset: 0x0000C82D
		// (set) Token: 0x06000201 RID: 513 RVA: 0x0000E63E File Offset: 0x0000C83E
		public static int StatusPointPerLevel
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.UPalGameSetting.Address, "1460");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.UPalGameSetting.Address, "1460", value);
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000202 RID: 514 RVA: 0x0000E650 File Offset: 0x0000C850
		// (set) Token: 0x06000203 RID: 515 RVA: 0x0000E661 File Offset: 0x0000C861
		public static int bIsEnableMuteki
		{
			get
			{
				return PropertyAccessors.ReadIntProperty(Addresses.PalCharacterParameterComponent.Address, "A2");
			}
			set
			{
				PropertyAccessors.WriteIntProperty(Addresses.PalCharacterParameterComponent.Address, "A2", value);
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000204 RID: 516 RVA: 0x0000E673 File Offset: 0x0000C873
		// (set) Token: 0x06000205 RID: 517 RVA: 0x0000E684 File Offset: 0x0000C884
		public static float CrimeStateMaintainDurationBaseDefault
		{
			get
			{
				return PropertyAccessors.ReadFloatProperty(Addresses.UPalGameSetting.Address, "E08");
			}
			set
			{
				PropertyAccessors.WriteFloatProperty(Addresses.UPalGameSetting.Address, "E08", value);
			}
		}

		// Token: 0x040000C8 RID: 200
		private const string NowItemWeight_Offset = "150";

		// Token: 0x040000C9 RID: 201
		private const string MaxInventoryWeight_Offset = "154";

		// Token: 0x040000CA RID: 202
		private const string StatusPointPerLevel_Offset = "1460";

		// Token: 0x040000CB RID: 203
		private const string bReplicateMovement_Offset = "58";

		// Token: 0x040000CC RID: 204
		public const string IDInstanceIdA_Offset = "48";

		// Token: 0x040000CD RID: 205
		public const string IDInstanceIdB_Offset = "4C";

		// Token: 0x040000CE RID: 206
		public const string IDInstanceIdC_Offset = "50";

		// Token: 0x040000CF RID: 207
		public const string IDInstanceIdD_Offset = "54";

		// Token: 0x040000D0 RID: 208
		private const string VelocityZ_Offset = "C8";

		// Token: 0x040000D1 RID: 209
		private const string CustomTimeDilation_Offset = "64";

		// Token: 0x040000D2 RID: 210
		private const string MaxWalkSpeed_Offset = "1E8";

		// Token: 0x040000D3 RID: 211
		private const string MaxWalkSpeedCrouched_Offset = "1EC";

		// Token: 0x040000D4 RID: 212
		private const string MaxSwimSpeed_Offset = "1F0";

		// Token: 0x040000D5 RID: 213
		private const string MaxFlySpeed_Offset = "1F4";

		// Token: 0x040000D6 RID: 214
		private const string MaxCustomMovementSpeed_Offset = "1F8";

		// Token: 0x040000D7 RID: 215
		private const string MaxAcceleration_Offset = "1FC";

		// Token: 0x040000D8 RID: 216
		private const string FatigueMaxSpeed_Offset = "FAC";

		// Token: 0x040000D9 RID: 217
		private const string SprintMaxSpeed_Offset = "FB0";

		// Token: 0x040000DA RID: 218
		private const string SprintMaxAcceleration_Offset = "FB4";

		// Token: 0x040000DB RID: 219
		private const string ClimbMaxSpeed_Offset = "FE0";

		// Token: 0x040000DC RID: 220
		private const string RollingMaxSpeed_Offset = "FE4";

		// Token: 0x040000DD RID: 221
		private const string SlidingStartSpeed_Offset = "FC8";

		// Token: 0x040000DE RID: 222
		private const string SlidingMaxSpeed_Offset = "FCC";

		// Token: 0x040000DF RID: 223
		public const string AirControl_Offset = "220";

		// Token: 0x040000E0 RID: 224
		private const string JumpZVelocity_Offset = "178";

		// Token: 0x040000E1 RID: 225
		private const string bIsEnableMuteki_Offset = "A2";

		// Token: 0x040000E2 RID: 226
		private const string CrimeStateMaintainDurationBaseDefault_Offset = "E08";

		// Token: 0x040000E3 RID: 227
		private const string BodyTemperature_StomachDecreaceRate1_Offset = "4";

		// Token: 0x040000E4 RID: 228
		private const string BodyTemperature_StomachDecreaceRate2_Offset = "C";

		// Token: 0x040000E5 RID: 229
		private const string BodyTemperature_StomachDecreaceRate3_Offset = "14";

		// Token: 0x040000E6 RID: 230
		private const string BodyTemperature_SlipDamage_Percent1_Offset = "4";

		// Token: 0x040000E7 RID: 231
		private const string BodyTemperature_SlipDamage_Percent2_Offset = "C";

		// Token: 0x040000E8 RID: 232
		private const string BodyTemperature_SlipDamage_Percent3_Offset = "14";

		// Token: 0x040000E9 RID: 233
		private const string StomachDecreace_perSecond_Monster_Offset = "2EC";

		// Token: 0x040000EA RID: 234
		private const string StomachDecreace_perSecond_Player_Offset = "2F0";

		// Token: 0x040000EB RID: 235
		private const string StomachDecreace_AutoHealing_Offset = "2F4";

		// Token: 0x040000EC RID: 236
		private const string StomachDecreace_WorkingRate_Offset = "2F8";

		// Token: 0x040000ED RID: 237
		private const string HungerStart_StomachValue_Offset = "2FC";

		// Token: 0x040000EE RID: 238
		private const string StomachDecreaceRate_GroundRide_Sprint_Offset = "358";

		// Token: 0x040000EF RID: 239
		private const string StomachDecreaceRate_WaterRide_Offset = "35C";

		// Token: 0x040000F0 RID: 240
		private const string StomachDecreaceRate_WaterRide_Sprint_Offset = "360";

		// Token: 0x040000F1 RID: 241
		private const string StomachDecreaceRate_FlyRide_Offset = "364";

		// Token: 0x040000F2 RID: 242
		private const string StomachDecreaceRate_FlyRide_Sprint_Offset = "368";

		// Token: 0x040000F3 RID: 243
		private const string RideWazaStaminaRate_Offset = "264";

		// Token: 0x040000F4 RID: 244
		private const string Starvation_DecreaseHP_Percent_perSecond_Offset = "2E4";

		// Token: 0x040000F5 RID: 245
		private const string AutoHPRegene_Percent_perSecond_Offset = "2D8";

		// Token: 0x040000F6 RID: 246
		private const string AutoHPRegene_Percent_perSecond_Sleeping_Offset = "2DC";

		// Token: 0x040000F7 RID: 247
		private const string PlayerShield_RecoverStartTime_Offset = "374";

		// Token: 0x040000F8 RID: 248
		private const string PlayerShield_RecoverPercentPerSecond_Offset = "378";

		// Token: 0x040000F9 RID: 249
		private const string CombatEndDistance_BattleStartSelfPos_To_SelfPos_Offset = "578";

		// Token: 0x040000FA RID: 250
		private const string CombatEndDistance_BattleStartSelfPos_To_TargetPos_Offset = "57C";

		// Token: 0x040000FB RID: 251
		private const string CombatEndDistance_BattleStartSelfPos_To_TargetPos_AddFirstTargetDistance_Offset = "580";

		// Token: 0x040000FC RID: 252
		private const string SPUnusedStatusPoints_Offset = "3E4";

		// Token: 0x040000FD RID: 253
		private const string TechnologyPoint_Offset = "140";

		// Token: 0x040000FE RID: 254
		private const string bossTechnologyPoint_Offset = "144";

		// Token: 0x040000FF RID: 255
		private const string MaxStomach_Offset = "300";

		// Token: 0x04000100 RID: 256
		private const string SPLevel_Offset = "290";

		// Token: 0x04000101 RID: 257
		private const string SPRank_Offset = "294";

		// Token: 0x04000102 RID: 258
		private const string MaxStomachValue_Offset = "3DC";

		// Token: 0x04000103 RID: 259
		private const string TimeDilation_Offset = "3C8";

		// Token: 0x04000104 RID: 260
		private const string AttackUP_Offset = "12C";

		// Token: 0x04000105 RID: 261
		private const string DefenseUP_Offset = "130";

		// Token: 0x04000106 RID: 262
		private const string ClimbingStaminaMove_Offset = "25C";

		// Token: 0x04000107 RID: 263
		private const string ClimbingStaminaJump_Offset = "260";

		// Token: 0x04000108 RID: 264
		private const string FlyHover_SP_Offset = "274";

		// Token: 0x04000109 RID: 265
		private const string FlyHorizon_SP_Offset = "278";

		// Token: 0x0400010A RID: 266
		private const string FlyHorizon_Dash_SP_Offset = "27C";

		// Token: 0x0400010B RID: 267
		private const string FlyVertical_SP_Offset = "280";

		// Token: 0x0400010C RID: 268
		private const string JumpSP_Offset = "28C";

		// Token: 0x0400010D RID: 269
		private const string StepSP_Offset = "290";

		// Token: 0x0400010E RID: 270
		private const string MeleeAttackSP_Offset = "294";

		// Token: 0x0400010F RID: 271
		private const string SprintSP_Offset = "298";

		// Token: 0x04000110 RID: 272
		private const string GliderSP_Offset = "29C";

		// Token: 0x04000111 RID: 273
		private const string Swimming_SP_Idle_Offset = "2A4";

		// Token: 0x04000112 RID: 274
		private const string Swimming_SP_Swim_Offset = "2A8";

		// Token: 0x04000113 RID: 275
		private const string Swimming_SP_DashSwim_Offset = "2AC";

		// Token: 0x04000114 RID: 276
		private const string BlockRespawnTime_Offset = "CC4";

		// Token: 0x04000115 RID: 277
		private const string Durability_Offset = "70";

		// Token: 0x04000116 RID: 278
		private const string MaxDurability_Offset = "74";

		// Token: 0x04000117 RID: 279
		private const string OldDurability_Offset = "78";

		// Token: 0x04000118 RID: 280
		private const string RemainingBullets_Offset = "7C";

		// Token: 0x04000119 RID: 281
		private const string StackCount_Offset = "104";

		// Token: 0x0400011A RID: 282
		private const string AddMaxHPPerStatusPoint_Offset = "1464";

		// Token: 0x0400011B RID: 283
		private const string AddMaxSPPerStatusPoint_Offset = "1468";

		// Token: 0x0400011C RID: 284
		private const string AddPowerPerStatusPoint_Offset = "146C";

		// Token: 0x0400011D RID: 285
		private const string AddMaxInventoryWeightPerStatusPoint_Offset = "1470";

		// Token: 0x0400011E RID: 286
		private const string AddCaptureLevelPerStatusPoint_Offset = "1474";

		// Token: 0x0400011F RID: 287
		private const string AddWorkSpeedPerStatusPoint_Offset = "1478";

		// Token: 0x04000120 RID: 288
		private const string AddMaxHPPerHPRank_Offset = "147C";

		// Token: 0x04000121 RID: 289
		private const string AddAttackPerAttackRank_Offset = "1480";

		// Token: 0x04000122 RID: 290
		private const string AddDefencePerDefenceRank_Offset = "1484";

		// Token: 0x04000123 RID: 291
		private const string AddWorkSpeedPerWorkSpeedRank_Offset = "1488";

		// Token: 0x04000124 RID: 292
		private const string BuildXP_Offset = "3A0";

		// Token: 0x04000125 RID: 293
		private const string CraftXP_Offset = "3A4";

		// Token: 0x04000126 RID: 294
		private const string PickupItemOnLevelExp_Offset = "3A8";

		// Token: 0x04000127 RID: 295
		private const string MapObjectDestroyProceedExp_Offset = "3AC";

		// Token: 0x04000128 RID: 296
		private const string TechnologyPoint_UnlockFastTravel_Offset = "E2C";

		// Token: 0x04000129 RID: 297
		private const string RarePalAppearanceProbability_Offset = "58";

		// Token: 0x0400012A RID: 298
		private const string CharacterMaxRank_Offset = "28";

		// Token: 0x0400012B RID: 299
		private const string RarePal_LevelMultiply_Offset = "5C";

		// Token: 0x0400012C RID: 300
		private const string BossOrRarePal_TalentMin_Offset = "60";

		// Token: 0x0400012D RID: 301
		private const string CaptureJudgeRate1_Offset = "0";

		// Token: 0x0400012E RID: 302
		private const string CaptureJudgeRate2_Offset = "4";

		// Token: 0x0400012F RID: 303
		private const string CaptureJudgeRate3_Offset = "8";

		// Token: 0x04000130 RID: 304
		private const string DamageValueMinMapObject_Offset = "1E0";

		// Token: 0x04000131 RID: 305
		private const string SPRankAttack_Offset = "29C";

		// Token: 0x04000132 RID: 306
		private const string SPRankDefence_Offset = "2A0";

		// Token: 0x04000133 RID: 307
		private const string SPRankCraftSpeed_Offset = "2A4";

		// Token: 0x04000134 RID: 308
		private const string IsRarePal_Offset = "2C0";

		// Token: 0x04000135 RID: 309
		private const string SPMaxHPValue_Offset = "358";

		// Token: 0x04000136 RID: 310
		private const string SPSupport_Offset = "360";

		// Token: 0x04000137 RID: 311
		private const string SPMHP_Offset = "2E8";

		// Token: 0x04000138 RID: 312
		private const string SPGender_Offset = "280";

		// Token: 0x04000139 RID: 313
		private const string SPHungerType_Offset = "398";

		// Token: 0x0400013A RID: 314
		private const string SPSanityValue_Offset = "39C";

		// Token: 0x0400013B RID: 315
		private const string EquipWazaAttackSlot1_Offset = "0";

		// Token: 0x0400013C RID: 316
		private const string EquipWazaAttackSlot2_Offset = "1";

		// Token: 0x0400013D RID: 317
		private const string EquipWazaAttackSlot3_Offset = "2";

		// Token: 0x0400013E RID: 318
		private const string InstallDinstanceFromOwner_Offset = "D0";

		// Token: 0x0400013F RID: 319
		private const string BaseCampAreaRange_Offset = "E0";

		// Token: 0x04000140 RID: 320
		public const string PassiveSkill1_Offset = "0";

		// Token: 0x04000141 RID: 321
		public const string PassiveSkill2_Offset = "8";

		// Token: 0x04000142 RID: 322
		public const string PassiveSkill3_Offset = "10";

		// Token: 0x04000143 RID: 323
		public const string PassiveSkill4_Offset = "18";

		// Token: 0x04000144 RID: 324
		public const string PassiveSkill5_Offset = "20";

		// Token: 0x04000145 RID: 325
		public const string PassiveSkill6_Offset = "28";

		// Token: 0x04000146 RID: 326
		public const string PassiveSkill7_Offset = "30";

		// Token: 0x04000147 RID: 327
		public const string PassiveSkill8_Offset = "38";

		// Token: 0x04000148 RID: 328
		public const string PassiveSkill9_Offset = "40";

		// Token: 0x04000149 RID: 329
		public const string PassiveSkill10_Offset = "48";

		// Token: 0x0400014A RID: 330
		public const string PassiveSkill11_Offset = "50";

		// Token: 0x0400014B RID: 331
		public const string PassiveSkillSize_Offset = "310";

		// Token: 0x0400014C RID: 332
		public const string PassiveSkill1SizeMax_Offset = "314";

		// Token: 0x0400014D RID: 333
		public const string StaticDurability_Offset = "120";

		// Token: 0x0400014E RID: 334
		public const string StaticWeight_Offset = "11C";

		// Token: 0x0400014F RID: 335
		public const string MagazineSize_Offset = "158";

		// Token: 0x04000150 RID: 336
		public const string StaticAttackValue_Offset = "160";

		// Token: 0x04000151 RID: 337
		public const string StaticDefenseValue_Offset = "164";

		// Token: 0x04000152 RID: 338
		public const string StaticRarity_Offset = "68";

		// Token: 0x04000153 RID: 339
		public const string PalSoulID_Offset = "40";

		// Token: 0x04000154 RID: 340
		public const string GoldID_Offset = "48";

		// Token: 0x04000155 RID: 341
		public const string ItemIdStaticId_Offset = "DC";

		// Token: 0x04000156 RID: 342
		public const string WoodID_Offset = "30";

		// Token: 0x04000157 RID: 343
		public const string DefaultEi_Offset = "38";

		// Token: 0x04000158 RID: 344
		public const string PalRarity1_Offset = "0";

		// Token: 0x04000159 RID: 345
		public const string EggScale1_Offset = "4";

		// Token: 0x0400015A RID: 346
		public const string HatchingSpeedDivisionRate1_Offset = "8";

		// Token: 0x0400015B RID: 347
		public const string PalRarity2_Offset = "C";

		// Token: 0x0400015C RID: 348
		public const string EggScale2_Offset = "10";

		// Token: 0x0400015D RID: 349
		public const string HatchingSpeedDivisionRate2_Offset = "14";

		// Token: 0x0400015E RID: 350
		public const string PalRarity3_Offset = "18";

		// Token: 0x0400015F RID: 351
		public const string EggScale3_Offset = "1C";

		// Token: 0x04000160 RID: 352
		public const string HatchingSpeedDivisionRate3_Offset = "20";

		// Token: 0x04000161 RID: 353
		public const string PalRarity4_Offset = "24";

		// Token: 0x04000162 RID: 354
		public const string EggScale4_Offset = "28";

		// Token: 0x04000163 RID: 355
		public const string HatchingSpeedDivisionRate4_Offset = "2C";

		// Token: 0x04000164 RID: 356
		public const string PalRarity5_Offset = "30";

		// Token: 0x04000165 RID: 357
		public const string EggScale5_Offset = "34";

		// Token: 0x04000166 RID: 358
		public const string HatchingSpeedDivisionRate5_Offset = "38";

		// Token: 0x04000167 RID: 359
		public const string PalEggTempHatchRate1_Offset = "4";

		// Token: 0x04000168 RID: 360
		public const string PalEggTempHatchRate2_Offset = "14";

		// Token: 0x04000169 RID: 361
		public const string PalEggTempHatchRate3_Offset = "24";

		// Token: 0x0400016A RID: 362
		public const string PalEggTempHatchRate4_Offset = "34";

		// Token: 0x0400016B RID: 363
		public const string PalEggTempHatchRate5_Offset = "44";

		// Token: 0x0400016C RID: 364
		public const string PalEggTempHatchRate6_Offset = "54";

		// Token: 0x0400016D RID: 365
		public const string PalEggTempHatchRate7_Offset = "64";

		// Token: 0x0400016E RID: 366
		public const string PalEggTempHatchRate8_Offset = "74";

		// Token: 0x0400016F RID: 367
		public const string PalEggTempHatchRate9_Offset = "84";
	}
}
