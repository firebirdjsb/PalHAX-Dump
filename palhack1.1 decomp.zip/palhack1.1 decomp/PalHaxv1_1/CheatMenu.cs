﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace PalHaxv1_1
{
	// Token: 0x02000003 RID: 3
	public partial class CheatMenu : Form
	{
		// Token: 0x14000003 RID: 3
		// (add) Token: 0x0600000E RID: 14 RVA: 0x000022BC File Offset: 0x000004BC
		// (remove) Token: 0x0600000F RID: 15 RVA: 0x000022F4 File Offset: 0x000004F4
		public event EventHandler<bool> SpoofPositionToggled;

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x06000010 RID: 16 RVA: 0x0000232C File Offset: 0x0000052C
		// (remove) Token: 0x06000011 RID: 17 RVA: 0x00002364 File Offset: 0x00000564
		public event EventHandler<bool> FlymodeToggled;

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x06000012 RID: 18 RVA: 0x0000239C File Offset: 0x0000059C
		// (remove) Token: 0x06000013 RID: 19 RVA: 0x000023D4 File Offset: 0x000005D4
		public event EventHandler<bool> SpeedhackToggled;

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x06000014 RID: 20 RVA: 0x0000240C File Offset: 0x0000060C
		// (remove) Token: 0x06000015 RID: 21 RVA: 0x00002444 File Offset: 0x00000644
		public event EventHandler<bool> SuperJumpToggled;

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x06000016 RID: 22 RVA: 0x0000247C File Offset: 0x0000067C
		// (remove) Token: 0x06000017 RID: 23 RVA: 0x000024B4 File Offset: 0x000006B4
		public event EventHandler<bool> GodmodeToggled;

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x06000018 RID: 24 RVA: 0x000024EC File Offset: 0x000006EC
		// (remove) Token: 0x06000019 RID: 25 RVA: 0x00002524 File Offset: 0x00000724
		public event EventHandler<bool> ShowWatermarkToggled;

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x0600001A RID: 26 RVA: 0x0000255C File Offset: 0x0000075C
		// (remove) Token: 0x0600001B RID: 27 RVA: 0x00002594 File Offset: 0x00000794
		public event EventHandler<bool> ShowHotkeyToggled;

		// Token: 0x0600001C RID: 28 RVA: 0x000025CC File Offset: 0x000007CC
		public CheatMenu()
		{
			this.InitializeComponent();
			CheatMenuManager cheatMenuManager = new CheatMenuManager(this);
			cheatMenuManager.Initialize();
			this.ShowWatermarkBox.Checked = true;
			this.ShowHotkeyBox.Checked = true;
			this.InitializeUI();
			cheatMenuManager.WireButtonClickEvents();
			cheatMenuManager.WireScrollbarEvents();
		}

		// Token: 0x0600001D RID: 29 RVA: 0x0000261A File Offset: 0x0000081A
		private void InitializeUI()
		{
			FormHelper.SetRoundedFormAppearance(this, 20);
			this.ShowWatermarkBox.Checked = true;
			this.ShowHotkeyBox.Checked = true;
		}

		// Token: 0x0600001E RID: 30 RVA: 0x0000263C File Offset: 0x0000083C
		public bool IsFlymodeEnabled()
		{
			return this.FlymodeBox.Checked;
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00002649 File Offset: 0x00000849
		internal void MoveArrowPicture_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				Bools.isDragging = true;
				this.dragCursorPoint = Cursor.Position;
				this.dragFormPoint = base.Location;
			}
		}

		// Token: 0x06000020 RID: 32 RVA: 0x00002678 File Offset: 0x00000878
		internal void MoveArrowPicture_MouseMove(object sender, MouseEventArgs e)
		{
			if (Bools.isDragging)
			{
				Point pt = Point.Subtract(Cursor.Position, new Size(this.dragCursorPoint));
				base.Location = Point.Add(this.dragFormPoint, new Size(pt));
			}
		}

		// Token: 0x06000021 RID: 33 RVA: 0x000026B9 File Offset: 0x000008B9
		internal void MoveArrowPicture_MouseUp(object sender, MouseEventArgs e)
		{
			Bools.isDragging = false;
		}

		// Token: 0x06000022 RID: 34 RVA: 0x000026C1 File Offset: 0x000008C1
		public void ToggleSpoofPositionCheckbox()
		{
			this.SpoofPositionBox.Checked = !this.SpoofPositionBox.Checked;
		}

		// Token: 0x06000023 RID: 35 RVA: 0x000026DC File Offset: 0x000008DC
		public void ToggleSpeedhackCheckbox()
		{
			this.SpeedhackBox.Checked = !this.SpeedhackBox.Checked;
		}

		// Token: 0x06000024 RID: 36 RVA: 0x000026F7 File Offset: 0x000008F7
		public void ToggleFlymodeCheckbox()
		{
			this.FlymodeBox.Checked = !this.FlymodeBox.Checked;
		}

		// Token: 0x06000025 RID: 37 RVA: 0x00002712 File Offset: 0x00000912
		public void ToggleSuperJumpCheckbox()
		{
			this.SuperJumpBox.Checked = !this.SuperJumpBox.Checked;
		}

		// Token: 0x06000026 RID: 38 RVA: 0x0000272D File Offset: 0x0000092D
		private void SpoofPositionBox_CheckedChanged(object sender, EventArgs e)
		{
			EventHandler<bool> spoofPositionToggled = this.SpoofPositionToggled;
			if (spoofPositionToggled == null)
			{
				return;
			}
			spoofPositionToggled(this, this.SpoofPositionBox.Checked);
		}

		// Token: 0x06000027 RID: 39 RVA: 0x0000274B File Offset: 0x0000094B
		private void FlymodeBox_CheckedChanged(object sender, EventArgs e)
		{
			EventHandler<bool> flymodeToggled = this.FlymodeToggled;
			if (flymodeToggled == null)
			{
				return;
			}
			flymodeToggled(this, this.FlymodeBox.Checked);
		}

		// Token: 0x06000028 RID: 40 RVA: 0x00002769 File Offset: 0x00000969
		private void SpeedhackBox_CheckedChanged(object sender, EventArgs e)
		{
			EventHandler<bool> speedhackToggled = this.SpeedhackToggled;
			if (speedhackToggled == null)
			{
				return;
			}
			speedhackToggled(this, this.SpeedhackBox.Checked);
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00002787 File Offset: 0x00000987
		private void SuperJumpBox_CheckedChanged(object sender, EventArgs e)
		{
			EventHandler<bool> superJumpToggled = this.SuperJumpToggled;
			if (superJumpToggled == null)
			{
				return;
			}
			superJumpToggled(this, this.SuperJumpBox.Checked);
		}

		// Token: 0x0600002A RID: 42 RVA: 0x000027A5 File Offset: 0x000009A5
		private void ShowWatermarkBox_CheckedChanged(object sender, EventArgs e)
		{
			EventHandler<bool> showWatermarkToggled = this.ShowWatermarkToggled;
			if (showWatermarkToggled == null)
			{
				return;
			}
			showWatermarkToggled(this, this.ShowWatermarkBox.Checked);
		}

		// Token: 0x0600002B RID: 43 RVA: 0x000027C3 File Offset: 0x000009C3
		private void ShowHotkeyBox_CheckedChanged(object sender, EventArgs e)
		{
			EventHandler<bool> showHotkeyToggled = this.ShowHotkeyToggled;
			if (showHotkeyToggled == null)
			{
				return;
			}
			showHotkeyToggled(this, this.ShowHotkeyBox.Checked);
		}

		// Token: 0x0600002C RID: 44 RVA: 0x000027E1 File Offset: 0x000009E1
		private void GetInvStatsButton_Click(object sender, EventArgs e)
		{
			TextboxValueHandler.UpdateTextBoxesFromStackCounts(this.tbStackCount_, this.tbStackCount2_, this.tbStackCount3_, this.tbStackCount4_, this.tbStackCount5_);
		}

		// Token: 0x0600002D RID: 45 RVA: 0x00002806 File Offset: 0x00000A06
		private void SetInvStatsButton_Click(object sender, EventArgs e)
		{
			TextboxValueHandler.UpdateStackCountsFromTextBoxes(this.tbStackCount_, this.tbStackCount2_, this.tbStackCount3_, this.tbStackCount4_, this.tbStackCount5_);
		}

		// Token: 0x0600002E RID: 46 RVA: 0x0000282C File Offset: 0x00000A2C
		private void GetStatsButton_Click(object sender, EventArgs e)
		{
			TextboxValueHandler.UpdateStatsTextBoxes(this.tbStatusPointPerLevel_, this.tbAddMaxHPPerStatusPoint_, this.tbAddMaxSPPerStatusPoint_, this.tbAddPowerPerStatusPoint_, this.tbAddMaxInventoryWeightPerStatusPoint_, this.tbAddCaptureLevelPerStatusPoint_, this.tbAddWorkSpeedPerStatusPoint_, this.tbAddMaxHPPerHPRank_, this.tbAddAttackPerAttackRank_, this.tbAddDefencePerDefenceRank_, this.tbAddWorkSpeedPerWorkSpeedRank_, this.tbTechnologyPoint_UnlockFastTravel_);
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00002888 File Offset: 0x00000A88
		private void SetStatsButton_Click(object sender, EventArgs e)
		{
			TextboxValueHandler.SetStatsFromTextBoxes(this.tbStatusPointPerLevel_, this.tbAddMaxHPPerStatusPoint_, this.tbAddMaxSPPerStatusPoint_, this.tbAddPowerPerStatusPoint_, this.tbAddMaxInventoryWeightPerStatusPoint_, this.tbAddCaptureLevelPerStatusPoint_, this.tbAddWorkSpeedPerStatusPoint_, this.tbAddMaxHPPerHPRank_, this.tbAddAttackPerAttackRank_, this.tbAddDefencePerDefenceRank_, this.tbAddWorkSpeedPerWorkSpeedRank_, this.tbTechnologyPoint_UnlockFastTravel_);
		}

		// Token: 0x06000030 RID: 48 RVA: 0x000028E2 File Offset: 0x00000AE2
		private void GetXPButton_Click(object sender, EventArgs e)
		{
			TextboxValueHandler.UpdateXPTextBoxes(this.tbBuildXP_, this.tbCraftXP_, this.tbPickupItemOnLevelExp_, this.tbMapObjectDestroyProceedExp_);
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00002901 File Offset: 0x00000B01
		private void SetXPButton_Click(object sender, EventArgs e)
		{
			TextboxValueHandler.SetXPFromTextBoxes(this.tbBuildXP_, this.tbCraftXP_, this.tbPickupItemOnLevelExp_, this.tbMapObjectDestroyProceedExp_);
		}

		// Token: 0x06000032 RID: 50 RVA: 0x00002920 File Offset: 0x00000B20
		private void GetPalAttackButton_Click(object sender, EventArgs e)
		{
			this.tbEquipWazaAttackSlot1_.Text = ((byte)Offsets.EquipWazaAttackSlot1).ToString();
			this.tbEquipWazaAttackSlot2_.Text = ((byte)Offsets.EquipWazaAttackSlot2).ToString();
			this.tbEquipWazaAttackSlot3_.Text = ((byte)Offsets.EquipWazaAttackSlot3).ToString();
		}

		// Token: 0x06000033 RID: 51 RVA: 0x00002978 File Offset: 0x00000B78
		private void SetPalAttackButton_Click(object sender, EventArgs e)
		{
			try
			{
				Offsets.EquipWazaAttackSlot1 = (int)byte.Parse(this.tbEquipWazaAttackSlot1_.Text);
				Offsets.EquipWazaAttackSlot2 = (int)byte.Parse(this.tbEquipWazaAttackSlot2_.Text);
				Offsets.EquipWazaAttackSlot3 = (int)byte.Parse(this.tbEquipWazaAttackSlot3_.Text);
			}
			catch (FormatException)
			{
				MessageBox.Show("Invalid input. Please enter valid numbers.");
			}
		}

		// Token: 0x06000034 RID: 52 RVA: 0x000029E4 File Offset: 0x00000BE4
		private void GetPalInstanceID_Click(object sender, EventArgs e)
		{
			CheatMenu.storedIDInstanceIdA = Offsets.IDInstanceIdA;
			CheatMenu.storedIDInstanceIdB = Offsets.IDInstanceIdB;
			CheatMenu.storedIDInstanceIdC = Offsets.IDInstanceIdC;
			CheatMenu.storedIDInstanceIdD = Offsets.IDInstanceIdD;
		}

		// Token: 0x06000035 RID: 53 RVA: 0x00002A0E File Offset: 0x00000C0E
		private void SetPalInstanceID_Click(object sender, EventArgs e)
		{
			CheatMenu.WriteStoredValuesToMemory();
		}

		// Token: 0x06000036 RID: 54 RVA: 0x00002A18 File Offset: 0x00000C18
		public static void WriteStoredValuesToMemory()
		{
			PropertyAccessors.WriteUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "48", CheatMenu.storedIDInstanceIdA);
			PropertyAccessors.WriteUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "4C", CheatMenu.storedIDInstanceIdB);
			PropertyAccessors.WriteUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "50", CheatMenu.storedIDInstanceIdC);
			PropertyAccessors.WriteUIntProperty(Addresses.CharacterInventoryPalsSlot1Handle.Address, "54", CheatMenu.storedIDInstanceIdD);
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00002A78 File Offset: 0x00000C78
		private void GetPalStatsButton_Click(object sender, EventArgs e)
		{
			this.tbSPRankAttack_.Text = Offsets.SPRankAttack.ToString("D");
			this.tbSPRankDefence_.Text = Offsets.SPRankDefence.ToString("D");
			this.tbSPRankCraftSpeed_.Text = Offsets.SPRankCraftSpeed.ToString("D");
			this.tbSPSupport_.Text = Offsets.SPSupport.ToString("D");
		}

		// Token: 0x06000038 RID: 56 RVA: 0x00002AFC File Offset: 0x00000CFC
		private void SetPalStatsButton_Click(object sender, EventArgs e)
		{
			try
			{
				Offsets.SPRankAttack = int.Parse(this.tbSPRankAttack_.Text);
				Offsets.SPRankDefence = int.Parse(this.tbSPRankDefence_.Text);
				Offsets.SPRankCraftSpeed = int.Parse(this.tbSPRankCraftSpeed_.Text);
				Offsets.SPSupport = int.Parse(this.tbSPSupport_.Text);
			}
			catch (FormatException)
			{
				MessageBox.Show("Invalid input. Please enter valid numbers.");
			}
		}

		// Token: 0x06000039 RID: 57 RVA: 0x00002B80 File Offset: 0x00000D80
		private void GetBaseStatsButton_Click(object sender, EventArgs e)
		{
			this.tbInstallDinstanceFromOwner_.Text = Offsets.InstallDinstanceFromOwner.ToString("F0");
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00002BAC File Offset: 0x00000DAC
		private void SetBaseStatsButton_Click(object sender, EventArgs e)
		{
			try
			{
				Offsets.InstallDinstanceFromOwner = float.Parse(this.tbInstallDinstanceFromOwner_.Text);
			}
			catch (FormatException)
			{
				MessageBox.Show("Invalid input. Please enter valid numbers.");
			}
		}

		// Token: 0x0400000A RID: 10
		private const int CORNER_RADIUS = 20;

		// Token: 0x0400000B RID: 11
		private Point dragCursorPoint;

		// Token: 0x0400000C RID: 12
		private Point dragFormPoint;

		// Token: 0x04000014 RID: 20
		private static uint storedIDInstanceIdA;

		// Token: 0x04000015 RID: 21
		private static uint storedIDInstanceIdB;

		// Token: 0x04000016 RID: 22
		private static uint storedIDInstanceIdC;

		// Token: 0x04000017 RID: 23
		private static uint storedIDInstanceIdD;
	}
}
