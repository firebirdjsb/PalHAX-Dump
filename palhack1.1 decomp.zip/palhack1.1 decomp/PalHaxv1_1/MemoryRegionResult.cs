﻿using System;

namespace PalHaxv1_1
{
	// Token: 0x02000006 RID: 6
	internal struct MemoryRegionResult
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x060000A3 RID: 163 RVA: 0x0000CED9 File Offset: 0x0000B0D9
		// (set) Token: 0x060000A4 RID: 164 RVA: 0x0000CEE1 File Offset: 0x0000B0E1
		public UIntPtr CurrentBaseAddress { get; set; }

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x060000A5 RID: 165 RVA: 0x0000CEEA File Offset: 0x0000B0EA
		// (set) Token: 0x060000A6 RID: 166 RVA: 0x0000CEF2 File Offset: 0x0000B0F2
		public long RegionSize { get; set; }

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x060000A7 RID: 167 RVA: 0x0000CEFB File Offset: 0x0000B0FB
		// (set) Token: 0x060000A8 RID: 168 RVA: 0x0000CF03 File Offset: 0x0000B103
		public UIntPtr RegionBase { get; set; }
	}
}
