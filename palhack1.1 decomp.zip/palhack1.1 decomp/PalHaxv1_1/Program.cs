﻿using System;
using System.Windows.Forms;

namespace PalHaxv1_1
{
	// Token: 0x02000016 RID: 22
	internal static class Program
	{
		// Token: 0x06000290 RID: 656 RVA: 0x00011677 File Offset: 0x0000F877
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Overlay());
		}
	}
}
