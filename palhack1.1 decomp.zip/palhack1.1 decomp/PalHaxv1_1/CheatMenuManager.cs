﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace PalHaxv1_1
{
	// Token: 0x0200000D RID: 13
	public class CheatMenuManager
	{
		// Token: 0x0600022A RID: 554 RVA: 0x0000EEC9 File Offset: 0x0000D0C9
		public CheatMenuManager(CheatMenu cheatMenu)
		{
			this._cheatMenu = cheatMenu;
		}

		// Token: 0x0600022B RID: 555 RVA: 0x0000EED8 File Offset: 0x0000D0D8
		public void Initialize()
		{
			this.InitializeTabControl();
			this.InitializeFormSize();
			this.InitializeCheckBoxes();
			this.WireEvents();
		}

		// Token: 0x0600022C RID: 556 RVA: 0x0000EEF2 File Offset: 0x0000D0F2
		private void InitializeTabControl()
		{
			this._cheatMenu.CheatMenuTabControl.Height = 372;
		}

		// Token: 0x0600022D RID: 557 RVA: 0x0000EF09 File Offset: 0x0000D109
		private void InitializeFormSize()
		{
			this._cheatMenu.Height = 394;
		}

		// Token: 0x0600022E RID: 558 RVA: 0x0000EF1C File Offset: 0x0000D11C
		private void InitializeCheckBoxes()
		{
			this._cheatMenu.GodmodeBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.SpeedhackBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.SpoofPositionBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.FlymodeBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.CarryWeightBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.SuperJumpBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.ShowWatermarkBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.ShowHotkeyBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.NeverWantedBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.BodyTemperatureDamageBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.NoStomachBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.HealthRegenBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.ShieldRegenBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.AIIgnoreBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.AIChaseBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.OneHitBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.NoStaminaBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.RarePalAppearanceBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.InstaFarmBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.CatchRateBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.NoRespawnDelayBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.EggHatchBox.CheckedChanged += this.CheckBox_CheckedChanged;
		}

		// Token: 0x0600022F RID: 559 RVA: 0x0000F194 File Offset: 0x0000D394
		private void WireEvents()
		{
			this._cheatMenu.MoveArrowPicture.MouseDown += this._cheatMenu.MoveArrowPicture_MouseDown;
			this._cheatMenu.MoveArrowPicture.MouseMove += this._cheatMenu.MoveArrowPicture_MouseMove;
			this._cheatMenu.MoveArrowPicture.MouseUp += this._cheatMenu.MoveArrowPicture_MouseUp;
			this._cheatMenu.SpoofPositionBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.FlymodeBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.SpeedhackBox.CheckedChanged += this.CheckBox_CheckedChanged;
			this._cheatMenu.PlayerTabPageButton.Click += this.Button_Click;
			this._cheatMenu.WeaponTabPageButton.Click += this.Button_Click;
			this._cheatMenu.InventoryTabPageButton.Click += this.Button_Click;
			this._cheatMenu.PalEditorTabPageButton.Click += this.Button_Click;
			this._cheatMenu.WorldTabPageButton.Click += this.Button_Click;
			this._cheatMenu.BaseTabPageButton.Click += this.Button_Click;
			this._cheatMenu.MenuSettingsTabPageButton.Click += this.Button_Click;
		}

		// Token: 0x06000230 RID: 560 RVA: 0x0000F31C File Offset: 0x0000D51C
		public void WireButtonClickEvents()
		{
			this._cheatMenu.GiveTechPointsButton.Click += MenuFeaturesButtonClicks.GiveTechPointsButton_Click;
			this._cheatMenu.MaxStomachButton.Click += MenuFeaturesButtonClicks.MaxStomachButton_Click;
			this._cheatMenu.MaxLevelButton.Click += MenuFeaturesButtonClicks.MaxLevelButton_Click;
			this._cheatMenu.ModWeaponButton.Click += MenuFeaturesButtonClicks.ModWeaponButton_Click;
			this._cheatMenu.GiveGoldButton.Click += MenuFeaturesButtonClicks.GiveGoldButton_Click;
			this._cheatMenu.BaseResetBuildRange.Click += MenuFeaturesButtonClicks.BaseResetBuildRange_Click;
			this._cheatMenu.BaseInfBuildRange.Click += MenuFeaturesButtonClicks.BaseInfBuildRange_Click;
			this._cheatMenu.GiveWoodButton.Click += MenuFeaturesButtonClicks.GiveWoodButton_Click;
			this._cheatMenu.GiveSoulsButton.Click += MenuFeaturesButtonClicks.GiveSoulsButton_Click;
			this._cheatMenu.HealPlayerButton.Click += MenuFeaturesButtonClicks.HealPlayerButton_Click;
			this._cheatMenu.PalMaxLevelButton.Click += MenuFeaturesButtonClicks.PalMaxLevelButton_Click;
			this._cheatMenu.PalMaleButton.Click += MenuFeaturesButtonClicks.PalMaleButton_Click;
			this._cheatMenu.PalFemaleButton.Click += MenuFeaturesButtonClicks.PalFemaleButton_Click;
			this._cheatMenu.SetRarePalButton.Click += MenuFeaturesButtonClicks.SetRarePalButton_Click;
			this._cheatMenu.PalMaxHPButton.Click += MenuFeaturesButtonClicks.PalMaxHPButton_Click;
			this._cheatMenu.PalMaxStomachButton.Click += MenuFeaturesButtonClicks.PalMaxStomachButton_Click;
			this._cheatMenu.PalSanityButton.Click += MenuFeaturesButtonClicks.PalSanityButton_Click;
		}

		// Token: 0x06000231 RID: 561 RVA: 0x0000F505 File Offset: 0x0000D705
		public void WireScrollbarEvents()
		{
			this._cheatMenu.SpeedBar.ValueChanged += MenuFeaturesScrollbar.SpeedBar_ValueChanged;
			this._cheatMenu.SpeedBar2.ValueChanged += MenuFeaturesScrollbar.SpeedBar2_ValueChanged;
		}

		// Token: 0x06000232 RID: 562 RVA: 0x0000F540 File Offset: 0x0000D740
		private void Button_Click(object sender, EventArgs e)
		{
			Button button = sender as Button;
			if (button != null)
			{
				string name = button.Name;
				if (name != null)
				{
					switch (name.Length)
					{
					case 17:
						if (name == "BaseTabPageButton")
						{
							this._cheatMenu.CheatMenuTabControl.SelectedTab = this._cheatMenu.tabPageBase;
							this._cheatMenu.CheatMenuTabControl.Height = 312;
							this._cheatMenu.Height = 365;
						}
						break;
					case 18:
						if (name == "WorldTabPageButton")
						{
							this._cheatMenu.CheatMenuTabControl.SelectedTab = this._cheatMenu.tabPageWorld;
							this._cheatMenu.CheatMenuTabControl.Height = 510;
							this._cheatMenu.Height = 532;
						}
						break;
					case 19:
					{
						char c = name[0];
						if (c != 'P')
						{
							if (c == 'W')
							{
								if (name == "WeaponTabPageButton")
								{
									this._cheatMenu.CheatMenuTabControl.SelectedTab = this._cheatMenu.tabPageWeapon;
									this._cheatMenu.CheatMenuTabControl.Height = 312;
									this._cheatMenu.Height = 365;
								}
							}
						}
						else if (name == "PlayerTabPageButton")
						{
							this._cheatMenu.CheatMenuTabControl.SelectedTab = this._cheatMenu.tabPagePlayer;
							this._cheatMenu.CheatMenuTabControl.Height = 372;
							this._cheatMenu.Height = 394;
						}
						break;
					}
					case 22:
					{
						char c = name[0];
						if (c != 'I')
						{
							if (c == 'P')
							{
								if (name == "PalEditorTabPageButton")
								{
									this._cheatMenu.CheatMenuTabControl.SelectedTab = this._cheatMenu.tabPagePalEditor;
									this._cheatMenu.CheatMenuTabControl.Height = 422;
									this._cheatMenu.Height = 444;
								}
							}
						}
						else if (name == "InventoryTabPageButton")
						{
							this._cheatMenu.CheatMenuTabControl.SelectedTab = this._cheatMenu.tabPageInventory;
							this._cheatMenu.CheatMenuTabControl.Height = 312;
							this._cheatMenu.Height = 365;
						}
						break;
					}
					case 25:
						if (name == "MenuSettingsTabPageButton")
						{
							this._cheatMenu.CheatMenuTabControl.SelectedTab = this._cheatMenu.tabPageMenuSettings;
							this._cheatMenu.CheatMenuTabControl.Height = 312;
							this._cheatMenu.Height = 365;
						}
						break;
					}
				}
				this._cheatMenu.Invalidate();
			}
		}

		// Token: 0x06000233 RID: 563 RVA: 0x0000F848 File Offset: 0x0000DA48
		private void CheckBox_CheckedChanged(object sender, EventArgs e)
		{
			CheckBox checkBox = sender as CheckBox;
			if (checkBox != null)
			{
				if (checkBox.Checked)
				{
					string name = checkBox.Name;
					if (name != null)
					{
						switch (name.Length)
						{
						case 9:
							if (name == "OneHitBox")
							{
								MenuFeaturesCheckbox.HandleOneHitCheckbox(true);
							}
							break;
						case 10:
						{
							char c = name[0];
							if (c != 'A')
							{
								if (c == 'G')
								{
									if (name == "GodmodeBox")
									{
										MenuFeaturesCheckbox.HandleGodmodeCheckbox(true);
									}
								}
							}
							else if (name == "AIChaseBox")
							{
								MenuFeaturesCheckbox.HandleAIChaseCheckbox(true);
							}
							break;
						}
						case 11:
						{
							char c = name[0];
							if (c != 'A')
							{
								if (c == 'E')
								{
									if (name == "EggHatchBox")
									{
										MenuFeaturesCheckbox.HandleEggHatchCheckbox(true);
									}
								}
							}
							else if (name == "AIIgnoreBox")
							{
								MenuFeaturesCheckbox.HandleAIIgnoreCheckbox(true);
							}
							break;
						}
						case 12:
						{
							char c = name[8];
							if (c <= 'h')
							{
								if (c != 'a')
								{
									if (c != 'e')
									{
										if (c == 'h')
										{
											if (name == "NoStomachBox")
											{
												MenuFeaturesCheckbox.HandleNoStomachCheckbox(true);
											}
										}
									}
									else if (name == "CatchRateBox")
									{
										MenuFeaturesCheckbox.HandleCatchRateCheckbox(true);
									}
								}
								else if (name == "NoStaminaBox")
								{
									MenuFeaturesCheckbox.HandleNoStaminaCheckbox(true);
								}
							}
							else if (c != 'k')
							{
								if (c != 'm')
								{
									if (c == 'p')
									{
										if (name == "SuperJumpBox")
										{
											MenuFeaturesCheckbox.HandleSuperJumpCheckbox(true);
										}
									}
								}
								else if (name == "InstaFarmBox")
								{
									MenuFeaturesCheckbox.HandleInstaFarmCheckbox(true);
								}
							}
							else if (name == "SpeedhackBox")
							{
								MenuFeaturesCheckbox.HandleSpeedhackCheckbox(true);
							}
							break;
						}
						case 14:
						{
							char c = name[0];
							if (c <= 'H')
							{
								if (c != 'C')
								{
									if (c == 'H')
									{
										if (name == "HealthRegenBox")
										{
											MenuFeaturesCheckbox.HandleHealthRegenCheckbox(true);
										}
									}
								}
								else if (name == "CarryWeightBox")
								{
									MenuFeaturesCheckbox.HandleCarryWeightCheckbox(true);
								}
							}
							else if (c != 'N')
							{
								if (c == 'S')
								{
									if (name == "ShieldRegenBox")
									{
										MenuFeaturesCheckbox.HandleShieldRegenCheckbox(true);
									}
								}
							}
							else if (name == "NeverWantedBox")
							{
								MenuFeaturesCheckbox.HandleNeverWantedCheckbox(true);
							}
							break;
						}
						case 16:
							if (name == "SpoofPositionBox")
							{
								MenuFeaturesCheckbox.HandleSpoofPositionCheckbox(true);
							}
							break;
						case 17:
							if (name == "NoRespawnDelayBox")
							{
								MenuFeaturesCheckbox.HandleNoRespawnDelayCheckbox(true);
							}
							break;
						case 20:
							if (name == "RarePalAppearanceBox")
							{
								MenuFeaturesCheckbox.HandleRarePalAppearanceCheckbox(true);
							}
							break;
						case 24:
							if (name == "BodyTemperatureDamageBox")
							{
								MenuFeaturesCheckbox.HandleBodyTemperatureDamageCheckbox(true);
							}
							break;
						}
					}
				}
				else
				{
					string name = checkBox.Name;
					if (name != null)
					{
						switch (name.Length)
						{
						case 9:
							if (name == "OneHitBox")
							{
								MenuFeaturesCheckbox.HandleOneHitCheckbox(false);
							}
							break;
						case 10:
						{
							char c = name[0];
							if (c != 'A')
							{
								if (c == 'G')
								{
									if (name == "GodmodeBox")
									{
										MenuFeaturesCheckbox.HandleGodmodeCheckbox(false);
									}
								}
							}
							else if (name == "AIChaseBox")
							{
								MenuFeaturesCheckbox.HandleAIChaseCheckbox(false);
							}
							break;
						}
						case 11:
						{
							char c = name[0];
							if (c != 'A')
							{
								if (c == 'E')
								{
									if (name == "EggHatchBox")
									{
										MenuFeaturesCheckbox.HandleEggHatchCheckbox(false);
									}
								}
							}
							else if (name == "AIIgnoreBox")
							{
								MenuFeaturesCheckbox.HandleAIIgnoreCheckbox(false);
							}
							break;
						}
						case 12:
						{
							char c = name[8];
							if (c <= 'h')
							{
								if (c != 'a')
								{
									if (c != 'e')
									{
										if (c == 'h')
										{
											if (name == "NoStomachBox")
											{
												MenuFeaturesCheckbox.HandleNoStomachCheckbox(false);
											}
										}
									}
									else if (name == "CatchRateBox")
									{
										MenuFeaturesCheckbox.HandleCatchRateCheckbox(false);
									}
								}
								else if (name == "NoStaminaBox")
								{
									MenuFeaturesCheckbox.HandleNoStaminaCheckbox(false);
								}
							}
							else if (c != 'k')
							{
								if (c != 'm')
								{
									if (c == 'p')
									{
										if (name == "SuperJumpBox")
										{
											MenuFeaturesCheckbox.HandleSuperJumpCheckbox(false);
										}
									}
								}
								else if (name == "InstaFarmBox")
								{
									MenuFeaturesCheckbox.HandleInstaFarmCheckbox(false);
								}
							}
							else if (name == "SpeedhackBox")
							{
								MenuFeaturesCheckbox.HandleSpeedhackCheckbox(false);
							}
							break;
						}
						case 14:
						{
							char c = name[0];
							if (c <= 'H')
							{
								if (c != 'C')
								{
									if (c == 'H')
									{
										if (name == "HealthRegenBox")
										{
											MenuFeaturesCheckbox.HandleHealthRegenCheckbox(false);
										}
									}
								}
								else if (name == "CarryWeightBox")
								{
									MenuFeaturesCheckbox.HandleCarryWeightCheckbox(false);
								}
							}
							else if (c != 'N')
							{
								if (c == 'S')
								{
									if (name == "ShieldRegenBox")
									{
										MenuFeaturesCheckbox.HandleShieldRegenCheckbox(false);
									}
								}
							}
							else if (name == "NeverWantedBox")
							{
								MenuFeaturesCheckbox.HandleNeverWantedCheckbox(false);
							}
							break;
						}
						case 16:
							if (name == "SpoofPositionBox")
							{
								MenuFeaturesCheckbox.HandleSpoofPositionCheckbox(false);
							}
							break;
						case 17:
							if (name == "NoRespawnDelayBox")
							{
								MenuFeaturesCheckbox.HandleNoRespawnDelayCheckbox(false);
							}
							break;
						case 20:
							if (name == "RarePalAppearanceBox")
							{
								MenuFeaturesCheckbox.HandleRarePalAppearanceCheckbox(false);
							}
							break;
						case 24:
							if (name == "BodyTemperatureDamageBox")
							{
								MenuFeaturesCheckbox.HandleBodyTemperatureDamageCheckbox(false);
							}
							break;
						}
					}
				}
				checkBox.ForeColor = (checkBox.Checked ? Color.Green : Color.Red);
			}
		}

		// Token: 0x0400017B RID: 379
		private CheatMenu _cheatMenu;
	}
}
