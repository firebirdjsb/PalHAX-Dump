﻿using System;
using System.Windows.Forms;

namespace PalHaxv1_1
{
	// Token: 0x02000014 RID: 20
	public static class TextboxValueHandler
	{
		// Token: 0x06000263 RID: 611 RVA: 0x000104B8 File Offset: 0x0000E6B8
		public static void UpdateStackCountsFromTextBoxes(TextBox textBox1, TextBox textBox2, TextBox textBox3, TextBox textBox4, TextBox textBox5)
		{
			try
			{
				Offsets.StackCount1 = int.Parse(textBox1.Text);
				Offsets.StackCount2 = int.Parse(textBox2.Text);
				Offsets.StackCount3 = int.Parse(textBox3.Text);
				Offsets.StackCount4 = int.Parse(textBox4.Text);
				Offsets.StackCount5 = int.Parse(textBox5.Text);
			}
			catch (FormatException)
			{
				MessageBox.Show("Invalid input. Please enter valid numbers.");
			}
		}

		// Token: 0x06000264 RID: 612 RVA: 0x00010538 File Offset: 0x0000E738
		public static void UpdateTextBoxesFromStackCounts(TextBox textBox1, TextBox textBox2, TextBox textBox3, TextBox textBox4, TextBox textBox5)
		{
			textBox1.Text = Offsets.StackCount1.ToString();
			textBox2.Text = Offsets.StackCount2.ToString();
			textBox3.Text = Offsets.StackCount3.ToString();
			textBox4.Text = Offsets.StackCount4.ToString();
			textBox5.Text = Offsets.StackCount5.ToString();
		}

		// Token: 0x06000265 RID: 613 RVA: 0x000105A8 File Offset: 0x0000E7A8
		public static void UpdateStatsTextBoxes(TextBox tbStatusPointPerLevel_, TextBox tbAddMaxHPPerStatusPoint_, TextBox tbAddMaxSPPerStatusPoint_, TextBox tbAddPowerPerStatusPoint_, TextBox tbAddMaxInventoryWeightPerStatusPoint_, TextBox tbAddCaptureLevelPerStatusPoint_, TextBox tbAddWorkSpeedPerStatusPoint_, TextBox tbAddMaxHPPerHPRank_, TextBox tbAddAttackPerAttackRank_, TextBox tbAddDefencePerDefenceRank_, TextBox tbAddWorkSpeedPerWorkSpeedRank_, TextBox tbTechnologyPoint_UnlockFastTravel_)
		{
			tbStatusPointPerLevel_.Text = Offsets.StatusPointPerLevel.ToString("D");
			tbAddMaxHPPerStatusPoint_.Text = Offsets.AddMaxHPPerStatusPoint.ToString("F4");
			tbAddMaxSPPerStatusPoint_.Text = Offsets.AddMaxSPPerStatusPoint.ToString("F4");
			tbAddPowerPerStatusPoint_.Text = Offsets.AddPowerPerStatusPoint.ToString("F4");
			tbAddMaxInventoryWeightPerStatusPoint_.Text = Offsets.AddMaxInventoryWeightPerStatusPoint.ToString("F4");
			tbAddCaptureLevelPerStatusPoint_.Text = Offsets.AddCaptureLevelPerStatusPoint.ToString("F4");
			tbAddWorkSpeedPerStatusPoint_.Text = Offsets.AddWorkSpeedPerStatusPoint.ToString("F4");
			tbAddMaxHPPerHPRank_.Text = Offsets.AddMaxHPPerHPRank.ToString("F4");
			tbAddAttackPerAttackRank_.Text = Offsets.AddAttackPerAttackRank.ToString("F4");
			tbAddDefencePerDefenceRank_.Text = Offsets.AddDefencePerDefenceRank.ToString("F4");
			tbAddWorkSpeedPerWorkSpeedRank_.Text = Offsets.AddWorkSpeedPerWorkSpeedRank.ToString("F4");
			tbTechnologyPoint_UnlockFastTravel_.Text = Offsets.TechnologyPointUnlockFastTravel.ToString("D");
		}

		// Token: 0x06000266 RID: 614 RVA: 0x000106E0 File Offset: 0x0000E8E0
		public static void SetStatsFromTextBoxes(TextBox tbStatusPointPerLevel_, TextBox tbAddMaxHPPerStatusPoint_, TextBox tbAddMaxSPPerStatusPoint_, TextBox tbAddPowerPerStatusPoint_, TextBox tbAddMaxInventoryWeightPerStatusPoint_, TextBox tbAddCaptureLevelPerStatusPoint_, TextBox tbAddWorkSpeedPerStatusPoint_, TextBox tbAddMaxHPPerHPRank_, TextBox tbAddAttackPerAttackRank_, TextBox tbAddDefencePerDefenceRank_, TextBox tbAddWorkSpeedPerWorkSpeedRank_, TextBox tbTechnologyPoint_UnlockFastTravel_)
		{
			try
			{
				Offsets.StatusPointPerLevel = int.Parse(tbStatusPointPerLevel_.Text);
				Offsets.AddMaxHPPerStatusPoint = float.Parse(tbAddMaxHPPerStatusPoint_.Text);
				Offsets.AddMaxSPPerStatusPoint = float.Parse(tbAddMaxSPPerStatusPoint_.Text);
				Offsets.AddPowerPerStatusPoint = float.Parse(tbAddPowerPerStatusPoint_.Text);
				Offsets.AddMaxInventoryWeightPerStatusPoint = float.Parse(tbAddMaxInventoryWeightPerStatusPoint_.Text);
				Offsets.AddCaptureLevelPerStatusPoint = float.Parse(tbAddCaptureLevelPerStatusPoint_.Text);
				Offsets.AddWorkSpeedPerStatusPoint = float.Parse(tbAddWorkSpeedPerStatusPoint_.Text);
				Offsets.AddMaxHPPerHPRank = float.Parse(tbAddMaxHPPerHPRank_.Text);
				Offsets.AddAttackPerAttackRank = float.Parse(tbAddAttackPerAttackRank_.Text);
				Offsets.AddDefencePerDefenceRank = float.Parse(tbAddDefencePerDefenceRank_.Text);
				Offsets.AddWorkSpeedPerWorkSpeedRank = float.Parse(tbAddWorkSpeedPerWorkSpeedRank_.Text);
				Offsets.TechnologyPointUnlockFastTravel = int.Parse(tbTechnologyPoint_UnlockFastTravel_.Text);
			}
			catch (FormatException)
			{
				MessageBox.Show("Invalid input. Please enter valid numbers.");
			}
		}

		// Token: 0x06000267 RID: 615 RVA: 0x000107D8 File Offset: 0x0000E9D8
		public static void UpdateXPTextBoxes(TextBox tbBuildXP_, TextBox tbCraftXP_, TextBox tbPickupItemOnLevelExp_, TextBox tbMapObjectDestroyProceedExp_)
		{
			tbBuildXP_.Text = Offsets.BuildXP.ToString("D");
			tbCraftXP_.Text = Offsets.CraftXP.ToString("D");
			tbPickupItemOnLevelExp_.Text = Offsets.PickupItemOnLevelExp.ToString("D");
			tbMapObjectDestroyProceedExp_.Text = Offsets.MapObjectDestroyProceedExp.ToString("D");
		}

		// Token: 0x06000268 RID: 616 RVA: 0x00010848 File Offset: 0x0000EA48
		public static void SetXPFromTextBoxes(TextBox tbBuildXP_, TextBox tbCraftXP_, TextBox tbPickupItemOnLevelExp_, TextBox tbMapObjectDestroyProceedExp_)
		{
			Offsets.BuildXP = int.Parse(tbBuildXP_.Text);
			Offsets.CraftXP = int.Parse(tbCraftXP_.Text);
			Offsets.PickupItemOnLevelExp = int.Parse(tbPickupItemOnLevelExp_.Text);
			Offsets.MapObjectDestroyProceedExp = int.Parse(tbMapObjectDestroyProceedExp_.Text);
		}
	}
}
