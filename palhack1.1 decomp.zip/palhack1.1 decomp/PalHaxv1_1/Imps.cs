﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace PalHaxv1_1
{
	// Token: 0x02000005 RID: 5
	public class Imps
	{
		// Token: 0x0600007A RID: 122
		[DllImport("user32.dll")]
		public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

		// Token: 0x0600007B RID: 123
		[DllImport("kernel32.dll")]
		public static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

		// Token: 0x0600007C RID: 124
		[DllImport("kernel32.dll", EntryPoint = "VirtualQueryEx")]
		public static extern UIntPtr Native_VirtualQueryEx(IntPtr hProcess, UIntPtr lpAddress, out Imps.MEMORY_BASIC_INFORMATION32 lpBuffer, UIntPtr dwLength);

		// Token: 0x0600007D RID: 125
		[DllImport("kernel32.dll", EntryPoint = "VirtualQueryEx")]
		public static extern UIntPtr Native_VirtualQueryEx(IntPtr hProcess, UIntPtr lpAddress, out Imps.MEMORY_BASIC_INFORMATION64 lpBuffer, UIntPtr dwLength);

		// Token: 0x0600007E RID: 126
		[DllImport("kernel32.dll")]
		private static extern uint GetLastError();

		// Token: 0x0600007F RID: 127
		[DllImport("kernel32.dll")]
		public static extern void GetSystemInfo(out Imps.SYSTEM_INFO lpSystemInfo);

		// Token: 0x06000080 RID: 128
		[DllImport("kernel32.dll")]
		public static extern IntPtr OpenThread(Imps.ThreadAccess dwDesiredAccess, bool bInheritHandle, uint dwThreadId);

		// Token: 0x06000081 RID: 129
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern int SuspendThread(IntPtr hThread);

		// Token: 0x06000082 RID: 130
		[DllImport("kernel32.dll")]
		public static extern int ResumeThread(IntPtr hThread);

		// Token: 0x06000083 RID: 131
		[DllImport("dbghelp.dll")]
		private static extern bool MiniDumpWriteDump(IntPtr hProcess, int ProcessId, IntPtr hFile, Imps.MINIDUMP_TYPE DumpType, IntPtr ExceptionParam, IntPtr UserStreamParam, IntPtr CallackParam);

		// Token: 0x06000084 RID: 132
		[DllImport("user32.dll", SetLastError = true)]
		public static extern int GetWindowLong(IntPtr hWnd, int nIndex);

		// Token: 0x06000085 RID: 133
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		public static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr w, IntPtr l);

		// Token: 0x06000086 RID: 134
		[DllImport("kernel32.dll")]
		public static extern bool WriteProcessMemory(IntPtr hProcess, UIntPtr lpBaseAddress, string lpBuffer, UIntPtr nSize, out IntPtr lpNumberOfBytesWritten);

		// Token: 0x06000087 RID: 135
		[DllImport("kernel32.dll")]
		public static extern int GetProcessId(IntPtr handle);

		// Token: 0x06000088 RID: 136
		[DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
		public static extern uint GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, uint nSize, string lpFileName);

		// Token: 0x06000089 RID: 137
		[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
		public static extern bool VirtualFreeEx(IntPtr hProcess, UIntPtr lpAddress, UIntPtr dwSize, uint dwFreeType);

		// Token: 0x0600008A RID: 138
		[DllImport("psapi.dll")]
		private static extern uint GetModuleFileNameEx(IntPtr hProcess, IntPtr hModule, [Out] StringBuilder lpBaseName, [MarshalAs(UnmanagedType.U4)] [In] int nSize);

		// Token: 0x0600008B RID: 139
		[DllImport("psapi.dll", SetLastError = true)]
		public static extern bool EnumProcessModules(IntPtr hProcess, [Out] IntPtr lphModule, uint cb, [MarshalAs(UnmanagedType.U4)] out uint lpcbNeeded);

		// Token: 0x0600008C RID: 140
		[DllImport("kernel32.dll")]
		public static extern bool ReadProcessMemory(IntPtr hProcess, UIntPtr lpBaseAddress, [Out] byte[] lpBuffer, UIntPtr nSize, IntPtr lpNumberOfBytesRead);

		// Token: 0x0600008D RID: 141
		[DllImport("kernel32.dll")]
		public static extern bool ReadProcessMemory(IntPtr hProcess, UIntPtr lpBaseAddress, [Out] byte[] lpBuffer, UIntPtr nSize, out ulong lpNumberOfBytesRead);

		// Token: 0x0600008E RID: 142
		[DllImport("kernel32.dll")]
		public static extern bool ReadProcessMemory(IntPtr hProcess, UIntPtr lpBaseAddress, [Out] IntPtr lpBuffer, UIntPtr nSize, out ulong lpNumberOfBytesRead);

		// Token: 0x0600008F RID: 143
		[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
		public static extern UIntPtr VirtualAllocEx(IntPtr hProcess, UIntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

		// Token: 0x06000090 RID: 144
		[DllImport("kernel32.dll")]
		public static extern bool VirtualProtectEx(IntPtr hProcess, UIntPtr lpAddress, IntPtr dwSize, Imps.MemoryProtection flNewProtect, out Imps.MemoryProtection lpflOldProtect);

		// Token: 0x06000091 RID: 145
		[DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true)]
		public static extern UIntPtr GetProcAddress(IntPtr hModule, string procName);

		// Token: 0x06000092 RID: 146
		[DllImport("kernel32.dll", EntryPoint = "CloseHandle")]
		private static extern bool _CloseHandle(IntPtr hObject);

		// Token: 0x06000093 RID: 147
		[DllImport("kernel32.dll")]
		public static extern int CloseHandle(IntPtr hObject);

		// Token: 0x06000094 RID: 148
		[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
		public static extern IntPtr GetModuleHandle(string lpModuleName);

		// Token: 0x06000095 RID: 149
		[DllImport("kernel32", ExactSpelling = true, SetLastError = true)]
		internal static extern int WaitForSingleObject(IntPtr handle, int milliseconds);

		// Token: 0x06000096 RID: 150
		[DllImport("kernel32.dll")]
		public static extern bool WriteProcessMemory(IntPtr hProcess, UIntPtr lpBaseAddress, byte[] lpBuffer, UIntPtr nSize, IntPtr lpNumberOfBytesWritten);

		// Token: 0x06000097 RID: 151
		[DllImport("kernel32.dll")]
		public static extern bool WriteProcessMemory(IntPtr hProcess, UIntPtr lpBaseAddress, byte[] lpBuffer, UIntPtr nSize, out IntPtr lpNumberOfBytesWritten);

		// Token: 0x06000098 RID: 152
		[DllImport("kernel32")]
		public static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, UIntPtr lpStartAddress, UIntPtr lpParameter, uint dwCreationFlags, out IntPtr lpThreadId);

		// Token: 0x06000099 RID: 153
		[DllImport("kernel32")]
		public static extern bool IsWow64Process(IntPtr hProcess, out bool lpSystemInfo);

		// Token: 0x0600009A RID: 154
		[DllImport("user32.dll")]
		public static extern bool SetForegroundWindow(IntPtr hWnd);

		// Token: 0x0600009B RID: 155
		[DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern IntPtr CreateToolhelp32Snapshot([In] uint dwFlags, [In] uint th32ProcessID);

		// Token: 0x0600009C RID: 156
		[DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool Process32First([In] IntPtr hSnapshot, ref Imps.PROCESSENTRY32 lppe);

		// Token: 0x0600009D RID: 157
		[DllImport("kernel32.dll")]
		public static extern bool Module32First(IntPtr hSnapshot, ref Imps.MODULEENTRY32 lpme);

		// Token: 0x0600009E RID: 158
		[DllImport("kernel32.dll")]
		public static extern bool Module32Next(IntPtr hSnapshot, ref Imps.MODULEENTRY32 lpme);

		// Token: 0x0600009F RID: 159
		[DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool Process32Next([In] IntPtr hSnapshot, ref Imps.PROCESSENTRY32 lppe);

		// Token: 0x060000A0 RID: 160
		[DllImport("ntdll.dll", SetLastError = true)]
		internal static extern Imps.NTSTATUS NtCreateThreadEx(out IntPtr hProcess, Imps.AccessMask desiredAccess, IntPtr objectAttributes, UIntPtr processHandle, IntPtr startAddress, IntPtr parameter, Imps.ThreadCreationFlags inCreateSuspended, int stackZeroBits, int sizeOfStack, int maximumStackSize, IntPtr attributeList);

		// Token: 0x060000A1 RID: 161
		[DllImport("ntdll.dll", SetLastError = true)]
		internal static extern int NtQueryInformationThread(IntPtr threadHandle, Imps.ThreadInfoClass threadInformationClass, IntPtr threadInformation, int threadInformationLength, IntPtr returnLengthPtr);

		// Token: 0x040000AE RID: 174
		public const int PROCESS_CREATE_THREAD = 2;

		// Token: 0x040000AF RID: 175
		public const int PROCESS_QUERY_INFORMATION = 1024;

		// Token: 0x040000B0 RID: 176
		public const int PROCESS_VM_OPERATION = 8;

		// Token: 0x040000B1 RID: 177
		public const int PROCESS_VM_WRITE = 32;

		// Token: 0x040000B2 RID: 178
		public const int PROCESS_VM_READ = 16;

		// Token: 0x040000B3 RID: 179
		public const uint MEM_FREE = 65536U;

		// Token: 0x040000B4 RID: 180
		public const uint MEM_COMMIT = 4096U;

		// Token: 0x040000B5 RID: 181
		public const uint MEM_RESERVE = 8192U;

		// Token: 0x040000B6 RID: 182
		public const uint PAGE_READONLY = 2U;

		// Token: 0x040000B7 RID: 183
		public const uint PAGE_READWRITE = 4U;

		// Token: 0x040000B8 RID: 184
		public const uint PAGE_WRITECOPY = 8U;

		// Token: 0x040000B9 RID: 185
		public const uint PAGE_EXECUTE_READWRITE = 64U;

		// Token: 0x040000BA RID: 186
		public const uint PAGE_EXECUTE_WRITECOPY = 128U;

		// Token: 0x040000BB RID: 187
		public const uint PAGE_EXECUTE = 16U;

		// Token: 0x040000BC RID: 188
		public const uint PAGE_EXECUTE_READ = 32U;

		// Token: 0x040000BD RID: 189
		public const uint PAGE_GUARD = 256U;

		// Token: 0x040000BE RID: 190
		public const uint PAGE_NOACCESS = 1U;

		// Token: 0x040000BF RID: 191
		public const uint MEM_PRIVATE = 131072U;

		// Token: 0x040000C0 RID: 192
		public const uint MEM_IMAGE = 16777216U;

		// Token: 0x02000021 RID: 33
		internal enum NTSTATUS
		{
			// Token: 0x040001B6 RID: 438
			Success
		}

		// Token: 0x02000022 RID: 34
		internal enum AccessMask
		{
			// Token: 0x040001B8 RID: 440
			SpecificRightsAll = 65535,
			// Token: 0x040001B9 RID: 441
			StandardRightsAll = 2031616
		}

		// Token: 0x02000023 RID: 35
		internal enum ThreadCreationFlags
		{
			// Token: 0x040001BB RID: 443
			Immediately,
			// Token: 0x040001BC RID: 444
			CreateSuspended,
			// Token: 0x040001BD RID: 445
			HideFromDebugger = 4,
			// Token: 0x040001BE RID: 446
			StackSizeParamIsAReservation = 65536
		}

		// Token: 0x02000024 RID: 36
		internal enum MINIDUMP_TYPE
		{
			// Token: 0x040001C0 RID: 448
			MiniDumpNormal,
			// Token: 0x040001C1 RID: 449
			MiniDumpWithDataSegs,
			// Token: 0x040001C2 RID: 450
			MiniDumpWithFullMemory,
			// Token: 0x040001C3 RID: 451
			MiniDumpWithHandleData = 4,
			// Token: 0x040001C4 RID: 452
			MiniDumpFilterMemory = 8,
			// Token: 0x040001C5 RID: 453
			MiniDumpScanMemory = 16,
			// Token: 0x040001C6 RID: 454
			MiniDumpWithUnloadedModules = 32,
			// Token: 0x040001C7 RID: 455
			MiniDumpWithIndirectlyReferencedMemory = 64,
			// Token: 0x040001C8 RID: 456
			MiniDumpFilterModulePaths = 128,
			// Token: 0x040001C9 RID: 457
			MiniDumpWithProcessThreadData = 256,
			// Token: 0x040001CA RID: 458
			MiniDumpWithPrivateReadWriteMemory = 512,
			// Token: 0x040001CB RID: 459
			MiniDumpWithoutOptionalData = 1024,
			// Token: 0x040001CC RID: 460
			MiniDumpWithFullMemoryInfo = 2048,
			// Token: 0x040001CD RID: 461
			MiniDumpWithThreadInfo = 4096,
			// Token: 0x040001CE RID: 462
			MiniDumpWithCodeSegs = 8192
		}

		// Token: 0x02000025 RID: 37
		public struct SYSTEM_INFO
		{
			// Token: 0x040001CF RID: 463
			public ushort processorArchitecture;

			// Token: 0x040001D0 RID: 464
			private ushort reserved;

			// Token: 0x040001D1 RID: 465
			public uint pageSize;

			// Token: 0x040001D2 RID: 466
			public UIntPtr minimumApplicationAddress;

			// Token: 0x040001D3 RID: 467
			public UIntPtr maximumApplicationAddress;

			// Token: 0x040001D4 RID: 468
			public IntPtr activeProcessorMask;

			// Token: 0x040001D5 RID: 469
			public uint numberOfProcessors;

			// Token: 0x040001D6 RID: 470
			public uint processorType;

			// Token: 0x040001D7 RID: 471
			public uint allocationGranularity;

			// Token: 0x040001D8 RID: 472
			public ushort processorLevel;

			// Token: 0x040001D9 RID: 473
			public ushort processorRevision;
		}

		// Token: 0x02000026 RID: 38
		public struct MEMORY_BASIC_INFORMATION32
		{
			// Token: 0x040001DA RID: 474
			public UIntPtr BaseAddress;

			// Token: 0x040001DB RID: 475
			public UIntPtr AllocationBase;

			// Token: 0x040001DC RID: 476
			public uint AllocationProtect;

			// Token: 0x040001DD RID: 477
			public uint RegionSize;

			// Token: 0x040001DE RID: 478
			public uint State;

			// Token: 0x040001DF RID: 479
			public uint Protect;

			// Token: 0x040001E0 RID: 480
			public uint Type;
		}

		// Token: 0x02000027 RID: 39
		public struct MEMORY_BASIC_INFORMATION64
		{
			// Token: 0x040001E1 RID: 481
			public UIntPtr BaseAddress;

			// Token: 0x040001E2 RID: 482
			public UIntPtr AllocationBase;

			// Token: 0x040001E3 RID: 483
			public uint AllocationProtect;

			// Token: 0x040001E4 RID: 484
			public uint __alignment1;

			// Token: 0x040001E5 RID: 485
			public ulong RegionSize;

			// Token: 0x040001E6 RID: 486
			public uint State;

			// Token: 0x040001E7 RID: 487
			public uint Protect;

			// Token: 0x040001E8 RID: 488
			public uint Type;

			// Token: 0x040001E9 RID: 489
			public uint __alignment2;
		}

		// Token: 0x02000028 RID: 40
		public struct MEMORY_BASIC_INFORMATION
		{
			// Token: 0x040001EA RID: 490
			public UIntPtr BaseAddress;

			// Token: 0x040001EB RID: 491
			public UIntPtr AllocationBase;

			// Token: 0x040001EC RID: 492
			public uint AllocationProtect;

			// Token: 0x040001ED RID: 493
			public long RegionSize;

			// Token: 0x040001EE RID: 494
			public uint State;

			// Token: 0x040001EF RID: 495
			public uint Protect;

			// Token: 0x040001F0 RID: 496
			public uint Type;
		}

		// Token: 0x02000029 RID: 41
		private enum SnapshotFlags : uint
		{
			// Token: 0x040001F2 RID: 498
			HeapList = 1U,
			// Token: 0x040001F3 RID: 499
			Process,
			// Token: 0x040001F4 RID: 500
			Thread = 4U,
			// Token: 0x040001F5 RID: 501
			Module = 8U,
			// Token: 0x040001F6 RID: 502
			Module32 = 16U,
			// Token: 0x040001F7 RID: 503
			Inherit = 2147483648U,
			// Token: 0x040001F8 RID: 504
			All = 31U,
			// Token: 0x040001F9 RID: 505
			NoHeaps = 1073741824U
		}

		// Token: 0x0200002A RID: 42
		[Flags]
		public enum ThreadAccess
		{
			// Token: 0x040001FB RID: 507
			TERMINATE = 1,
			// Token: 0x040001FC RID: 508
			SUSPEND_RESUME = 2,
			// Token: 0x040001FD RID: 509
			GET_CONTEXT = 8,
			// Token: 0x040001FE RID: 510
			SET_CONTEXT = 16,
			// Token: 0x040001FF RID: 511
			SET_INFORMATION = 32,
			// Token: 0x04000200 RID: 512
			QUERY_INFORMATION = 64,
			// Token: 0x04000201 RID: 513
			SET_THREAD_TOKEN = 128,
			// Token: 0x04000202 RID: 514
			IMPERSONATE = 256,
			// Token: 0x04000203 RID: 515
			DIRECT_IMPERSONATION = 512
		}

		// Token: 0x0200002B RID: 43
		[Flags]
		public enum MemoryProtection : uint
		{
			// Token: 0x04000205 RID: 517
			Execute = 16U,
			// Token: 0x04000206 RID: 518
			ExecuteRead = 32U,
			// Token: 0x04000207 RID: 519
			ExecuteReadWrite = 64U,
			// Token: 0x04000208 RID: 520
			ExecuteWriteCopy = 128U,
			// Token: 0x04000209 RID: 521
			NoAccess = 1U,
			// Token: 0x0400020A RID: 522
			ReadOnly = 2U,
			// Token: 0x0400020B RID: 523
			ReadWrite = 4U,
			// Token: 0x0400020C RID: 524
			WriteCopy = 8U,
			// Token: 0x0400020D RID: 525
			GuardModifierflag = 256U,
			// Token: 0x0400020E RID: 526
			NoCacheModifierflag = 512U,
			// Token: 0x0400020F RID: 527
			WriteCombineModifierflag = 1024U
		}

		// Token: 0x0200002C RID: 44
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
		private struct PROCESSENTRY32
		{
			// Token: 0x04000210 RID: 528
			private const int MAX_PATH = 260;

			// Token: 0x04000211 RID: 529
			internal uint dwSize;

			// Token: 0x04000212 RID: 530
			internal uint cntUsage;

			// Token: 0x04000213 RID: 531
			internal uint th32ProcessID;

			// Token: 0x04000214 RID: 532
			internal IntPtr th32DefaultHeapID;

			// Token: 0x04000215 RID: 533
			internal uint th32ModuleID;

			// Token: 0x04000216 RID: 534
			internal uint cntThreads;

			// Token: 0x04000217 RID: 535
			internal uint th32ParentProcessID;

			// Token: 0x04000218 RID: 536
			internal int pcPriClassBase;

			// Token: 0x04000219 RID: 537
			internal uint dwFlags;

			// Token: 0x0400021A RID: 538
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
			internal string szExeFile;
		}

		// Token: 0x0200002D RID: 45
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
		public struct MODULEENTRY32
		{
			// Token: 0x0400021B RID: 539
			internal uint dwSize;

			// Token: 0x0400021C RID: 540
			internal uint th32ModuleID;

			// Token: 0x0400021D RID: 541
			internal uint th32ProcessID;

			// Token: 0x0400021E RID: 542
			internal uint GlblcntUsage;

			// Token: 0x0400021F RID: 543
			internal uint ProccntUsage;

			// Token: 0x04000220 RID: 544
			internal IntPtr modBaseAddr;

			// Token: 0x04000221 RID: 545
			internal uint modBaseSize;

			// Token: 0x04000222 RID: 546
			internal IntPtr hModule;

			// Token: 0x04000223 RID: 547
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
			internal string szModule;

			// Token: 0x04000224 RID: 548
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
			internal string szExePath;
		}

		// Token: 0x0200002E RID: 46
		public enum ThreadInfoClass
		{
			// Token: 0x04000226 RID: 550
			ThreadQuerySetWin32StartAddress = 9
		}
	}
}
