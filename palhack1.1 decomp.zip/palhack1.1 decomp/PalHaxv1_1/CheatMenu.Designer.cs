﻿namespace PalHaxv1_1
{
	// Token: 0x02000003 RID: 3
	public partial class CheatMenu : global::System.Windows.Forms.Form
	{
		// Token: 0x0600003B RID: 59 RVA: 0x00002BF0 File Offset: 0x00000DF0
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600003C RID: 60 RVA: 0x00002C10 File Offset: 0x00000E10
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::PalHaxv1_1.CheatMenu));
			this.MoveArrowPicture = new global::System.Windows.Forms.PictureBox();
			this.PlayerTabPageButton = new global::System.Windows.Forms.Button();
			this.WeaponTabPageButton = new global::System.Windows.Forms.Button();
			this.CheatMenuTabControl = new global::System.Windows.Forms.TabControl();
			this.tabPagePlayer = new global::System.Windows.Forms.TabPage();
			this.EggHatchBox = new global::System.Windows.Forms.CheckBox();
			this.groupBox2 = new global::System.Windows.Forms.GroupBox();
			this.SpoofPositionBox = new global::System.Windows.Forms.CheckBox();
			this.SpeedBar = new global::System.Windows.Forms.TrackBar();
			this.LTimeDilation2 = new global::System.Windows.Forms.Label();
			this.NoRespawnDelayBox = new global::System.Windows.Forms.CheckBox();
			this.SpeedBar2 = new global::System.Windows.Forms.TrackBar();
			this.LTimeDilation = new global::System.Windows.Forms.Label();
			this.NoStaminaBox = new global::System.Windows.Forms.CheckBox();
			this.CarryWeightBox = new global::System.Windows.Forms.CheckBox();
			this.OneHitBox = new global::System.Windows.Forms.CheckBox();
			this.SuperJumpBox = new global::System.Windows.Forms.CheckBox();
			this.SpeedhackBox = new global::System.Windows.Forms.CheckBox();
			this.FlymodeBox = new global::System.Windows.Forms.CheckBox();
			this.HealPlayerButton = new global::System.Windows.Forms.Button();
			this.MaxLevelButton = new global::System.Windows.Forms.Button();
			this.MaxStomachButton = new global::System.Windows.Forms.Button();
			this.GiveTechPointsButton = new global::System.Windows.Forms.Button();
			this.ShieldRegenBox = new global::System.Windows.Forms.CheckBox();
			this.HealthRegenBox = new global::System.Windows.Forms.CheckBox();
			this.AIChaseBox = new global::System.Windows.Forms.CheckBox();
			this.AIIgnoreBox = new global::System.Windows.Forms.CheckBox();
			this.NoStomachBox = new global::System.Windows.Forms.CheckBox();
			this.BodyTemperatureDamageBox = new global::System.Windows.Forms.CheckBox();
			this.NeverWantedBox = new global::System.Windows.Forms.CheckBox();
			this.GodmodeBox = new global::System.Windows.Forms.CheckBox();
			this.tabPageWeapon = new global::System.Windows.Forms.TabPage();
			this.groupBox8 = new global::System.Windows.Forms.GroupBox();
			this.ModWeaponButton = new global::System.Windows.Forms.Button();
			this.tabPageInventory = new global::System.Windows.Forms.TabPage();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.label3 = new global::System.Windows.Forms.Label();
			this.label12 = new global::System.Windows.Forms.Label();
			this.GiveGoldButton = new global::System.Windows.Forms.Button();
			this.GiveSoulsButton = new global::System.Windows.Forms.Button();
			this.GiveWoodButton = new global::System.Windows.Forms.Button();
			this.gbItemSlotStack = new global::System.Windows.Forms.GroupBox();
			this.tbStackCount5_ = new global::System.Windows.Forms.TextBox();
			this.SetInvStatsButton = new global::System.Windows.Forms.Button();
			this.GetInvStatsButton = new global::System.Windows.Forms.Button();
			this.label22 = new global::System.Windows.Forms.Label();
			this.tbStackCount4_ = new global::System.Windows.Forms.TextBox();
			this.label23 = new global::System.Windows.Forms.Label();
			this.tbStackCount_ = new global::System.Windows.Forms.TextBox();
			this.tbStackCount3_ = new global::System.Windows.Forms.TextBox();
			this.LSlot3 = new global::System.Windows.Forms.Label();
			this.LSlot1 = new global::System.Windows.Forms.Label();
			this.tbStackCount2_ = new global::System.Windows.Forms.TextBox();
			this.LSlot2 = new global::System.Windows.Forms.Label();
			this.tabPagePalEditor = new global::System.Windows.Forms.TabPage();
			this.groupBox4 = new global::System.Windows.Forms.GroupBox();
			this.PalSanityButton = new global::System.Windows.Forms.Button();
			this.groupBox7 = new global::System.Windows.Forms.GroupBox();
			this.SetPalInstanceID = new global::System.Windows.Forms.Button();
			this.GetPalInstanceID = new global::System.Windows.Forms.Button();
			this.SetRarePalButton = new global::System.Windows.Forms.Button();
			this.PalMaxHPButton = new global::System.Windows.Forms.Button();
			this.groupBox5 = new global::System.Windows.Forms.GroupBox();
			this.SetPalAttackButton = new global::System.Windows.Forms.Button();
			this.label5 = new global::System.Windows.Forms.Label();
			this.tbEquipWazaAttackSlot1_ = new global::System.Windows.Forms.TextBox();
			this.label4 = new global::System.Windows.Forms.Label();
			this.tbEquipWazaAttackSlot2_ = new global::System.Windows.Forms.TextBox();
			this.tbEquipWazaAttackSlot3_ = new global::System.Windows.Forms.TextBox();
			this.GetPalAttackButton = new global::System.Windows.Forms.Button();
			this.label6 = new global::System.Windows.Forms.Label();
			this.groupBox6 = new global::System.Windows.Forms.GroupBox();
			this.tbSPSupport_ = new global::System.Windows.Forms.TextBox();
			this.label10 = new global::System.Windows.Forms.Label();
			this.SetPalStatsButton = new global::System.Windows.Forms.Button();
			this.tbSPRankCraftSpeed_ = new global::System.Windows.Forms.TextBox();
			this.label9 = new global::System.Windows.Forms.Label();
			this.tbSPRankDefence_ = new global::System.Windows.Forms.TextBox();
			this.label8 = new global::System.Windows.Forms.Label();
			this.tbSPRankAttack_ = new global::System.Windows.Forms.TextBox();
			this.label7 = new global::System.Windows.Forms.Label();
			this.GetPalStatsButton = new global::System.Windows.Forms.Button();
			this.PalMaxLevelButton = new global::System.Windows.Forms.Button();
			this.PalFemaleButton = new global::System.Windows.Forms.Button();
			this.PalMaleButton = new global::System.Windows.Forms.Button();
			this.PalMaxStomachButton = new global::System.Windows.Forms.Button();
			this.tabPageWorld = new global::System.Windows.Forms.TabPage();
			this.groupBox3 = new global::System.Windows.Forms.GroupBox();
			this.gbPlayerStats = new global::System.Windows.Forms.GroupBox();
			this.LTechnologyPointUnlockFastTravel = new global::System.Windows.Forms.Label();
			this.GetStatsButton = new global::System.Windows.Forms.Button();
			this.SetStatsButton = new global::System.Windows.Forms.Button();
			this.tbTechnologyPoint_UnlockFastTravel_ = new global::System.Windows.Forms.TextBox();
			this.LAddMaxHPPerStatusPoint = new global::System.Windows.Forms.Label();
			this.tbAddMaxHPPerStatusPoint_ = new global::System.Windows.Forms.TextBox();
			this.tbStatusPointPerLevel_ = new global::System.Windows.Forms.TextBox();
			this.tbAddWorkSpeedPerStatusPoint_ = new global::System.Windows.Forms.TextBox();
			this.LAddMaxSPPerStatusPoint = new global::System.Windows.Forms.Label();
			this.LAddPowerPerStatusPoint = new global::System.Windows.Forms.Label();
			this.tbAddMaxSPPerStatusPoint_ = new global::System.Windows.Forms.TextBox();
			this.tbAddMaxInventoryWeightPerStatusPoint_ = new global::System.Windows.Forms.TextBox();
			this.tbAddPowerPerStatusPoint_ = new global::System.Windows.Forms.TextBox();
			this.tbAddCaptureLevelPerStatusPoint_ = new global::System.Windows.Forms.TextBox();
			this.LStatusPointPerLevel = new global::System.Windows.Forms.Label();
			this.tbAddMaxHPPerHPRank_ = new global::System.Windows.Forms.TextBox();
			this.LAddMaxInventoryWeightPerStatusPoint = new global::System.Windows.Forms.Label();
			this.tbAddWorkSpeedPerWorkSpeedRank_ = new global::System.Windows.Forms.TextBox();
			this.tbAddDefencePerDefenceRank_ = new global::System.Windows.Forms.TextBox();
			this.LAddWorkSpeedPerWorkSpeedRank = new global::System.Windows.Forms.Label();
			this.tbAddAttackPerAttackRank_ = new global::System.Windows.Forms.TextBox();
			this.LAddCaptureLevelPerStatusPoint = new global::System.Windows.Forms.Label();
			this.LAddWorkSpeedPerStatusPoint = new global::System.Windows.Forms.Label();
			this.LAddMaxHPPerHPRank = new global::System.Windows.Forms.Label();
			this.LAddAttackPerAttackRank = new global::System.Windows.Forms.Label();
			this.LAddDefencePerDefenceRank = new global::System.Windows.Forms.Label();
			this.gbXP = new global::System.Windows.Forms.GroupBox();
			this.GetXPButton = new global::System.Windows.Forms.Button();
			this.LBuildXP = new global::System.Windows.Forms.Label();
			this.SetXPButton = new global::System.Windows.Forms.Button();
			this.tbBuildXP_ = new global::System.Windows.Forms.TextBox();
			this.tbCraftXP_ = new global::System.Windows.Forms.TextBox();
			this.LCraftXP = new global::System.Windows.Forms.Label();
			this.tbPickupItemOnLevelExp_ = new global::System.Windows.Forms.TextBox();
			this.LPickupItemOnLevelExp = new global::System.Windows.Forms.Label();
			this.tbMapObjectDestroyProceedExp_ = new global::System.Windows.Forms.TextBox();
			this.LMapObjectDestroyProceedExp = new global::System.Windows.Forms.Label();
			this.RarePalAppearanceBox = new global::System.Windows.Forms.CheckBox();
			this.InstaFarmBox = new global::System.Windows.Forms.CheckBox();
			this.CatchRateBox = new global::System.Windows.Forms.CheckBox();
			this.tabPageBase = new global::System.Windows.Forms.TabPage();
			this.groupBox9 = new global::System.Windows.Forms.GroupBox();
			this.GetBaseStatsButton = new global::System.Windows.Forms.Button();
			this.BaseResetBuildRange = new global::System.Windows.Forms.Button();
			this.SetBaseStatsButton = new global::System.Windows.Forms.Button();
			this.BaseInfBuildRange = new global::System.Windows.Forms.Button();
			this.tbInstallDinstanceFromOwner_ = new global::System.Windows.Forms.TextBox();
			this.label11 = new global::System.Windows.Forms.Label();
			this.tabPageMenuSettings = new global::System.Windows.Forms.TabPage();
			this.ShowHotkeyBox = new global::System.Windows.Forms.CheckBox();
			this.ShowWatermarkBox = new global::System.Windows.Forms.CheckBox();
			this.InventoryTabPageButton = new global::System.Windows.Forms.Button();
			this.PalEditorTabPageButton = new global::System.Windows.Forms.Button();
			this.WorldTabPageButton = new global::System.Windows.Forms.Button();
			this.BaseTabPageButton = new global::System.Windows.Forms.Button();
			this.MenuSettingsTabPageButton = new global::System.Windows.Forms.Button();
			this.HidingPanel = new global::System.Windows.Forms.Panel();
			((global::System.ComponentModel.ISupportInitialize)this.MoveArrowPicture).BeginInit();
			this.CheatMenuTabControl.SuspendLayout();
			this.tabPagePlayer.SuspendLayout();
			this.groupBox2.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.SpeedBar).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.SpeedBar2).BeginInit();
			this.tabPageWeapon.SuspendLayout();
			this.groupBox8.SuspendLayout();
			this.tabPageInventory.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.gbItemSlotStack.SuspendLayout();
			this.tabPagePalEditor.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox7.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.groupBox6.SuspendLayout();
			this.tabPageWorld.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.gbPlayerStats.SuspendLayout();
			this.gbXP.SuspendLayout();
			this.tabPageBase.SuspendLayout();
			this.groupBox9.SuspendLayout();
			this.tabPageMenuSettings.SuspendLayout();
			base.SuspendLayout();
			this.MoveArrowPicture.BackColor = global::System.Drawing.Color.FromArgb(0, 0, 64);
			this.MoveArrowPicture.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
	//		this.MoveArrowPicture.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("MoveArrowPicture.Image");
			this.MoveArrowPicture.Location = new global::System.Drawing.Point(12, 12);
			this.MoveArrowPicture.Name = "MoveArrowPicture";
			this.MoveArrowPicture.Size = new global::System.Drawing.Size(91, 37);
			this.MoveArrowPicture.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.MoveArrowPicture.TabIndex = 0;
			this.MoveArrowPicture.TabStop = false;
			this.MoveArrowPicture.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.MoveArrowPicture_MouseDown);
			this.MoveArrowPicture.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.MoveArrowPicture_MouseMove);
			this.MoveArrowPicture.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.MoveArrowPicture_MouseUp);
			this.PlayerTabPageButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.PlayerTabPageButton.Font = new global::System.Drawing.Font("Verdana", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.PlayerTabPageButton.ForeColor = global::System.Drawing.Color.Lime;
			this.PlayerTabPageButton.Location = new global::System.Drawing.Point(12, 55);
			this.PlayerTabPageButton.Name = "PlayerTabPageButton";
			this.PlayerTabPageButton.Size = new global::System.Drawing.Size(91, 37);
			this.PlayerTabPageButton.TabIndex = 1;
			this.PlayerTabPageButton.TabStop = false;
			this.PlayerTabPageButton.Text = "Player";
			this.PlayerTabPageButton.UseVisualStyleBackColor = true;
			this.WeaponTabPageButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.WeaponTabPageButton.Font = new global::System.Drawing.Font("Verdana", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.WeaponTabPageButton.ForeColor = global::System.Drawing.Color.Lime;
			this.WeaponTabPageButton.Location = new global::System.Drawing.Point(12, 98);
			this.WeaponTabPageButton.Name = "WeaponTabPageButton";
			this.WeaponTabPageButton.Size = new global::System.Drawing.Size(91, 37);
			this.WeaponTabPageButton.TabIndex = 2;
			this.WeaponTabPageButton.TabStop = false;
			this.WeaponTabPageButton.Text = "Weapon";
			this.WeaponTabPageButton.UseVisualStyleBackColor = true;
			this.CheatMenuTabControl.Controls.Add(this.tabPagePlayer);
			this.CheatMenuTabControl.Controls.Add(this.tabPageWeapon);
			this.CheatMenuTabControl.Controls.Add(this.tabPageInventory);
			this.CheatMenuTabControl.Controls.Add(this.tabPagePalEditor);
			this.CheatMenuTabControl.Controls.Add(this.tabPageWorld);
			this.CheatMenuTabControl.Controls.Add(this.tabPageBase);
			this.CheatMenuTabControl.Controls.Add(this.tabPageMenuSettings);
			this.CheatMenuTabControl.Location = new global::System.Drawing.Point(109, 12);
			this.CheatMenuTabControl.Multiline = true;
			this.CheatMenuTabControl.Name = "CheatMenuTabControl";
			this.CheatMenuTabControl.SelectedIndex = 0;
			this.CheatMenuTabControl.Size = new global::System.Drawing.Size(419, 372);
			this.CheatMenuTabControl.TabIndex = 3;
			this.CheatMenuTabControl.TabStop = false;
			this.tabPagePlayer.BackColor = global::System.Drawing.Color.Black;
			this.tabPagePlayer.Controls.Add(this.EggHatchBox);
			this.tabPagePlayer.Controls.Add(this.groupBox2);
			this.tabPagePlayer.Controls.Add(this.HealPlayerButton);
			this.tabPagePlayer.Controls.Add(this.MaxLevelButton);
			this.tabPagePlayer.Controls.Add(this.MaxStomachButton);
			this.tabPagePlayer.Controls.Add(this.GiveTechPointsButton);
			this.tabPagePlayer.Controls.Add(this.ShieldRegenBox);
			this.tabPagePlayer.Controls.Add(this.HealthRegenBox);
			this.tabPagePlayer.Controls.Add(this.AIChaseBox);
			this.tabPagePlayer.Controls.Add(this.AIIgnoreBox);
			this.tabPagePlayer.Controls.Add(this.NoStomachBox);
			this.tabPagePlayer.Controls.Add(this.BodyTemperatureDamageBox);
			this.tabPagePlayer.Controls.Add(this.NeverWantedBox);
			this.tabPagePlayer.Controls.Add(this.GodmodeBox);
			this.tabPagePlayer.Location = new global::System.Drawing.Point(4, 22);
			this.tabPagePlayer.Name = "tabPagePlayer";
			this.tabPagePlayer.Padding = new global::System.Windows.Forms.Padding(3);
			this.tabPagePlayer.Size = new global::System.Drawing.Size(411, 346);
			this.tabPagePlayer.TabIndex = 0;
			this.tabPagePlayer.Text = "Player";
			this.EggHatchBox.AutoSize = true;
			this.EggHatchBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.EggHatchBox.FlatAppearance.BorderSize = 2;
			this.EggHatchBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.EggHatchBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.EggHatchBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.EggHatchBox.ForeColor = global::System.Drawing.Color.Red;
			this.EggHatchBox.Location = new global::System.Drawing.Point(9, 190);
			this.EggHatchBox.Name = "EggHatchBox";
			this.EggHatchBox.Size = new global::System.Drawing.Size(76, 17);
			this.EggHatchBox.TabIndex = 74;
			this.EggHatchBox.Text = "Egg Farm";
			this.EggHatchBox.UseVisualStyleBackColor = true;
			this.groupBox2.Controls.Add(this.SpoofPositionBox);
			this.groupBox2.Controls.Add(this.SpeedBar);
			this.groupBox2.Controls.Add(this.LTimeDilation2);
			this.groupBox2.Controls.Add(this.NoRespawnDelayBox);
			this.groupBox2.Controls.Add(this.SpeedBar2);
			this.groupBox2.Controls.Add(this.LTimeDilation);
			this.groupBox2.Controls.Add(this.NoStaminaBox);
			this.groupBox2.Controls.Add(this.CarryWeightBox);
			this.groupBox2.Controls.Add(this.OneHitBox);
			this.groupBox2.Controls.Add(this.SuperJumpBox);
			this.groupBox2.Controls.Add(this.SpeedhackBox);
			this.groupBox2.Controls.Add(this.FlymodeBox);
			this.groupBox2.Font = new global::System.Drawing.Font("Verdana", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.groupBox2.ForeColor = global::System.Drawing.Color.FromArgb(255, 128, 0);
			this.groupBox2.Location = new global::System.Drawing.Point(196, 6);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new global::System.Drawing.Size(182, 336);
			this.groupBox2.TabIndex = 73;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Non Host";
			this.SpoofPositionBox.AutoSize = true;
			this.SpoofPositionBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SpoofPositionBox.Font = new global::System.Drawing.Font("Verdana", 8.25f);
			this.SpoofPositionBox.ForeColor = global::System.Drawing.Color.Red;
			this.SpoofPositionBox.Location = new global::System.Drawing.Point(34, 26);
			this.SpoofPositionBox.Name = "SpoofPositionBox";
			this.SpoofPositionBox.Size = new global::System.Drawing.Size(118, 17);
			this.SpoofPositionBox.TabIndex = 4;
			this.SpoofPositionBox.Text = "Spoof Position**";
			this.SpoofPositionBox.UseVisualStyleBackColor = true;
			this.SpoofPositionBox.CheckedChanged += new global::System.EventHandler(this.SpoofPositionBox_CheckedChanged);
			this.SpeedBar.LargeChange = 1;
			this.SpeedBar.Location = new global::System.Drawing.Point(13, 64);
			this.SpeedBar.Maximum = 20;
			this.SpeedBar.Minimum = 1;
			this.SpeedBar.Name = "SpeedBar";
			this.SpeedBar.Size = new global::System.Drawing.Size(148, 45);
			this.SpeedBar.TabIndex = 65;
			this.SpeedBar.Value = 1;
			this.LTimeDilation2.AutoSize = true;
			this.LTimeDilation2.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LTimeDilation2.ForeColor = global::System.Drawing.Color.Red;
			this.LTimeDilation2.Location = new global::System.Drawing.Point(27, 272);
			this.LTimeDilation2.Name = "LTimeDilation2";
			this.LTimeDilation2.Size = new global::System.Drawing.Size(118, 13);
			this.LTimeDilation2.TabIndex = 68;
			this.LTimeDilation2.Text = "World Time Dilation";
			this.NoRespawnDelayBox.AutoSize = true;
			this.NoRespawnDelayBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.NoRespawnDelayBox.FlatAppearance.BorderSize = 2;
			this.NoRespawnDelayBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.NoRespawnDelayBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.NoRespawnDelayBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.NoRespawnDelayBox.ForeColor = global::System.Drawing.Color.Red;
			this.NoRespawnDelayBox.Location = new global::System.Drawing.Point(34, 243);
			this.NoRespawnDelayBox.Name = "NoRespawnDelayBox";
			this.NoRespawnDelayBox.Size = new global::System.Drawing.Size(130, 17);
			this.NoRespawnDelayBox.TabIndex = 70;
			this.NoRespawnDelayBox.Text = "No Respawn Delay";
			this.NoRespawnDelayBox.UseVisualStyleBackColor = true;
			this.SpeedBar2.LargeChange = 1;
			this.SpeedBar2.Location = new global::System.Drawing.Point(13, 286);
			this.SpeedBar2.Maximum = 20;
			this.SpeedBar2.Minimum = 1;
			this.SpeedBar2.Name = "SpeedBar2";
			this.SpeedBar2.Size = new global::System.Drawing.Size(148, 45);
			this.SpeedBar2.TabIndex = 67;
			this.SpeedBar2.Value = 1;
			this.LTimeDilation.AutoSize = true;
			this.LTimeDilation.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LTimeDilation.ForeColor = global::System.Drawing.Color.Red;
			this.LTimeDilation.Location = new global::System.Drawing.Point(20, 50);
			this.LTimeDilation.Name = "LTimeDilation";
			this.LTimeDilation.Size = new global::System.Drawing.Size(136, 13);
			this.LTimeDilation.TabIndex = 66;
			this.LTimeDilation.Text = "Player Time Dilation**";
			this.NoStaminaBox.AutoSize = true;
			this.NoStaminaBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.NoStaminaBox.FlatAppearance.BorderSize = 2;
			this.NoStaminaBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.NoStaminaBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.NoStaminaBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.NoStaminaBox.ForeColor = global::System.Drawing.Color.Red;
			this.NoStaminaBox.Location = new global::System.Drawing.Point(34, 220);
			this.NoStaminaBox.Name = "NoStaminaBox";
			this.NoStaminaBox.Size = new global::System.Drawing.Size(114, 17);
			this.NoStaminaBox.TabIndex = 69;
			this.NoStaminaBox.Text = "No Stamina Use";
			this.NoStaminaBox.UseVisualStyleBackColor = true;
			this.CarryWeightBox.AutoSize = true;
			this.CarryWeightBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.CarryWeightBox.Font = new global::System.Drawing.Font("Verdana", 8.25f);
			this.CarryWeightBox.ForeColor = global::System.Drawing.Color.Red;
			this.CarryWeightBox.Location = new global::System.Drawing.Point(34, 105);
			this.CarryWeightBox.Name = "CarryWeightBox";
			this.CarryWeightBox.Size = new global::System.Drawing.Size(112, 17);
			this.CarryWeightBox.TabIndex = 7;
			this.CarryWeightBox.Text = "Carry Weight**";
			this.CarryWeightBox.UseVisualStyleBackColor = true;
			this.OneHitBox.AutoSize = true;
			this.OneHitBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.OneHitBox.FlatAppearance.BorderSize = 2;
			this.OneHitBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.OneHitBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.OneHitBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.OneHitBox.ForeColor = global::System.Drawing.Color.Red;
			this.OneHitBox.Location = new global::System.Drawing.Point(34, 197);
			this.OneHitBox.Name = "OneHitBox";
			this.OneHitBox.Size = new global::System.Drawing.Size(86, 17);
			this.OneHitBox.TabIndex = 71;
			this.OneHitBox.Text = "One Hit Kill";
			this.OneHitBox.UseVisualStyleBackColor = true;
			this.SuperJumpBox.AutoSize = true;
			this.SuperJumpBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SuperJumpBox.Font = new global::System.Drawing.Font("Verdana", 8.25f);
			this.SuperJumpBox.ForeColor = global::System.Drawing.Color.Red;
			this.SuperJumpBox.Location = new global::System.Drawing.Point(34, 128);
			this.SuperJumpBox.Name = "SuperJumpBox";
			this.SuperJumpBox.Size = new global::System.Drawing.Size(105, 17);
			this.SuperJumpBox.TabIndex = 8;
			this.SuperJumpBox.Text = "Super Jump**";
			this.SuperJumpBox.UseVisualStyleBackColor = true;
			this.SuperJumpBox.CheckedChanged += new global::System.EventHandler(this.SuperJumpBox_CheckedChanged);
			this.SpeedhackBox.AutoSize = true;
			this.SpeedhackBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SpeedhackBox.Font = new global::System.Drawing.Font("Verdana", 8.25f);
			this.SpeedhackBox.ForeColor = global::System.Drawing.Color.Red;
			this.SpeedhackBox.Location = new global::System.Drawing.Point(34, 151);
			this.SpeedhackBox.Name = "SpeedhackBox";
			this.SpeedhackBox.Size = new global::System.Drawing.Size(100, 17);
			this.SpeedhackBox.TabIndex = 6;
			this.SpeedhackBox.Text = "Speedhack**";
			this.SpeedhackBox.UseVisualStyleBackColor = true;
			this.SpeedhackBox.CheckedChanged += new global::System.EventHandler(this.SpeedhackBox_CheckedChanged);
			this.FlymodeBox.AutoSize = true;
			this.FlymodeBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.FlymodeBox.Font = new global::System.Drawing.Font("Verdana", 8.25f);
			this.FlymodeBox.ForeColor = global::System.Drawing.Color.Red;
			this.FlymodeBox.Location = new global::System.Drawing.Point(34, 174);
			this.FlymodeBox.Name = "FlymodeBox";
			this.FlymodeBox.Size = new global::System.Drawing.Size(85, 17);
			this.FlymodeBox.TabIndex = 5;
			this.FlymodeBox.Text = "Flymode**";
			this.FlymodeBox.UseVisualStyleBackColor = true;
			this.FlymodeBox.CheckedChanged += new global::System.EventHandler(this.FlymodeBox_CheckedChanged);
			this.HealPlayerButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.HealPlayerButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.HealPlayerButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.HealPlayerButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.HealPlayerButton.Location = new global::System.Drawing.Point(93, 301);
			this.HealPlayerButton.Name = "HealPlayerButton";
			this.HealPlayerButton.Size = new global::System.Drawing.Size(81, 40);
			this.HealPlayerButton.TabIndex = 72;
			this.HealPlayerButton.TabStop = false;
			this.HealPlayerButton.Text = "Heal Player";
			this.HealPlayerButton.UseVisualStyleBackColor = false;
			this.MaxLevelButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.MaxLevelButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.MaxLevelButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.MaxLevelButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.MaxLevelButton.Location = new global::System.Drawing.Point(14, 211);
			this.MaxLevelButton.Name = "MaxLevelButton";
			this.MaxLevelButton.Size = new global::System.Drawing.Size(160, 40);
			this.MaxLevelButton.TabIndex = 64;
			this.MaxLevelButton.TabStop = false;
			this.MaxLevelButton.Text = "Set Max Player Level";
			this.MaxLevelButton.UseVisualStyleBackColor = false;
			this.MaxStomachButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.MaxStomachButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.MaxStomachButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.MaxStomachButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.MaxStomachButton.Location = new global::System.Drawing.Point(14, 301);
			this.MaxStomachButton.Name = "MaxStomachButton";
			this.MaxStomachButton.Size = new global::System.Drawing.Size(73, 40);
			this.MaxStomachButton.TabIndex = 63;
			this.MaxStomachButton.TabStop = false;
			this.MaxStomachButton.Text = "Full Stomach";
			this.MaxStomachButton.UseVisualStyleBackColor = false;
			this.GiveTechPointsButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.GiveTechPointsButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GiveTechPointsButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GiveTechPointsButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.GiveTechPointsButton.Location = new global::System.Drawing.Point(14, 254);
			this.GiveTechPointsButton.Name = "GiveTechPointsButton";
			this.GiveTechPointsButton.Size = new global::System.Drawing.Size(160, 44);
			this.GiveTechPointsButton.TabIndex = 62;
			this.GiveTechPointsButton.TabStop = false;
			this.GiveTechPointsButton.Text = "Give 1000x Tech-Relic-Stat Points";
			this.GiveTechPointsButton.UseVisualStyleBackColor = false;
			this.ShieldRegenBox.AutoSize = true;
			this.ShieldRegenBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.ShieldRegenBox.FlatAppearance.BorderSize = 2;
			this.ShieldRegenBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.ShieldRegenBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ShieldRegenBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ShieldRegenBox.ForeColor = global::System.Drawing.Color.Red;
			this.ShieldRegenBox.Location = new global::System.Drawing.Point(9, 121);
			this.ShieldRegenBox.Name = "ShieldRegenBox";
			this.ShieldRegenBox.Size = new global::System.Drawing.Size(165, 17);
			this.ShieldRegenBox.TabIndex = 61;
			this.ShieldRegenBox.Text = "Max Shield Regeneration";
			this.ShieldRegenBox.UseVisualStyleBackColor = true;
			this.HealthRegenBox.AutoSize = true;
			this.HealthRegenBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.HealthRegenBox.FlatAppearance.BorderSize = 2;
			this.HealthRegenBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.HealthRegenBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.HealthRegenBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.HealthRegenBox.ForeColor = global::System.Drawing.Color.Red;
			this.HealthRegenBox.Location = new global::System.Drawing.Point(9, 98);
			this.HealthRegenBox.Name = "HealthRegenBox";
			this.HealthRegenBox.Size = new global::System.Drawing.Size(166, 17);
			this.HealthRegenBox.TabIndex = 60;
			this.HealthRegenBox.Text = "Max Health Regeneration";
			this.HealthRegenBox.UseVisualStyleBackColor = true;
			this.AIChaseBox.AutoSize = true;
			this.AIChaseBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.AIChaseBox.FlatAppearance.BorderSize = 2;
			this.AIChaseBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.AIChaseBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.AIChaseBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.AIChaseBox.ForeColor = global::System.Drawing.Color.Red;
			this.AIChaseBox.Location = new global::System.Drawing.Point(9, 167);
			this.AIChaseBox.Name = "AIChaseBox";
			this.AIChaseBox.Size = new global::System.Drawing.Size(167, 17);
			this.AIChaseBox.TabIndex = 59;
			this.AIChaseBox.Text = "Hostile AI chases forever";
			this.AIChaseBox.UseVisualStyleBackColor = true;
			this.AIIgnoreBox.AutoSize = true;
			this.AIIgnoreBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.AIIgnoreBox.FlatAppearance.BorderSize = 2;
			this.AIIgnoreBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.AIIgnoreBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.AIIgnoreBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.AIIgnoreBox.ForeColor = global::System.Drawing.Color.Red;
			this.AIIgnoreBox.Location = new global::System.Drawing.Point(9, 144);
			this.AIIgnoreBox.Name = "AIIgnoreBox";
			this.AIIgnoreBox.Size = new global::System.Drawing.Size(108, 17);
			this.AIIgnoreBox.TabIndex = 58;
			this.AIIgnoreBox.Text = "AI Ignores You";
			this.AIIgnoreBox.UseVisualStyleBackColor = true;
			this.NoStomachBox.AutoSize = true;
			this.NoStomachBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.NoStomachBox.FlatAppearance.BorderSize = 2;
			this.NoStomachBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.NoStomachBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.NoStomachBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.NoStomachBox.ForeColor = global::System.Drawing.Color.Red;
			this.NoStomachBox.Location = new global::System.Drawing.Point(9, 75);
			this.NoStomachBox.Name = "NoStomachBox";
			this.NoStomachBox.Size = new global::System.Drawing.Size(150, 17);
			this.NoStomachBox.TabIndex = 57;
			this.NoStomachBox.Text = "No Stomach Decrease";
			this.NoStomachBox.UseVisualStyleBackColor = true;
			this.BodyTemperatureDamageBox.AutoSize = true;
			this.BodyTemperatureDamageBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.BodyTemperatureDamageBox.FlatAppearance.BorderSize = 2;
			this.BodyTemperatureDamageBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.BodyTemperatureDamageBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.BodyTemperatureDamageBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.BodyTemperatureDamageBox.ForeColor = global::System.Drawing.Color.Red;
			this.BodyTemperatureDamageBox.Location = new global::System.Drawing.Point(9, 52);
			this.BodyTemperatureDamageBox.Name = "BodyTemperatureDamageBox";
			this.BodyTemperatureDamageBox.Size = new global::System.Drawing.Size(167, 17);
			this.BodyTemperatureDamageBox.TabIndex = 56;
			this.BodyTemperatureDamageBox.Text = "No Temperature Damage";
			this.BodyTemperatureDamageBox.UseVisualStyleBackColor = true;
			this.NeverWantedBox.AutoSize = true;
			this.NeverWantedBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.NeverWantedBox.FlatAppearance.BorderSize = 2;
			this.NeverWantedBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.NeverWantedBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.NeverWantedBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.NeverWantedBox.ForeColor = global::System.Drawing.Color.Red;
			this.NeverWantedBox.Location = new global::System.Drawing.Point(9, 29);
			this.NeverWantedBox.Name = "NeverWantedBox";
			this.NeverWantedBox.Size = new global::System.Drawing.Size(103, 17);
			this.NeverWantedBox.TabIndex = 55;
			this.NeverWantedBox.Text = "Never Wanted";
			this.NeverWantedBox.UseVisualStyleBackColor = true;
			this.GodmodeBox.AutoSize = true;
			this.GodmodeBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.GodmodeBox.FlatAppearance.BorderSize = 2;
			this.GodmodeBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.GodmodeBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GodmodeBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GodmodeBox.ForeColor = global::System.Drawing.Color.Red;
			this.GodmodeBox.Location = new global::System.Drawing.Point(9, 6);
			this.GodmodeBox.Name = "GodmodeBox";
			this.GodmodeBox.Size = new global::System.Drawing.Size(78, 17);
			this.GodmodeBox.TabIndex = 54;
			this.GodmodeBox.Text = "Godmode";
			this.GodmodeBox.UseVisualStyleBackColor = true;
			this.tabPageWeapon.BackColor = global::System.Drawing.Color.Black;
			this.tabPageWeapon.Controls.Add(this.groupBox8);
			this.tabPageWeapon.Location = new global::System.Drawing.Point(4, 22);
			this.tabPageWeapon.Name = "tabPageWeapon";
			this.tabPageWeapon.Padding = new global::System.Windows.Forms.Padding(3);
			this.tabPageWeapon.Size = new global::System.Drawing.Size(411, 346);
			this.tabPageWeapon.TabIndex = 1;
			this.tabPageWeapon.Text = "Weapon";
			this.groupBox8.Controls.Add(this.ModWeaponButton);
			this.groupBox8.Font = new global::System.Drawing.Font("Verdana", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.groupBox8.ForeColor = global::System.Drawing.Color.FromArgb(255, 128, 0);
			this.groupBox8.Location = new global::System.Drawing.Point(6, 6);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Size = new global::System.Drawing.Size(151, 80);
			this.groupBox8.TabIndex = 74;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "Non Host";
			this.ModWeaponButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.ModWeaponButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ModWeaponButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ModWeaponButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.ModWeaponButton.Location = new global::System.Drawing.Point(6, 26);
			this.ModWeaponButton.Name = "ModWeaponButton";
			this.ModWeaponButton.Size = new global::System.Drawing.Size(129, 38);
			this.ModWeaponButton.TabIndex = 10;
			this.ModWeaponButton.TabStop = false;
			this.ModWeaponButton.Text = "Mod Current Equipped Weapon*";
			this.ModWeaponButton.UseVisualStyleBackColor = false;
			this.tabPageInventory.BackColor = global::System.Drawing.Color.Black;
			this.tabPageInventory.Controls.Add(this.groupBox1);
			this.tabPageInventory.Controls.Add(this.gbItemSlotStack);
			this.tabPageInventory.Location = new global::System.Drawing.Point(4, 22);
			this.tabPageInventory.Name = "tabPageInventory";
			this.tabPageInventory.Size = new global::System.Drawing.Size(411, 346);
			this.tabPageInventory.TabIndex = 2;
			this.tabPageInventory.Text = "Inventory";
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label12);
			this.groupBox1.Controls.Add(this.GiveGoldButton);
			this.groupBox1.Controls.Add(this.GiveSoulsButton);
			this.groupBox1.Controls.Add(this.GiveWoodButton);
			this.groupBox1.Font = new global::System.Drawing.Font("Verdana", 12f, global::System.Drawing.FontStyle.Bold);
			this.groupBox1.ForeColor = global::System.Drawing.Color.Yellow;
			this.groupBox1.Location = new global::System.Drawing.Point(6, 124);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new global::System.Drawing.Size(258, 83);
			this.groupBox1.TabIndex = 60;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Item Slots Give Item";
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label2.ForeColor = global::System.Drawing.Color.Cyan;
			this.label2.Location = new global::System.Drawing.Point(187, 19);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(35, 12);
			this.label2.TabIndex = 67;
			this.label2.Text = "Slot 3";
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label3.ForeColor = global::System.Drawing.Color.Cyan;
			this.label3.Location = new global::System.Drawing.Point(26, 19);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(35, 12);
			this.label3.TabIndex = 65;
			this.label3.Text = "Slot 1";
			this.label12.AutoSize = true;
			this.label12.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label12.ForeColor = global::System.Drawing.Color.Cyan;
			this.label12.Location = new global::System.Drawing.Point(106, 19);
			this.label12.Name = "label12";
			this.label12.Size = new global::System.Drawing.Size(35, 12);
			this.label12.TabIndex = 66;
			this.label12.Text = "Slot 2";
			this.GiveGoldButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.GiveGoldButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GiveGoldButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GiveGoldButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.GiveGoldButton.Location = new global::System.Drawing.Point(168, 34);
			this.GiveGoldButton.Name = "GiveGoldButton";
			this.GiveGoldButton.Size = new global::System.Drawing.Size(75, 38);
			this.GiveGoldButton.TabIndex = 64;
			this.GiveGoldButton.TabStop = false;
			this.GiveGoldButton.Text = "Gold x1M";
			this.GiveGoldButton.UseVisualStyleBackColor = false;
			this.GiveSoulsButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.GiveSoulsButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GiveSoulsButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GiveSoulsButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.GiveSoulsButton.Location = new global::System.Drawing.Point(87, 34);
			this.GiveSoulsButton.Name = "GiveSoulsButton";
			this.GiveSoulsButton.Size = new global::System.Drawing.Size(75, 38);
			this.GiveSoulsButton.TabIndex = 63;
			this.GiveSoulsButton.TabStop = false;
			this.GiveSoulsButton.Text = "Pal Souls x9999";
			this.GiveSoulsButton.UseVisualStyleBackColor = false;
			this.GiveWoodButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.GiveWoodButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GiveWoodButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GiveWoodButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.GiveWoodButton.Location = new global::System.Drawing.Point(6, 34);
			this.GiveWoodButton.Name = "GiveWoodButton";
			this.GiveWoodButton.Size = new global::System.Drawing.Size(75, 38);
			this.GiveWoodButton.TabIndex = 52;
			this.GiveWoodButton.TabStop = false;
			this.GiveWoodButton.Text = "Wood x9999";
			this.GiveWoodButton.UseVisualStyleBackColor = false;
			this.gbItemSlotStack.Controls.Add(this.tbStackCount5_);
			this.gbItemSlotStack.Controls.Add(this.SetInvStatsButton);
			this.gbItemSlotStack.Controls.Add(this.GetInvStatsButton);
			this.gbItemSlotStack.Controls.Add(this.label22);
			this.gbItemSlotStack.Controls.Add(this.tbStackCount4_);
			this.gbItemSlotStack.Controls.Add(this.label23);
			this.gbItemSlotStack.Controls.Add(this.tbStackCount_);
			this.gbItemSlotStack.Controls.Add(this.tbStackCount3_);
			this.gbItemSlotStack.Controls.Add(this.LSlot3);
			this.gbItemSlotStack.Controls.Add(this.LSlot1);
			this.gbItemSlotStack.Controls.Add(this.tbStackCount2_);
			this.gbItemSlotStack.Controls.Add(this.LSlot2);
			this.gbItemSlotStack.Font = new global::System.Drawing.Font("Verdana", 12f, global::System.Drawing.FontStyle.Bold);
			this.gbItemSlotStack.ForeColor = global::System.Drawing.Color.Yellow;
			this.gbItemSlotStack.Location = new global::System.Drawing.Point(6, 6);
			this.gbItemSlotStack.Name = "gbItemSlotStack";
			this.gbItemSlotStack.Size = new global::System.Drawing.Size(380, 112);
			this.gbItemSlotStack.TabIndex = 59;
			this.gbItemSlotStack.TabStop = false;
			this.gbItemSlotStack.Text = "Item Slots Stack Count";
			this.tbStackCount5_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbStackCount5_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbStackCount5_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbStackCount5_.Location = new global::System.Drawing.Point(302, 33);
			this.tbStackCount5_.Name = "tbStackCount5_";
			this.tbStackCount5_.Size = new global::System.Drawing.Size(68, 22);
			this.tbStackCount5_.TabIndex = 60;
			this.tbStackCount5_.TabStop = false;
			this.tbStackCount5_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.SetInvStatsButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.SetInvStatsButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SetInvStatsButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.SetInvStatsButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.SetInvStatsButton.Location = new global::System.Drawing.Point(87, 61);
			this.SetInvStatsButton.Name = "SetInvStatsButton";
			this.SetInvStatsButton.Size = new global::System.Drawing.Size(75, 38);
			this.SetInvStatsButton.TabIndex = 53;
			this.SetInvStatsButton.TabStop = false;
			this.SetInvStatsButton.Text = "Set Stats";
			this.SetInvStatsButton.UseVisualStyleBackColor = false;
			this.SetInvStatsButton.Click += new global::System.EventHandler(this.SetInvStatsButton_Click);
			this.GetInvStatsButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.GetInvStatsButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GetInvStatsButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GetInvStatsButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.GetInvStatsButton.Location = new global::System.Drawing.Point(6, 61);
			this.GetInvStatsButton.Name = "GetInvStatsButton";
			this.GetInvStatsButton.Size = new global::System.Drawing.Size(75, 38);
			this.GetInvStatsButton.TabIndex = 52;
			this.GetInvStatsButton.TabStop = false;
			this.GetInvStatsButton.Text = "Get Stats";
			this.GetInvStatsButton.UseVisualStyleBackColor = false;
			this.GetInvStatsButton.Click += new global::System.EventHandler(this.GetInvStatsButton_Click);
			this.label22.AutoSize = true;
			this.label22.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label22.ForeColor = global::System.Drawing.Color.Cyan;
			this.label22.Location = new global::System.Drawing.Point(318, 18);
			this.label22.Name = "label22";
			this.label22.Size = new global::System.Drawing.Size(35, 12);
			this.label22.TabIndex = 61;
			this.label22.Text = "Slot 5";
			this.tbStackCount4_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbStackCount4_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbStackCount4_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbStackCount4_.Location = new global::System.Drawing.Point(228, 33);
			this.tbStackCount4_.Name = "tbStackCount4_";
			this.tbStackCount4_.Size = new global::System.Drawing.Size(68, 22);
			this.tbStackCount4_.TabIndex = 58;
			this.tbStackCount4_.TabStop = false;
			this.tbStackCount4_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.label23.AutoSize = true;
			this.label23.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label23.ForeColor = global::System.Drawing.Color.Cyan;
			this.label23.Location = new global::System.Drawing.Point(245, 18);
			this.label23.Name = "label23";
			this.label23.Size = new global::System.Drawing.Size(35, 12);
			this.label23.TabIndex = 59;
			this.label23.Text = "Slot 4";
			this.tbStackCount_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbStackCount_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbStackCount_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbStackCount_.Location = new global::System.Drawing.Point(6, 33);
			this.tbStackCount_.Name = "tbStackCount_";
			this.tbStackCount_.Size = new global::System.Drawing.Size(68, 22);
			this.tbStackCount_.TabIndex = 50;
			this.tbStackCount_.TabStop = false;
			this.tbStackCount_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.tbStackCount3_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbStackCount3_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbStackCount3_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbStackCount3_.Location = new global::System.Drawing.Point(154, 33);
			this.tbStackCount3_.Name = "tbStackCount3_";
			this.tbStackCount3_.Size = new global::System.Drawing.Size(68, 22);
			this.tbStackCount3_.TabIndex = 56;
			this.tbStackCount3_.TabStop = false;
			this.tbStackCount3_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.LSlot3.AutoSize = true;
			this.LSlot3.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LSlot3.ForeColor = global::System.Drawing.Color.Cyan;
			this.LSlot3.Location = new global::System.Drawing.Point(173, 18);
			this.LSlot3.Name = "LSlot3";
			this.LSlot3.Size = new global::System.Drawing.Size(35, 12);
			this.LSlot3.TabIndex = 57;
			this.LSlot3.Text = "Slot 3";
			this.LSlot1.AutoSize = true;
			this.LSlot1.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LSlot1.ForeColor = global::System.Drawing.Color.Cyan;
			this.LSlot1.Location = new global::System.Drawing.Point(26, 18);
			this.LSlot1.Name = "LSlot1";
			this.LSlot1.Size = new global::System.Drawing.Size(35, 12);
			this.LSlot1.TabIndex = 51;
			this.LSlot1.Text = "Slot 1";
			this.tbStackCount2_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbStackCount2_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbStackCount2_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbStackCount2_.Location = new global::System.Drawing.Point(80, 33);
			this.tbStackCount2_.Name = "tbStackCount2_";
			this.tbStackCount2_.Size = new global::System.Drawing.Size(68, 22);
			this.tbStackCount2_.TabIndex = 54;
			this.tbStackCount2_.TabStop = false;
			this.tbStackCount2_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.LSlot2.AutoSize = true;
			this.LSlot2.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LSlot2.ForeColor = global::System.Drawing.Color.Cyan;
			this.LSlot2.Location = new global::System.Drawing.Point(95, 18);
			this.LSlot2.Name = "LSlot2";
			this.LSlot2.Size = new global::System.Drawing.Size(35, 12);
			this.LSlot2.TabIndex = 55;
			this.LSlot2.Text = "Slot 2";
			this.tabPagePalEditor.BackColor = global::System.Drawing.Color.Black;
			this.tabPagePalEditor.Controls.Add(this.groupBox4);
			this.tabPagePalEditor.Location = new global::System.Drawing.Point(4, 22);
			this.tabPagePalEditor.Name = "tabPagePalEditor";
			this.tabPagePalEditor.Size = new global::System.Drawing.Size(411, 346);
			this.tabPagePalEditor.TabIndex = 3;
			this.tabPagePalEditor.Text = "PalEditor";
			this.groupBox4.Controls.Add(this.PalSanityButton);
			this.groupBox4.Controls.Add(this.groupBox7);
			this.groupBox4.Controls.Add(this.SetRarePalButton);
			this.groupBox4.Controls.Add(this.PalMaxHPButton);
			this.groupBox4.Controls.Add(this.groupBox5);
			this.groupBox4.Controls.Add(this.groupBox6);
			this.groupBox4.Controls.Add(this.PalMaxLevelButton);
			this.groupBox4.Controls.Add(this.PalFemaleButton);
			this.groupBox4.Controls.Add(this.PalMaleButton);
			this.groupBox4.Controls.Add(this.PalMaxStomachButton);
			this.groupBox4.Font = new global::System.Drawing.Font("Verdana", 12f, global::System.Drawing.FontStyle.Bold);
			this.groupBox4.ForeColor = global::System.Drawing.Color.Yellow;
			this.groupBox4.Location = new global::System.Drawing.Point(6, 6);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new global::System.Drawing.Size(393, 383);
			this.groupBox4.TabIndex = 60;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Team Slot 1";
			this.PalSanityButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.PalSanityButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.PalSanityButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.PalSanityButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.PalSanityButton.Location = new global::System.Drawing.Point(107, 57);
			this.PalSanityButton.Name = "PalSanityButton";
			this.PalSanityButton.Size = new global::System.Drawing.Size(95, 25);
			this.PalSanityButton.TabIndex = 74;
			this.PalSanityButton.TabStop = false;
			this.PalSanityButton.Text = "Fill Sanity";
			this.PalSanityButton.UseVisualStyleBackColor = false;
			this.groupBox7.Controls.Add(this.SetPalInstanceID);
			this.groupBox7.Controls.Add(this.GetPalInstanceID);
			this.groupBox7.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Bold);
			this.groupBox7.ForeColor = global::System.Drawing.Color.Yellow;
			this.groupBox7.Location = new global::System.Drawing.Point(6, 293);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new global::System.Drawing.Size(247, 83);
			this.groupBox7.TabIndex = 68;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "Duplicate Pal";
			this.SetPalInstanceID.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.SetPalInstanceID.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SetPalInstanceID.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.SetPalInstanceID.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.SetPalInstanceID.Location = new global::System.Drawing.Point(121, 26);
			this.SetPalInstanceID.Name = "SetPalInstanceID";
			this.SetPalInstanceID.Size = new global::System.Drawing.Size(108, 38);
			this.SetPalInstanceID.TabIndex = 53;
			this.SetPalInstanceID.TabStop = false;
			this.SetPalInstanceID.Text = "Set Pal Slot 1";
			this.SetPalInstanceID.UseVisualStyleBackColor = false;
			this.SetPalInstanceID.Click += new global::System.EventHandler(this.SetPalInstanceID_Click);
			this.GetPalInstanceID.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.GetPalInstanceID.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GetPalInstanceID.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GetPalInstanceID.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.GetPalInstanceID.Location = new global::System.Drawing.Point(7, 26);
			this.GetPalInstanceID.Name = "GetPalInstanceID";
			this.GetPalInstanceID.Size = new global::System.Drawing.Size(108, 38);
			this.GetPalInstanceID.TabIndex = 52;
			this.GetPalInstanceID.TabStop = false;
			this.GetPalInstanceID.Text = "Get Pal Slot 1";
			this.GetPalInstanceID.UseVisualStyleBackColor = false;
			this.GetPalInstanceID.Click += new global::System.EventHandler(this.GetPalInstanceID_Click);
			this.SetRarePalButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.SetRarePalButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SetRarePalButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.SetRarePalButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.SetRarePalButton.Location = new global::System.Drawing.Point(208, 26);
			this.SetRarePalButton.Name = "SetRarePalButton";
			this.SetRarePalButton.Size = new global::System.Drawing.Size(95, 25);
			this.SetRarePalButton.TabIndex = 72;
			this.SetRarePalButton.TabStop = false;
			this.SetRarePalButton.Text = "Rare Pal";
			this.SetRarePalButton.UseVisualStyleBackColor = false;
			this.PalMaxHPButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.PalMaxHPButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.PalMaxHPButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.PalMaxHPButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.PalMaxHPButton.Location = new global::System.Drawing.Point(6, 57);
			this.PalMaxHPButton.Name = "PalMaxHPButton";
			this.PalMaxHPButton.Size = new global::System.Drawing.Size(95, 25);
			this.PalMaxHPButton.TabIndex = 71;
			this.PalMaxHPButton.TabStop = false;
			this.PalMaxHPButton.Text = "Max HP";
			this.PalMaxHPButton.UseVisualStyleBackColor = false;
			this.groupBox5.Controls.Add(this.SetPalAttackButton);
			this.groupBox5.Controls.Add(this.label5);
			this.groupBox5.Controls.Add(this.tbEquipWazaAttackSlot1_);
			this.groupBox5.Controls.Add(this.label4);
			this.groupBox5.Controls.Add(this.tbEquipWazaAttackSlot2_);
			this.groupBox5.Controls.Add(this.tbEquipWazaAttackSlot3_);
			this.groupBox5.Controls.Add(this.GetPalAttackButton);
			this.groupBox5.Controls.Add(this.label6);
			this.groupBox5.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Bold);
			this.groupBox5.ForeColor = global::System.Drawing.Color.Yellow;
			this.groupBox5.Location = new global::System.Drawing.Point(6, 218);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new global::System.Drawing.Size(381, 69);
			this.groupBox5.TabIndex = 66;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "Attacks";
			this.SetPalAttackButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.SetPalAttackButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SetPalAttackButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.SetPalAttackButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.SetPalAttackButton.Location = new global::System.Drawing.Point(302, 19);
			this.SetPalAttackButton.Name = "SetPalAttackButton";
			this.SetPalAttackButton.Size = new global::System.Drawing.Size(71, 38);
			this.SetPalAttackButton.TabIndex = 61;
			this.SetPalAttackButton.TabStop = false;
			this.SetPalAttackButton.Text = "Set Stats";
			this.SetPalAttackButton.UseVisualStyleBackColor = false;
			this.SetPalAttackButton.Click += new global::System.EventHandler(this.SetPalAttackButton_Click);
			this.label5.AutoSize = true;
			this.label5.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label5.ForeColor = global::System.Drawing.Color.Cyan;
			this.label5.Location = new global::System.Drawing.Point(90, 20);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(49, 12);
			this.label5.TabIndex = 59;
			this.label5.Text = "Attack 1";
			this.tbEquipWazaAttackSlot1_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbEquipWazaAttackSlot1_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbEquipWazaAttackSlot1_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbEquipWazaAttackSlot1_.Location = new global::System.Drawing.Point(83, 35);
			this.tbEquipWazaAttackSlot1_.Name = "tbEquipWazaAttackSlot1_";
			this.tbEquipWazaAttackSlot1_.Size = new global::System.Drawing.Size(67, 22);
			this.tbEquipWazaAttackSlot1_.TabIndex = 58;
			this.tbEquipWazaAttackSlot1_.TabStop = false;
			this.tbEquipWazaAttackSlot1_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.label4.AutoSize = true;
			this.label4.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label4.ForeColor = global::System.Drawing.Color.Cyan;
			this.label4.Location = new global::System.Drawing.Point(238, 20);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(49, 12);
			this.label4.TabIndex = 65;
			this.label4.Text = "Attack 3";
			this.tbEquipWazaAttackSlot2_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbEquipWazaAttackSlot2_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbEquipWazaAttackSlot2_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbEquipWazaAttackSlot2_.Location = new global::System.Drawing.Point(156, 35);
			this.tbEquipWazaAttackSlot2_.Name = "tbEquipWazaAttackSlot2_";
			this.tbEquipWazaAttackSlot2_.Size = new global::System.Drawing.Size(67, 22);
			this.tbEquipWazaAttackSlot2_.TabIndex = 62;
			this.tbEquipWazaAttackSlot2_.TabStop = false;
			this.tbEquipWazaAttackSlot2_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.tbEquipWazaAttackSlot3_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbEquipWazaAttackSlot3_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbEquipWazaAttackSlot3_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbEquipWazaAttackSlot3_.Location = new global::System.Drawing.Point(229, 35);
			this.tbEquipWazaAttackSlot3_.Name = "tbEquipWazaAttackSlot3_";
			this.tbEquipWazaAttackSlot3_.Size = new global::System.Drawing.Size(67, 22);
			this.tbEquipWazaAttackSlot3_.TabIndex = 64;
			this.tbEquipWazaAttackSlot3_.TabStop = false;
			this.tbEquipWazaAttackSlot3_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.GetPalAttackButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.GetPalAttackButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GetPalAttackButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GetPalAttackButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.GetPalAttackButton.Location = new global::System.Drawing.Point(6, 19);
			this.GetPalAttackButton.Name = "GetPalAttackButton";
			this.GetPalAttackButton.Size = new global::System.Drawing.Size(71, 38);
			this.GetPalAttackButton.TabIndex = 60;
			this.GetPalAttackButton.TabStop = false;
			this.GetPalAttackButton.Text = "Get Stats";
			this.GetPalAttackButton.UseVisualStyleBackColor = false;
			this.GetPalAttackButton.Click += new global::System.EventHandler(this.GetPalAttackButton_Click);
			this.label6.AutoSize = true;
			this.label6.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label6.ForeColor = global::System.Drawing.Color.Cyan;
			this.label6.Location = new global::System.Drawing.Point(163, 20);
			this.label6.Name = "label6";
			this.label6.Size = new global::System.Drawing.Size(49, 12);
			this.label6.TabIndex = 63;
			this.label6.Text = "Attack 2";
			this.groupBox6.Controls.Add(this.tbSPSupport_);
			this.groupBox6.Controls.Add(this.label10);
			this.groupBox6.Controls.Add(this.SetPalStatsButton);
			this.groupBox6.Controls.Add(this.tbSPRankCraftSpeed_);
			this.groupBox6.Controls.Add(this.label9);
			this.groupBox6.Controls.Add(this.tbSPRankDefence_);
			this.groupBox6.Controls.Add(this.label8);
			this.groupBox6.Controls.Add(this.tbSPRankAttack_);
			this.groupBox6.Controls.Add(this.label7);
			this.groupBox6.Controls.Add(this.GetPalStatsButton);
			this.groupBox6.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.groupBox6.ForeColor = global::System.Drawing.Color.Yellow;
			this.groupBox6.Location = new global::System.Drawing.Point(6, 89);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new global::System.Drawing.Size(235, 123);
			this.groupBox6.TabIndex = 67;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "Stats";
			this.tbSPSupport_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbSPSupport_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbSPSupport_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbSPSupport_.Location = new global::System.Drawing.Point(156, 80);
			this.tbSPSupport_.Name = "tbSPSupport_";
			this.tbSPSupport_.Size = new global::System.Drawing.Size(67, 22);
			this.tbSPSupport_.TabIndex = 64;
			this.tbSPSupport_.TabStop = false;
			this.tbSPSupport_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.label10.AutoSize = true;
			this.label10.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label10.ForeColor = global::System.Drawing.Color.Cyan;
			this.label10.Location = new global::System.Drawing.Point(165, 65);
			this.label10.Name = "label10";
			this.label10.Size = new global::System.Drawing.Size(44, 12);
			this.label10.TabIndex = 65;
			this.label10.Text = "Support";
			this.SetPalStatsButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.SetPalStatsButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SetPalStatsButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.SetPalStatsButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.SetPalStatsButton.Location = new global::System.Drawing.Point(6, 64);
			this.SetPalStatsButton.Name = "SetPalStatsButton";
			this.SetPalStatsButton.Size = new global::System.Drawing.Size(71, 38);
			this.SetPalStatsButton.TabIndex = 55;
			this.SetPalStatsButton.TabStop = false;
			this.SetPalStatsButton.Text = "Set Stats";
			this.SetPalStatsButton.UseVisualStyleBackColor = false;
			this.SetPalStatsButton.Click += new global::System.EventHandler(this.SetPalStatsButton_Click);
			this.tbSPRankCraftSpeed_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbSPRankCraftSpeed_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbSPRankCraftSpeed_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbSPRankCraftSpeed_.Location = new global::System.Drawing.Point(156, 36);
			this.tbSPRankCraftSpeed_.Name = "tbSPRankCraftSpeed_";
			this.tbSPRankCraftSpeed_.Size = new global::System.Drawing.Size(67, 22);
			this.tbSPRankCraftSpeed_.TabIndex = 62;
			this.tbSPRankCraftSpeed_.TabStop = false;
			this.tbSPRankCraftSpeed_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.label9.AutoSize = true;
			this.label9.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label9.ForeColor = global::System.Drawing.Color.Cyan;
			this.label9.Location = new global::System.Drawing.Point(158, 21);
			this.label9.Name = "label9";
			this.label9.Size = new global::System.Drawing.Size(64, 12);
			this.label9.TabIndex = 63;
			this.label9.Text = "Craft Speed";
			this.tbSPRankDefence_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbSPRankDefence_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbSPRankDefence_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbSPRankDefence_.Location = new global::System.Drawing.Point(83, 80);
			this.tbSPRankDefence_.Name = "tbSPRankDefence_";
			this.tbSPRankDefence_.Size = new global::System.Drawing.Size(67, 22);
			this.tbSPRankDefence_.TabIndex = 60;
			this.tbSPRankDefence_.TabStop = false;
			this.tbSPRankDefence_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.label8.AutoSize = true;
			this.label8.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label8.ForeColor = global::System.Drawing.Color.Cyan;
			this.label8.Location = new global::System.Drawing.Point(93, 65);
			this.label8.Name = "label8";
			this.label8.Size = new global::System.Drawing.Size(46, 12);
			this.label8.TabIndex = 61;
			this.label8.Text = "Defense";
			this.tbSPRankAttack_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbSPRankAttack_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbSPRankAttack_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbSPRankAttack_.Location = new global::System.Drawing.Point(83, 36);
			this.tbSPRankAttack_.Name = "tbSPRankAttack_";
			this.tbSPRankAttack_.Size = new global::System.Drawing.Size(67, 22);
			this.tbSPRankAttack_.TabIndex = 58;
			this.tbSPRankAttack_.TabStop = false;
			this.tbSPRankAttack_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.label7.AutoSize = true;
			this.label7.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label7.ForeColor = global::System.Drawing.Color.Cyan;
			this.label7.Location = new global::System.Drawing.Point(96, 21);
			this.label7.Name = "label7";
			this.label7.Size = new global::System.Drawing.Size(39, 12);
			this.label7.TabIndex = 59;
			this.label7.Text = "Attack";
			this.GetPalStatsButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.GetPalStatsButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GetPalStatsButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GetPalStatsButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.GetPalStatsButton.Location = new global::System.Drawing.Point(6, 20);
			this.GetPalStatsButton.Name = "GetPalStatsButton";
			this.GetPalStatsButton.Size = new global::System.Drawing.Size(71, 38);
			this.GetPalStatsButton.TabIndex = 54;
			this.GetPalStatsButton.TabStop = false;
			this.GetPalStatsButton.Text = "Get Stats";
			this.GetPalStatsButton.UseVisualStyleBackColor = false;
			this.GetPalStatsButton.Click += new global::System.EventHandler(this.GetPalStatsButton_Click);
			this.PalMaxLevelButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.PalMaxLevelButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.PalMaxLevelButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.PalMaxLevelButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.PalMaxLevelButton.Location = new global::System.Drawing.Point(6, 26);
			this.PalMaxLevelButton.Name = "PalMaxLevelButton";
			this.PalMaxLevelButton.Size = new global::System.Drawing.Size(95, 25);
			this.PalMaxLevelButton.TabIndex = 68;
			this.PalMaxLevelButton.TabStop = false;
			this.PalMaxLevelButton.Text = "Max Level";
			this.PalMaxLevelButton.UseVisualStyleBackColor = false;
			this.PalFemaleButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.PalFemaleButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.PalFemaleButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.PalFemaleButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.PalFemaleButton.Location = new global::System.Drawing.Point(279, 57);
			this.PalFemaleButton.Name = "PalFemaleButton";
			this.PalFemaleButton.Size = new global::System.Drawing.Size(65, 25);
			this.PalFemaleButton.TabIndex = 70;
			this.PalFemaleButton.TabStop = false;
			this.PalFemaleButton.Text = "Female";
			this.PalFemaleButton.UseVisualStyleBackColor = false;
			this.PalMaleButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.PalMaleButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.PalMaleButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.PalMaleButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.PalMaleButton.Location = new global::System.Drawing.Point(208, 57);
			this.PalMaleButton.Name = "PalMaleButton";
			this.PalMaleButton.Size = new global::System.Drawing.Size(65, 25);
			this.PalMaleButton.TabIndex = 69;
			this.PalMaleButton.TabStop = false;
			this.PalMaleButton.Text = "Male";
			this.PalMaleButton.UseVisualStyleBackColor = false;
			this.PalMaxStomachButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.PalMaxStomachButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.PalMaxStomachButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.PalMaxStomachButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.PalMaxStomachButton.Location = new global::System.Drawing.Point(107, 26);
			this.PalMaxStomachButton.Name = "PalMaxStomachButton";
			this.PalMaxStomachButton.Size = new global::System.Drawing.Size(95, 25);
			this.PalMaxStomachButton.TabIndex = 73;
			this.PalMaxStomachButton.TabStop = false;
			this.PalMaxStomachButton.Text = "Full Stomach";
			this.PalMaxStomachButton.UseVisualStyleBackColor = false;
			this.tabPageWorld.BackColor = global::System.Drawing.Color.Black;
			this.tabPageWorld.Controls.Add(this.groupBox3);
			this.tabPageWorld.Location = new global::System.Drawing.Point(4, 22);
			this.tabPageWorld.Name = "tabPageWorld";
			this.tabPageWorld.Size = new global::System.Drawing.Size(411, 346);
			this.tabPageWorld.TabIndex = 4;
			this.tabPageWorld.Text = "World";
			this.groupBox3.Controls.Add(this.gbPlayerStats);
			this.groupBox3.Controls.Add(this.gbXP);
			this.groupBox3.Controls.Add(this.RarePalAppearanceBox);
			this.groupBox3.Controls.Add(this.InstaFarmBox);
			this.groupBox3.Controls.Add(this.CatchRateBox);
			this.groupBox3.Font = new global::System.Drawing.Font("Verdana", 12f, global::System.Drawing.FontStyle.Bold);
			this.groupBox3.ForeColor = global::System.Drawing.Color.Yellow;
			this.groupBox3.Location = new global::System.Drawing.Point(6, 6);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new global::System.Drawing.Size(397, 474);
			this.groupBox3.TabIndex = 63;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Game Settings";
			this.gbPlayerStats.Controls.Add(this.LTechnologyPointUnlockFastTravel);
			this.gbPlayerStats.Controls.Add(this.GetStatsButton);
			this.gbPlayerStats.Controls.Add(this.SetStatsButton);
			this.gbPlayerStats.Controls.Add(this.tbTechnologyPoint_UnlockFastTravel_);
			this.gbPlayerStats.Controls.Add(this.LAddMaxHPPerStatusPoint);
			this.gbPlayerStats.Controls.Add(this.tbAddMaxHPPerStatusPoint_);
			this.gbPlayerStats.Controls.Add(this.tbStatusPointPerLevel_);
			this.gbPlayerStats.Controls.Add(this.tbAddWorkSpeedPerStatusPoint_);
			this.gbPlayerStats.Controls.Add(this.LAddMaxSPPerStatusPoint);
			this.gbPlayerStats.Controls.Add(this.LAddPowerPerStatusPoint);
			this.gbPlayerStats.Controls.Add(this.tbAddMaxSPPerStatusPoint_);
			this.gbPlayerStats.Controls.Add(this.tbAddMaxInventoryWeightPerStatusPoint_);
			this.gbPlayerStats.Controls.Add(this.tbAddPowerPerStatusPoint_);
			this.gbPlayerStats.Controls.Add(this.tbAddCaptureLevelPerStatusPoint_);
			this.gbPlayerStats.Controls.Add(this.LStatusPointPerLevel);
			this.gbPlayerStats.Controls.Add(this.tbAddMaxHPPerHPRank_);
			this.gbPlayerStats.Controls.Add(this.LAddMaxInventoryWeightPerStatusPoint);
			this.gbPlayerStats.Controls.Add(this.tbAddWorkSpeedPerWorkSpeedRank_);
			this.gbPlayerStats.Controls.Add(this.tbAddDefencePerDefenceRank_);
			this.gbPlayerStats.Controls.Add(this.LAddWorkSpeedPerWorkSpeedRank);
			this.gbPlayerStats.Controls.Add(this.tbAddAttackPerAttackRank_);
			this.gbPlayerStats.Controls.Add(this.LAddCaptureLevelPerStatusPoint);
			this.gbPlayerStats.Controls.Add(this.LAddWorkSpeedPerStatusPoint);
			this.gbPlayerStats.Controls.Add(this.LAddMaxHPPerHPRank);
			this.gbPlayerStats.Controls.Add(this.LAddAttackPerAttackRank);
			this.gbPlayerStats.Controls.Add(this.LAddDefencePerDefenceRank);
			this.gbPlayerStats.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.gbPlayerStats.ForeColor = global::System.Drawing.Color.Yellow;
			this.gbPlayerStats.Location = new global::System.Drawing.Point(6, 26);
			this.gbPlayerStats.Name = "gbPlayerStats";
			this.gbPlayerStats.Size = new global::System.Drawing.Size(381, 302);
			this.gbPlayerStats.TabIndex = 42;
			this.gbPlayerStats.TabStop = false;
			this.gbPlayerStats.Text = "World Stats";
			this.LTechnologyPointUnlockFastTravel.AutoSize = true;
			this.LTechnologyPointUnlockFastTravel.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LTechnologyPointUnlockFastTravel.ForeColor = global::System.Drawing.Color.Cyan;
			this.LTechnologyPointUnlockFastTravel.Location = new global::System.Drawing.Point(181, 175);
			this.LTechnologyPointUnlockFastTravel.Name = "LTechnologyPointUnlockFastTravel";
			this.LTechnologyPointUnlockFastTravel.Size = new global::System.Drawing.Size(176, 12);
			this.LTechnologyPointUnlockFastTravel.TabIndex = 38;
			this.LTechnologyPointUnlockFastTravel.Text = "TechnologyPointUnlockFastTravel";
			this.GetStatsButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.GetStatsButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GetStatsButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GetStatsButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.GetStatsButton.Location = new global::System.Drawing.Point(177, 239);
			this.GetStatsButton.Name = "GetStatsButton";
			this.GetStatsButton.Size = new global::System.Drawing.Size(80, 38);
			this.GetStatsButton.TabIndex = 8;
			this.GetStatsButton.TabStop = false;
			this.GetStatsButton.Text = "Get Stats";
			this.GetStatsButton.UseVisualStyleBackColor = false;
			this.GetStatsButton.Click += new global::System.EventHandler(this.GetStatsButton_Click);
			this.SetStatsButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.SetStatsButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SetStatsButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.SetStatsButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.SetStatsButton.Location = new global::System.Drawing.Point(263, 239);
			this.SetStatsButton.Name = "SetStatsButton";
			this.SetStatsButton.Size = new global::System.Drawing.Size(80, 38);
			this.SetStatsButton.TabIndex = 11;
			this.SetStatsButton.TabStop = false;
			this.SetStatsButton.Text = "Set Stats";
			this.SetStatsButton.UseVisualStyleBackColor = false;
			this.SetStatsButton.Click += new global::System.EventHandler(this.SetStatsButton_Click);
			this.tbTechnologyPoint_UnlockFastTravel_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbTechnologyPoint_UnlockFastTravel_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbTechnologyPoint_UnlockFastTravel_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbTechnologyPoint_UnlockFastTravel_.Location = new global::System.Drawing.Point(230, 190);
			this.tbTechnologyPoint_UnlockFastTravel_.Name = "tbTechnologyPoint_UnlockFastTravel_";
			this.tbTechnologyPoint_UnlockFastTravel_.Size = new global::System.Drawing.Size(67, 21);
			this.tbTechnologyPoint_UnlockFastTravel_.TabIndex = 37;
			this.tbTechnologyPoint_UnlockFastTravel_.TabStop = false;
			this.tbTechnologyPoint_UnlockFastTravel_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.LAddMaxHPPerStatusPoint.AutoSize = true;
			this.LAddMaxHPPerStatusPoint.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LAddMaxHPPerStatusPoint.ForeColor = global::System.Drawing.Color.Cyan;
			this.LAddMaxHPPerStatusPoint.Location = new global::System.Drawing.Point(6, 17);
			this.LAddMaxHPPerStatusPoint.Name = "LAddMaxHPPerStatusPoint";
			this.LAddMaxHPPerStatusPoint.Size = new global::System.Drawing.Size(137, 12);
			this.LAddMaxHPPerStatusPoint.TabIndex = 27;
			this.LAddMaxHPPerStatusPoint.Text = "AddMaxHPPerStatusPoint";
			this.tbAddMaxHPPerStatusPoint_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbAddMaxHPPerStatusPoint_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbAddMaxHPPerStatusPoint_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbAddMaxHPPerStatusPoint_.Location = new global::System.Drawing.Point(39, 34);
			this.tbAddMaxHPPerStatusPoint_.Name = "tbAddMaxHPPerStatusPoint_";
			this.tbAddMaxHPPerStatusPoint_.Size = new global::System.Drawing.Size(67, 21);
			this.tbAddMaxHPPerStatusPoint_.TabIndex = 12;
			this.tbAddMaxHPPerStatusPoint_.TabStop = false;
			this.tbAddMaxHPPerStatusPoint_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.tbStatusPointPerLevel_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbStatusPointPerLevel_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbStatusPointPerLevel_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbStatusPointPerLevel_.Location = new global::System.Drawing.Point(39, 151);
			this.tbStatusPointPerLevel_.Name = "tbStatusPointPerLevel_";
			this.tbStatusPointPerLevel_.Size = new global::System.Drawing.Size(67, 21);
			this.tbStatusPointPerLevel_.TabIndex = 9;
			this.tbStatusPointPerLevel_.TabStop = false;
			this.tbStatusPointPerLevel_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.tbAddWorkSpeedPerStatusPoint_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbAddWorkSpeedPerStatusPoint_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbAddWorkSpeedPerStatusPoint_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbAddWorkSpeedPerStatusPoint_.Location = new global::System.Drawing.Point(39, 229);
			this.tbAddWorkSpeedPerStatusPoint_.Name = "tbAddWorkSpeedPerStatusPoint_";
			this.tbAddWorkSpeedPerStatusPoint_.Size = new global::System.Drawing.Size(67, 21);
			this.tbAddWorkSpeedPerStatusPoint_.TabIndex = 17;
			this.tbAddWorkSpeedPerStatusPoint_.TabStop = false;
			this.tbAddWorkSpeedPerStatusPoint_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.LAddMaxSPPerStatusPoint.AutoSize = true;
			this.LAddMaxSPPerStatusPoint.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LAddMaxSPPerStatusPoint.ForeColor = global::System.Drawing.Color.Cyan;
			this.LAddMaxSPPerStatusPoint.Location = new global::System.Drawing.Point(199, 136);
			this.LAddMaxSPPerStatusPoint.Name = "LAddMaxSPPerStatusPoint";
			this.LAddMaxSPPerStatusPoint.Size = new global::System.Drawing.Size(136, 12);
			this.LAddMaxSPPerStatusPoint.TabIndex = 28;
			this.LAddMaxSPPerStatusPoint.Text = "AddMaxSPPerStatusPoint";
			this.LAddPowerPerStatusPoint.AutoSize = true;
			this.LAddPowerPerStatusPoint.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LAddPowerPerStatusPoint.ForeColor = global::System.Drawing.Color.Cyan;
			this.LAddPowerPerStatusPoint.Location = new global::System.Drawing.Point(6, 97);
			this.LAddPowerPerStatusPoint.Name = "LAddPowerPerStatusPoint";
			this.LAddPowerPerStatusPoint.Size = new global::System.Drawing.Size(131, 12);
			this.LAddPowerPerStatusPoint.TabIndex = 29;
			this.LAddPowerPerStatusPoint.Text = "AddPowerPerStatusPoint";
			this.tbAddMaxSPPerStatusPoint_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbAddMaxSPPerStatusPoint_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbAddMaxSPPerStatusPoint_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbAddMaxSPPerStatusPoint_.Location = new global::System.Drawing.Point(230, 151);
			this.tbAddMaxSPPerStatusPoint_.Name = "tbAddMaxSPPerStatusPoint_";
			this.tbAddMaxSPPerStatusPoint_.Size = new global::System.Drawing.Size(67, 21);
			this.tbAddMaxSPPerStatusPoint_.TabIndex = 13;
			this.tbAddMaxSPPerStatusPoint_.TabStop = false;
			this.tbAddMaxSPPerStatusPoint_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.tbAddMaxInventoryWeightPerStatusPoint_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbAddMaxInventoryWeightPerStatusPoint_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbAddMaxInventoryWeightPerStatusPoint_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbAddMaxInventoryWeightPerStatusPoint_.Location = new global::System.Drawing.Point(230, 34);
			this.tbAddMaxInventoryWeightPerStatusPoint_.Name = "tbAddMaxInventoryWeightPerStatusPoint_";
			this.tbAddMaxInventoryWeightPerStatusPoint_.Size = new global::System.Drawing.Size(67, 21);
			this.tbAddMaxInventoryWeightPerStatusPoint_.TabIndex = 15;
			this.tbAddMaxInventoryWeightPerStatusPoint_.TabStop = false;
			this.tbAddMaxInventoryWeightPerStatusPoint_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.tbAddPowerPerStatusPoint_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbAddPowerPerStatusPoint_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbAddPowerPerStatusPoint_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbAddPowerPerStatusPoint_.Location = new global::System.Drawing.Point(39, 112);
			this.tbAddPowerPerStatusPoint_.Name = "tbAddPowerPerStatusPoint_";
			this.tbAddPowerPerStatusPoint_.Size = new global::System.Drawing.Size(67, 21);
			this.tbAddPowerPerStatusPoint_.TabIndex = 14;
			this.tbAddPowerPerStatusPoint_.TabStop = false;
			this.tbAddPowerPerStatusPoint_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.tbAddCaptureLevelPerStatusPoint_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbAddCaptureLevelPerStatusPoint_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbAddCaptureLevelPerStatusPoint_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbAddCaptureLevelPerStatusPoint_.Location = new global::System.Drawing.Point(230, 112);
			this.tbAddCaptureLevelPerStatusPoint_.Name = "tbAddCaptureLevelPerStatusPoint_";
			this.tbAddCaptureLevelPerStatusPoint_.Size = new global::System.Drawing.Size(67, 21);
			this.tbAddCaptureLevelPerStatusPoint_.TabIndex = 16;
			this.tbAddCaptureLevelPerStatusPoint_.TabStop = false;
			this.tbAddCaptureLevelPerStatusPoint_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.LStatusPointPerLevel.AutoSize = true;
			this.LStatusPointPerLevel.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LStatusPointPerLevel.ForeColor = global::System.Drawing.Color.Cyan;
			this.LStatusPointPerLevel.Location = new global::System.Drawing.Point(22, 136);
			this.LStatusPointPerLevel.Name = "LStatusPointPerLevel";
			this.LStatusPointPerLevel.Size = new global::System.Drawing.Size(108, 12);
			this.LStatusPointPerLevel.TabIndex = 26;
			this.LStatusPointPerLevel.Text = "StatusPointPerLevel";
			this.tbAddMaxHPPerHPRank_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbAddMaxHPPerHPRank_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbAddMaxHPPerHPRank_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbAddMaxHPPerHPRank_.Location = new global::System.Drawing.Point(39, 73);
			this.tbAddMaxHPPerHPRank_.Name = "tbAddMaxHPPerHPRank_";
			this.tbAddMaxHPPerHPRank_.Size = new global::System.Drawing.Size(67, 21);
			this.tbAddMaxHPPerHPRank_.TabIndex = 18;
			this.tbAddMaxHPPerHPRank_.TabStop = false;
			this.tbAddMaxHPPerHPRank_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.LAddMaxInventoryWeightPerStatusPoint.AutoSize = true;
			this.LAddMaxInventoryWeightPerStatusPoint.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LAddMaxInventoryWeightPerStatusPoint.ForeColor = global::System.Drawing.Color.Cyan;
			this.LAddMaxInventoryWeightPerStatusPoint.Location = new global::System.Drawing.Point(166, 17);
			this.LAddMaxInventoryWeightPerStatusPoint.Name = "LAddMaxInventoryWeightPerStatusPoint";
			this.LAddMaxInventoryWeightPerStatusPoint.Size = new global::System.Drawing.Size(205, 12);
			this.LAddMaxInventoryWeightPerStatusPoint.TabIndex = 30;
			this.LAddMaxInventoryWeightPerStatusPoint.Text = "AddMaxInventoryWeightPerStatusPoint";
			this.tbAddWorkSpeedPerWorkSpeedRank_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbAddWorkSpeedPerWorkSpeedRank_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbAddWorkSpeedPerWorkSpeedRank_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbAddWorkSpeedPerWorkSpeedRank_.Location = new global::System.Drawing.Point(230, 73);
			this.tbAddWorkSpeedPerWorkSpeedRank_.Name = "tbAddWorkSpeedPerWorkSpeedRank_";
			this.tbAddWorkSpeedPerWorkSpeedRank_.Size = new global::System.Drawing.Size(67, 21);
			this.tbAddWorkSpeedPerWorkSpeedRank_.TabIndex = 21;
			this.tbAddWorkSpeedPerWorkSpeedRank_.TabStop = false;
			this.tbAddWorkSpeedPerWorkSpeedRank_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.tbAddDefencePerDefenceRank_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbAddDefencePerDefenceRank_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbAddDefencePerDefenceRank_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbAddDefencePerDefenceRank_.Location = new global::System.Drawing.Point(39, 271);
			this.tbAddDefencePerDefenceRank_.Name = "tbAddDefencePerDefenceRank_";
			this.tbAddDefencePerDefenceRank_.Size = new global::System.Drawing.Size(67, 21);
			this.tbAddDefencePerDefenceRank_.TabIndex = 20;
			this.tbAddDefencePerDefenceRank_.TabStop = false;
			this.tbAddDefencePerDefenceRank_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.LAddWorkSpeedPerWorkSpeedRank.AutoSize = true;
			this.LAddWorkSpeedPerWorkSpeedRank.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LAddWorkSpeedPerWorkSpeedRank.ForeColor = global::System.Drawing.Color.Cyan;
			this.LAddWorkSpeedPerWorkSpeedRank.Location = new global::System.Drawing.Point(170, 58);
			this.LAddWorkSpeedPerWorkSpeedRank.Name = "LAddWorkSpeedPerWorkSpeedRank";
			this.LAddWorkSpeedPerWorkSpeedRank.Size = new global::System.Drawing.Size(179, 12);
			this.LAddWorkSpeedPerWorkSpeedRank.TabIndex = 36;
			this.LAddWorkSpeedPerWorkSpeedRank.Text = "AddWorkSpeedPerWorkSpeedRank";
			this.tbAddAttackPerAttackRank_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbAddAttackPerAttackRank_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbAddAttackPerAttackRank_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbAddAttackPerAttackRank_.Location = new global::System.Drawing.Point(39, 190);
			this.tbAddAttackPerAttackRank_.Name = "tbAddAttackPerAttackRank_";
			this.tbAddAttackPerAttackRank_.Size = new global::System.Drawing.Size(67, 21);
			this.tbAddAttackPerAttackRank_.TabIndex = 19;
			this.tbAddAttackPerAttackRank_.TabStop = false;
			this.tbAddAttackPerAttackRank_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.LAddCaptureLevelPerStatusPoint.AutoSize = true;
			this.LAddCaptureLevelPerStatusPoint.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LAddCaptureLevelPerStatusPoint.ForeColor = global::System.Drawing.Color.Cyan;
			this.LAddCaptureLevelPerStatusPoint.Location = new global::System.Drawing.Point(181, 97);
			this.LAddCaptureLevelPerStatusPoint.Name = "LAddCaptureLevelPerStatusPoint";
			this.LAddCaptureLevelPerStatusPoint.Size = new global::System.Drawing.Size(168, 12);
			this.LAddCaptureLevelPerStatusPoint.TabIndex = 31;
			this.LAddCaptureLevelPerStatusPoint.Text = "AddCaptureLevelPerStatusPoint";
			this.LAddWorkSpeedPerStatusPoint.AutoSize = true;
			this.LAddWorkSpeedPerStatusPoint.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LAddWorkSpeedPerStatusPoint.ForeColor = global::System.Drawing.Color.Cyan;
			this.LAddWorkSpeedPerStatusPoint.Location = new global::System.Drawing.Point(6, 214);
			this.LAddWorkSpeedPerStatusPoint.Name = "LAddWorkSpeedPerStatusPoint";
			this.LAddWorkSpeedPerStatusPoint.Size = new global::System.Drawing.Size(157, 12);
			this.LAddWorkSpeedPerStatusPoint.TabIndex = 32;
			this.LAddWorkSpeedPerStatusPoint.Text = "AddWorkSpeedPerStatusPoint";
			this.LAddMaxHPPerHPRank.AutoSize = true;
			this.LAddMaxHPPerHPRank.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LAddMaxHPPerHPRank.ForeColor = global::System.Drawing.Color.Cyan;
			this.LAddMaxHPPerHPRank.Location = new global::System.Drawing.Point(16, 58);
			this.LAddMaxHPPerHPRank.Name = "LAddMaxHPPerHPRank";
			this.LAddMaxHPPerHPRank.Size = new global::System.Drawing.Size(118, 12);
			this.LAddMaxHPPerHPRank.TabIndex = 33;
			this.LAddMaxHPPerHPRank.Text = "AddMaxHPPerHPRank";
			this.LAddAttackPerAttackRank.AutoSize = true;
			this.LAddAttackPerAttackRank.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LAddAttackPerAttackRank.ForeColor = global::System.Drawing.Color.Cyan;
			this.LAddAttackPerAttackRank.Location = new global::System.Drawing.Point(8, 175);
			this.LAddAttackPerAttackRank.Name = "LAddAttackPerAttackRank";
			this.LAddAttackPerAttackRank.Size = new global::System.Drawing.Size(135, 12);
			this.LAddAttackPerAttackRank.TabIndex = 34;
			this.LAddAttackPerAttackRank.Text = "AddAttackPerAttackRank";
			this.LAddDefencePerDefenceRank.AutoSize = true;
			this.LAddDefencePerDefenceRank.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LAddDefencePerDefenceRank.ForeColor = global::System.Drawing.Color.Cyan;
			this.LAddDefencePerDefenceRank.Location = new global::System.Drawing.Point(6, 256);
			this.LAddDefencePerDefenceRank.Name = "LAddDefencePerDefenceRank";
			this.LAddDefencePerDefenceRank.Size = new global::System.Drawing.Size(149, 12);
			this.LAddDefencePerDefenceRank.TabIndex = 35;
			this.LAddDefencePerDefenceRank.Text = "AddDefencePerDefenceRank";
			this.gbXP.Controls.Add(this.GetXPButton);
			this.gbXP.Controls.Add(this.LBuildXP);
			this.gbXP.Controls.Add(this.SetXPButton);
			this.gbXP.Controls.Add(this.tbBuildXP_);
			this.gbXP.Controls.Add(this.tbCraftXP_);
			this.gbXP.Controls.Add(this.LCraftXP);
			this.gbXP.Controls.Add(this.tbPickupItemOnLevelExp_);
			this.gbXP.Controls.Add(this.LPickupItemOnLevelExp);
			this.gbXP.Controls.Add(this.tbMapObjectDestroyProceedExp_);
			this.gbXP.Controls.Add(this.LMapObjectDestroyProceedExp);
			this.gbXP.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.gbXP.ForeColor = global::System.Drawing.Color.Yellow;
			this.gbXP.Location = new global::System.Drawing.Point(6, 334);
			this.gbXP.Name = "gbXP";
			this.gbXP.Size = new global::System.Drawing.Size(343, 110);
			this.gbXP.TabIndex = 41;
			this.gbXP.TabStop = false;
			this.gbXP.Text = "World XP";
			this.GetXPButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.GetXPButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GetXPButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GetXPButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.GetXPButton.Location = new global::System.Drawing.Point(6, 59);
			this.GetXPButton.Name = "GetXPButton";
			this.GetXPButton.Size = new global::System.Drawing.Size(74, 38);
			this.GetXPButton.TabIndex = 43;
			this.GetXPButton.TabStop = false;
			this.GetXPButton.Text = "Get Stats";
			this.GetXPButton.UseVisualStyleBackColor = false;
			this.GetXPButton.Click += new global::System.EventHandler(this.GetXPButton_Click);
			this.LBuildXP.AutoSize = true;
			this.LBuildXP.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LBuildXP.ForeColor = global::System.Drawing.Color.Cyan;
			this.LBuildXP.Location = new global::System.Drawing.Point(17, 16);
			this.LBuildXP.Name = "LBuildXP";
			this.LBuildXP.Size = new global::System.Drawing.Size(44, 12);
			this.LBuildXP.TabIndex = 37;
			this.LBuildXP.Text = "BuildXP";
			this.SetXPButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.SetXPButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SetXPButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.SetXPButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.SetXPButton.Location = new global::System.Drawing.Point(86, 59);
			this.SetXPButton.Name = "SetXPButton";
			this.SetXPButton.Size = new global::System.Drawing.Size(74, 38);
			this.SetXPButton.TabIndex = 44;
			this.SetXPButton.TabStop = false;
			this.SetXPButton.Text = "Set Stats";
			this.SetXPButton.UseVisualStyleBackColor = false;
			this.SetXPButton.Click += new global::System.EventHandler(this.SetXPButton_Click);
			this.tbBuildXP_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbBuildXP_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbBuildXP_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbBuildXP_.Location = new global::System.Drawing.Point(6, 31);
			this.tbBuildXP_.Name = "tbBuildXP_";
			this.tbBuildXP_.Size = new global::System.Drawing.Size(67, 21);
			this.tbBuildXP_.TabIndex = 22;
			this.tbBuildXP_.TabStop = false;
			this.tbBuildXP_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.tbCraftXP_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbCraftXP_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbCraftXP_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbCraftXP_.Location = new global::System.Drawing.Point(82, 31);
			this.tbCraftXP_.Name = "tbCraftXP_";
			this.tbCraftXP_.Size = new global::System.Drawing.Size(67, 21);
			this.tbCraftXP_.TabIndex = 23;
			this.tbCraftXP_.TabStop = false;
			this.tbCraftXP_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.LCraftXP.AutoSize = true;
			this.LCraftXP.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LCraftXP.ForeColor = global::System.Drawing.Color.Cyan;
			this.LCraftXP.Location = new global::System.Drawing.Point(92, 16);
			this.LCraftXP.Name = "LCraftXP";
			this.LCraftXP.Size = new global::System.Drawing.Size(44, 12);
			this.LCraftXP.TabIndex = 38;
			this.LCraftXP.Text = "CraftXP";
			this.tbPickupItemOnLevelExp_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbPickupItemOnLevelExp_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbPickupItemOnLevelExp_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbPickupItemOnLevelExp_.Location = new global::System.Drawing.Point(161, 31);
			this.tbPickupItemOnLevelExp_.Name = "tbPickupItemOnLevelExp_";
			this.tbPickupItemOnLevelExp_.Size = new global::System.Drawing.Size(67, 21);
			this.tbPickupItemOnLevelExp_.TabIndex = 24;
			this.tbPickupItemOnLevelExp_.TabStop = false;
			this.tbPickupItemOnLevelExp_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.LPickupItemOnLevelExp.AutoSize = true;
			this.LPickupItemOnLevelExp.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LPickupItemOnLevelExp.ForeColor = global::System.Drawing.Color.Cyan;
			this.LPickupItemOnLevelExp.Location = new global::System.Drawing.Point(156, 16);
			this.LPickupItemOnLevelExp.Name = "LPickupItemOnLevelExp";
			this.LPickupItemOnLevelExp.Size = new global::System.Drawing.Size(82, 12);
			this.LPickupItemOnLevelExp.TabIndex = 39;
			this.LPickupItemOnLevelExp.Text = "PickupItemExp";
			this.tbMapObjectDestroyProceedExp_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbMapObjectDestroyProceedExp_.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbMapObjectDestroyProceedExp_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbMapObjectDestroyProceedExp_.Location = new global::System.Drawing.Point(254, 31);
			this.tbMapObjectDestroyProceedExp_.Name = "tbMapObjectDestroyProceedExp_";
			this.tbMapObjectDestroyProceedExp_.Size = new global::System.Drawing.Size(67, 21);
			this.tbMapObjectDestroyProceedExp_.TabIndex = 25;
			this.tbMapObjectDestroyProceedExp_.TabStop = false;
			this.tbMapObjectDestroyProceedExp_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.LMapObjectDestroyProceedExp.AutoSize = true;
			this.LMapObjectDestroyProceedExp.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LMapObjectDestroyProceedExp.ForeColor = global::System.Drawing.Color.Cyan;
			this.LMapObjectDestroyProceedExp.Location = new global::System.Drawing.Point(242, 16);
			this.LMapObjectDestroyProceedExp.Name = "LMapObjectDestroyProceedExp";
			this.LMapObjectDestroyProceedExp.Size = new global::System.Drawing.Size(86, 12);
			this.LMapObjectDestroyProceedExp.TabIndex = 40;
			this.LMapObjectDestroyProceedExp.Text = "ObjctDstroyExp";
			this.RarePalAppearanceBox.AutoSize = true;
			this.RarePalAppearanceBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.RarePalAppearanceBox.FlatAppearance.BorderSize = 2;
			this.RarePalAppearanceBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.RarePalAppearanceBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.RarePalAppearanceBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.RarePalAppearanceBox.ForeColor = global::System.Drawing.Color.Red;
			this.RarePalAppearanceBox.Location = new global::System.Drawing.Point(6, 448);
			this.RarePalAppearanceBox.Name = "RarePalAppearanceBox";
			this.RarePalAppearanceBox.Size = new global::System.Drawing.Size(151, 17);
			this.RarePalAppearanceBox.TabIndex = 3;
			this.RarePalAppearanceBox.Text = "Rare Pals + Max Level";
			this.RarePalAppearanceBox.UseVisualStyleBackColor = true;
			this.InstaFarmBox.AutoSize = true;
			this.InstaFarmBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.InstaFarmBox.FlatAppearance.BorderSize = 2;
			this.InstaFarmBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.InstaFarmBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.InstaFarmBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.InstaFarmBox.ForeColor = global::System.Drawing.Color.Red;
			this.InstaFarmBox.Location = new global::System.Drawing.Point(163, 448);
			this.InstaFarmBox.Name = "InstaFarmBox";
			this.InstaFarmBox.Size = new global::System.Drawing.Size(95, 17);
			this.InstaFarmBox.TabIndex = 45;
			this.InstaFarmBox.Text = "Instant Farm";
			this.InstaFarmBox.UseVisualStyleBackColor = true;
			this.CatchRateBox.AutoSize = true;
			this.CatchRateBox.FlatAppearance.BorderColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.CatchRateBox.FlatAppearance.BorderSize = 2;
			this.CatchRateBox.FlatAppearance.CheckedBackColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.CatchRateBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.CatchRateBox.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.CatchRateBox.ForeColor = global::System.Drawing.Color.Red;
			this.CatchRateBox.Location = new global::System.Drawing.Point(264, 448);
			this.CatchRateBox.Name = "CatchRateBox";
			this.CatchRateBox.Size = new global::System.Drawing.Size(123, 17);
			this.CatchRateBox.TabIndex = 2;
			this.CatchRateBox.Text = "100% Catch Rate";
			this.CatchRateBox.UseVisualStyleBackColor = true;
			this.tabPageBase.BackColor = global::System.Drawing.Color.Black;
			this.tabPageBase.Controls.Add(this.groupBox9);
			this.tabPageBase.Location = new global::System.Drawing.Point(4, 22);
			this.tabPageBase.Name = "tabPageBase";
			this.tabPageBase.Size = new global::System.Drawing.Size(411, 346);
			this.tabPageBase.TabIndex = 5;
			this.tabPageBase.Text = "Base";
			this.groupBox9.Controls.Add(this.GetBaseStatsButton);
			this.groupBox9.Controls.Add(this.BaseResetBuildRange);
			this.groupBox9.Controls.Add(this.SetBaseStatsButton);
			this.groupBox9.Controls.Add(this.BaseInfBuildRange);
			this.groupBox9.Controls.Add(this.tbInstallDinstanceFromOwner_);
			this.groupBox9.Controls.Add(this.label11);
			this.groupBox9.Font = new global::System.Drawing.Font("Verdana", 12f, global::System.Drawing.FontStyle.Bold);
			this.groupBox9.ForeColor = global::System.Drawing.Color.Yellow;
			this.groupBox9.Location = new global::System.Drawing.Point(6, 6);
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.Size = new global::System.Drawing.Size(241, 149);
			this.groupBox9.TabIndex = 83;
			this.groupBox9.TabStop = false;
			this.groupBox9.Text = "Camp";
			this.GetBaseStatsButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.GetBaseStatsButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GetBaseStatsButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GetBaseStatsButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.GetBaseStatsButton.Location = new global::System.Drawing.Point(6, 26);
			this.GetBaseStatsButton.Name = "GetBaseStatsButton";
			this.GetBaseStatsButton.Size = new global::System.Drawing.Size(108, 38);
			this.GetBaseStatsButton.TabIndex = 79;
			this.GetBaseStatsButton.TabStop = false;
			this.GetBaseStatsButton.Text = "Get Stats";
			this.GetBaseStatsButton.UseVisualStyleBackColor = false;
			this.GetBaseStatsButton.Click += new global::System.EventHandler(this.GetBaseStatsButton_Click);
			this.BaseResetBuildRange.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.BaseResetBuildRange.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.BaseResetBuildRange.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.BaseResetBuildRange.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.BaseResetBuildRange.Location = new global::System.Drawing.Point(120, 98);
			this.BaseResetBuildRange.Name = "BaseResetBuildRange";
			this.BaseResetBuildRange.Size = new global::System.Drawing.Size(108, 38);
			this.BaseResetBuildRange.TabIndex = 82;
			this.BaseResetBuildRange.TabStop = false;
			this.BaseResetBuildRange.Text = "Reset Build Range";
			this.BaseResetBuildRange.UseVisualStyleBackColor = false;
			this.SetBaseStatsButton.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.SetBaseStatsButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.SetBaseStatsButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.SetBaseStatsButton.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.SetBaseStatsButton.Location = new global::System.Drawing.Point(120, 26);
			this.SetBaseStatsButton.Name = "SetBaseStatsButton";
			this.SetBaseStatsButton.Size = new global::System.Drawing.Size(108, 38);
			this.SetBaseStatsButton.TabIndex = 80;
			this.SetBaseStatsButton.TabStop = false;
			this.SetBaseStatsButton.Text = "Set Stats";
			this.SetBaseStatsButton.UseVisualStyleBackColor = false;
			this.SetBaseStatsButton.Click += new global::System.EventHandler(this.SetBaseStatsButton_Click);
			this.BaseInfBuildRange.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.BaseInfBuildRange.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.BaseInfBuildRange.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.BaseInfBuildRange.ForeColor = global::System.Drawing.Color.FromArgb(0, 192, 0);
			this.BaseInfBuildRange.Location = new global::System.Drawing.Point(6, 98);
			this.BaseInfBuildRange.Name = "BaseInfBuildRange";
			this.BaseInfBuildRange.Size = new global::System.Drawing.Size(108, 38);
			this.BaseInfBuildRange.TabIndex = 81;
			this.BaseInfBuildRange.TabStop = false;
			this.BaseInfBuildRange.Text = "Infinite Build Range";
			this.BaseInfBuildRange.UseVisualStyleBackColor = false;
			this.tbInstallDinstanceFromOwner_.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.tbInstallDinstanceFromOwner_.Font = new global::System.Drawing.Font("Verdana", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tbInstallDinstanceFromOwner_.ForeColor = global::System.Drawing.Color.Cyan;
			this.tbInstallDinstanceFromOwner_.Location = new global::System.Drawing.Point(161, 70);
			this.tbInstallDinstanceFromOwner_.Name = "tbInstallDinstanceFromOwner_";
			this.tbInstallDinstanceFromOwner_.Size = new global::System.Drawing.Size(67, 22);
			this.tbInstallDinstanceFromOwner_.TabIndex = 77;
			this.tbInstallDinstanceFromOwner_.TabStop = false;
			this.tbInstallDinstanceFromOwner_.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.label11.AutoSize = true;
			this.label11.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label11.ForeColor = global::System.Drawing.Color.Cyan;
			this.label11.Location = new global::System.Drawing.Point(9, 75);
			this.label11.Name = "label11";
			this.label11.Size = new global::System.Drawing.Size(146, 12);
			this.label11.TabIndex = 78;
			this.label11.Text = "Install Distance from Owner";
			this.tabPageMenuSettings.BackColor = global::System.Drawing.Color.Black;
			this.tabPageMenuSettings.Controls.Add(this.ShowHotkeyBox);
			this.tabPageMenuSettings.Controls.Add(this.ShowWatermarkBox);
			this.tabPageMenuSettings.Location = new global::System.Drawing.Point(4, 22);
			this.tabPageMenuSettings.Name = "tabPageMenuSettings";
			this.tabPageMenuSettings.Size = new global::System.Drawing.Size(411, 346);
			this.tabPageMenuSettings.TabIndex = 6;
			this.tabPageMenuSettings.Text = "Menu Settings";
			this.ShowHotkeyBox.AutoSize = true;
			this.ShowHotkeyBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ShowHotkeyBox.Font = new global::System.Drawing.Font("Verdana", 8.25f);
			this.ShowHotkeyBox.ForeColor = global::System.Drawing.Color.Red;
			this.ShowHotkeyBox.Location = new global::System.Drawing.Point(6, 29);
			this.ShowHotkeyBox.Name = "ShowHotkeyBox";
			this.ShowHotkeyBox.Size = new global::System.Drawing.Size(104, 17);
			this.ShowHotkeyBox.TabIndex = 10;
			this.ShowHotkeyBox.Text = "Show Hotkeys";
			this.ShowHotkeyBox.UseVisualStyleBackColor = true;
			this.ShowHotkeyBox.CheckedChanged += new global::System.EventHandler(this.ShowHotkeyBox_CheckedChanged);
			this.ShowWatermarkBox.AutoSize = true;
			this.ShowWatermarkBox.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ShowWatermarkBox.Font = new global::System.Drawing.Font("Verdana", 8.25f);
			this.ShowWatermarkBox.ForeColor = global::System.Drawing.Color.Red;
			this.ShowWatermarkBox.Location = new global::System.Drawing.Point(6, 6);
			this.ShowWatermarkBox.Name = "ShowWatermarkBox";
			this.ShowWatermarkBox.Size = new global::System.Drawing.Size(121, 17);
			this.ShowWatermarkBox.TabIndex = 9;
			this.ShowWatermarkBox.Text = "Show Watermark";
			this.ShowWatermarkBox.UseVisualStyleBackColor = true;
			this.ShowWatermarkBox.CheckedChanged += new global::System.EventHandler(this.ShowWatermarkBox_CheckedChanged);
			this.InventoryTabPageButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.InventoryTabPageButton.Font = new global::System.Drawing.Font("Verdana", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.InventoryTabPageButton.ForeColor = global::System.Drawing.Color.Lime;
			this.InventoryTabPageButton.Location = new global::System.Drawing.Point(12, 141);
			this.InventoryTabPageButton.Name = "InventoryTabPageButton";
			this.InventoryTabPageButton.Size = new global::System.Drawing.Size(91, 37);
			this.InventoryTabPageButton.TabIndex = 8;
			this.InventoryTabPageButton.TabStop = false;
			this.InventoryTabPageButton.Text = "Inventory";
			this.InventoryTabPageButton.UseVisualStyleBackColor = true;
			this.PalEditorTabPageButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.PalEditorTabPageButton.Font = new global::System.Drawing.Font("Verdana", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.PalEditorTabPageButton.ForeColor = global::System.Drawing.Color.Lime;
			this.PalEditorTabPageButton.Location = new global::System.Drawing.Point(12, 184);
			this.PalEditorTabPageButton.Name = "PalEditorTabPageButton";
			this.PalEditorTabPageButton.Size = new global::System.Drawing.Size(91, 37);
			this.PalEditorTabPageButton.TabIndex = 9;
			this.PalEditorTabPageButton.TabStop = false;
			this.PalEditorTabPageButton.Text = "Pal Editor";
			this.PalEditorTabPageButton.UseVisualStyleBackColor = true;
			this.WorldTabPageButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.WorldTabPageButton.Font = new global::System.Drawing.Font("Verdana", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.WorldTabPageButton.ForeColor = global::System.Drawing.Color.Lime;
			this.WorldTabPageButton.Location = new global::System.Drawing.Point(12, 227);
			this.WorldTabPageButton.Name = "WorldTabPageButton";
			this.WorldTabPageButton.Size = new global::System.Drawing.Size(91, 37);
			this.WorldTabPageButton.TabIndex = 10;
			this.WorldTabPageButton.TabStop = false;
			this.WorldTabPageButton.Text = "World";
			this.WorldTabPageButton.UseVisualStyleBackColor = true;
			this.BaseTabPageButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.BaseTabPageButton.Font = new global::System.Drawing.Font("Verdana", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.BaseTabPageButton.ForeColor = global::System.Drawing.Color.Lime;
			this.BaseTabPageButton.Location = new global::System.Drawing.Point(12, 270);
			this.BaseTabPageButton.Name = "BaseTabPageButton";
			this.BaseTabPageButton.Size = new global::System.Drawing.Size(91, 37);
			this.BaseTabPageButton.TabIndex = 11;
			this.BaseTabPageButton.TabStop = false;
			this.BaseTabPageButton.Text = "Base";
			this.BaseTabPageButton.UseVisualStyleBackColor = true;
			this.MenuSettingsTabPageButton.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.MenuSettingsTabPageButton.Font = new global::System.Drawing.Font("Verdana", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.MenuSettingsTabPageButton.ForeColor = global::System.Drawing.Color.FromArgb(255, 128, 0);
			this.MenuSettingsTabPageButton.Location = new global::System.Drawing.Point(12, 313);
			this.MenuSettingsTabPageButton.Name = "MenuSettingsTabPageButton";
			this.MenuSettingsTabPageButton.Size = new global::System.Drawing.Size(91, 37);
			this.MenuSettingsTabPageButton.TabIndex = 12;
			this.MenuSettingsTabPageButton.TabStop = false;
			this.MenuSettingsTabPageButton.Text = "Menu Settings";
			this.MenuSettingsTabPageButton.UseVisualStyleBackColor = true;
			this.HidingPanel.BackColor = global::System.Drawing.Color.Black;
			this.HidingPanel.Location = new global::System.Drawing.Point(107, 9);
			this.HidingPanel.Name = "HidingPanel";
			this.HidingPanel.Size = new global::System.Drawing.Size(384, 23);
			this.HidingPanel.TabIndex = 13;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.Black;
			base.ClientSize = new global::System.Drawing.Size(542, 580);
			base.Controls.Add(this.HidingPanel);
			base.Controls.Add(this.MenuSettingsTabPageButton);
			base.Controls.Add(this.BaseTabPageButton);
			base.Controls.Add(this.WorldTabPageButton);
			base.Controls.Add(this.PalEditorTabPageButton);
			base.Controls.Add(this.InventoryTabPageButton);
			base.Controls.Add(this.CheatMenuTabControl);
			base.Controls.Add(this.WeaponTabPageButton);
			base.Controls.Add(this.PlayerTabPageButton);
			base.Controls.Add(this.MoveArrowPicture);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "CheatMenu";
			base.Opacity = 0.85;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "CheatMenu";
			base.TopMost = true;
			((global::System.ComponentModel.ISupportInitialize)this.MoveArrowPicture).EndInit();
			this.CheatMenuTabControl.ResumeLayout(false);
			this.tabPagePlayer.ResumeLayout(false);
			this.tabPagePlayer.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.SpeedBar).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.SpeedBar2).EndInit();
			this.tabPageWeapon.ResumeLayout(false);
			this.groupBox8.ResumeLayout(false);
			this.tabPageInventory.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.gbItemSlotStack.ResumeLayout(false);
			this.gbItemSlotStack.PerformLayout();
			this.tabPagePalEditor.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox7.ResumeLayout(false);
			this.groupBox5.ResumeLayout(false);
			this.groupBox5.PerformLayout();
			this.groupBox6.ResumeLayout(false);
			this.groupBox6.PerformLayout();
			this.tabPageWorld.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.gbPlayerStats.ResumeLayout(false);
			this.gbPlayerStats.PerformLayout();
			this.gbXP.ResumeLayout(false);
			this.gbXP.PerformLayout();
			this.tabPageBase.ResumeLayout(false);
			this.groupBox9.ResumeLayout(false);
			this.groupBox9.PerformLayout();
			this.tabPageMenuSettings.ResumeLayout(false);
			this.tabPageMenuSettings.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x04000018 RID: 24
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000019 RID: 25
		private global::System.Windows.Forms.Panel HidingPanel;

		// Token: 0x0400001A RID: 26
		internal global::System.Windows.Forms.CheckBox SpoofPositionBox;

		// Token: 0x0400001B RID: 27
		internal global::System.Windows.Forms.CheckBox FlymodeBox;

		// Token: 0x0400001C RID: 28
		internal global::System.Windows.Forms.CheckBox SpeedhackBox;

		// Token: 0x0400001D RID: 29
		internal global::System.Windows.Forms.CheckBox CarryWeightBox;

		// Token: 0x0400001E RID: 30
		internal global::System.Windows.Forms.CheckBox SuperJumpBox;

		// Token: 0x0400001F RID: 31
		internal global::System.Windows.Forms.CheckBox GodmodeBox;

		// Token: 0x04000020 RID: 32
		internal global::System.Windows.Forms.CheckBox NeverWantedBox;

		// Token: 0x04000021 RID: 33
		internal global::System.Windows.Forms.TabControl CheatMenuTabControl;

		// Token: 0x04000022 RID: 34
		internal global::System.Windows.Forms.CheckBox ShowWatermarkBox;

		// Token: 0x04000023 RID: 35
		internal global::System.Windows.Forms.CheckBox ShowHotkeyBox;

		// Token: 0x04000024 RID: 36
		internal global::System.Windows.Forms.PictureBox MoveArrowPicture;

		// Token: 0x04000025 RID: 37
		internal global::System.Windows.Forms.TabPage tabPageWeapon;

		// Token: 0x04000026 RID: 38
		internal global::System.Windows.Forms.TabPage tabPageInventory;

		// Token: 0x04000027 RID: 39
		internal global::System.Windows.Forms.TabPage tabPagePalEditor;

		// Token: 0x04000028 RID: 40
		internal global::System.Windows.Forms.TabPage tabPageWorld;

		// Token: 0x04000029 RID: 41
		internal global::System.Windows.Forms.TabPage tabPageBase;

		// Token: 0x0400002A RID: 42
		internal global::System.Windows.Forms.TabPage tabPageMenuSettings;

		// Token: 0x0400002B RID: 43
		internal global::System.Windows.Forms.Button PlayerTabPageButton;

		// Token: 0x0400002C RID: 44
		internal global::System.Windows.Forms.Button WeaponTabPageButton;

		// Token: 0x0400002D RID: 45
		internal global::System.Windows.Forms.Button InventoryTabPageButton;

		// Token: 0x0400002E RID: 46
		internal global::System.Windows.Forms.Button PalEditorTabPageButton;

		// Token: 0x0400002F RID: 47
		internal global::System.Windows.Forms.Button WorldTabPageButton;

		// Token: 0x04000030 RID: 48
		internal global::System.Windows.Forms.Button BaseTabPageButton;

		// Token: 0x04000031 RID: 49
		internal global::System.Windows.Forms.Button MenuSettingsTabPageButton;

		// Token: 0x04000032 RID: 50
		internal global::System.Windows.Forms.TabPage tabPagePlayer;

		// Token: 0x04000033 RID: 51
		internal global::System.Windows.Forms.CheckBox BodyTemperatureDamageBox;

		// Token: 0x04000034 RID: 52
		internal global::System.Windows.Forms.CheckBox NoStomachBox;

		// Token: 0x04000035 RID: 53
		internal global::System.Windows.Forms.CheckBox ShieldRegenBox;

		// Token: 0x04000036 RID: 54
		internal global::System.Windows.Forms.CheckBox HealthRegenBox;

		// Token: 0x04000037 RID: 55
		internal global::System.Windows.Forms.CheckBox AIChaseBox;

		// Token: 0x04000038 RID: 56
		internal global::System.Windows.Forms.CheckBox AIIgnoreBox;

		// Token: 0x04000039 RID: 57
		private global::System.Windows.Forms.Label LTimeDilation;

		// Token: 0x0400003A RID: 58
		private global::System.Windows.Forms.Label LTimeDilation2;

		// Token: 0x0400003B RID: 59
		internal global::System.Windows.Forms.CheckBox NoRespawnDelayBox;

		// Token: 0x0400003C RID: 60
		internal global::System.Windows.Forms.CheckBox NoStaminaBox;

		// Token: 0x0400003D RID: 61
		internal global::System.Windows.Forms.CheckBox OneHitBox;

		// Token: 0x0400003E RID: 62
		private global::System.Windows.Forms.GroupBox gbItemSlotStack;

		// Token: 0x0400003F RID: 63
		private global::System.Windows.Forms.TextBox tbStackCount5_;

		// Token: 0x04000040 RID: 64
		private global::System.Windows.Forms.Label label22;

		// Token: 0x04000041 RID: 65
		private global::System.Windows.Forms.TextBox tbStackCount4_;

		// Token: 0x04000042 RID: 66
		private global::System.Windows.Forms.Label label23;

		// Token: 0x04000043 RID: 67
		private global::System.Windows.Forms.TextBox tbStackCount_;

		// Token: 0x04000044 RID: 68
		private global::System.Windows.Forms.TextBox tbStackCount3_;

		// Token: 0x04000045 RID: 69
		private global::System.Windows.Forms.Label LSlot3;

		// Token: 0x04000046 RID: 70
		private global::System.Windows.Forms.Label LSlot1;

		// Token: 0x04000047 RID: 71
		private global::System.Windows.Forms.TextBox tbStackCount2_;

		// Token: 0x04000048 RID: 72
		private global::System.Windows.Forms.Label LSlot2;

		// Token: 0x04000049 RID: 73
		internal global::System.Windows.Forms.Button GiveTechPointsButton;

		// Token: 0x0400004A RID: 74
		internal global::System.Windows.Forms.Button MaxStomachButton;

		// Token: 0x0400004B RID: 75
		internal global::System.Windows.Forms.Button MaxLevelButton;

		// Token: 0x0400004C RID: 76
		internal global::System.Windows.Forms.TrackBar SpeedBar;

		// Token: 0x0400004D RID: 77
		internal global::System.Windows.Forms.TrackBar SpeedBar2;

		// Token: 0x0400004E RID: 78
		internal global::System.Windows.Forms.Button ModWeaponButton;

		// Token: 0x0400004F RID: 79
		private global::System.Windows.Forms.GroupBox groupBox3;

		// Token: 0x04000050 RID: 80
		private global::System.Windows.Forms.GroupBox gbPlayerStats;

		// Token: 0x04000051 RID: 81
		private global::System.Windows.Forms.Label LTechnologyPointUnlockFastTravel;

		// Token: 0x04000052 RID: 82
		private global::System.Windows.Forms.Button GetStatsButton;

		// Token: 0x04000053 RID: 83
		private global::System.Windows.Forms.Button SetStatsButton;

		// Token: 0x04000054 RID: 84
		private global::System.Windows.Forms.TextBox tbTechnologyPoint_UnlockFastTravel_;

		// Token: 0x04000055 RID: 85
		private global::System.Windows.Forms.Label LAddMaxHPPerStatusPoint;

		// Token: 0x04000056 RID: 86
		private global::System.Windows.Forms.TextBox tbAddMaxHPPerStatusPoint_;

		// Token: 0x04000057 RID: 87
		private global::System.Windows.Forms.TextBox tbStatusPointPerLevel_;

		// Token: 0x04000058 RID: 88
		private global::System.Windows.Forms.TextBox tbAddWorkSpeedPerStatusPoint_;

		// Token: 0x04000059 RID: 89
		private global::System.Windows.Forms.Label LAddMaxSPPerStatusPoint;

		// Token: 0x0400005A RID: 90
		private global::System.Windows.Forms.Label LAddPowerPerStatusPoint;

		// Token: 0x0400005B RID: 91
		private global::System.Windows.Forms.TextBox tbAddMaxSPPerStatusPoint_;

		// Token: 0x0400005C RID: 92
		private global::System.Windows.Forms.TextBox tbAddMaxInventoryWeightPerStatusPoint_;

		// Token: 0x0400005D RID: 93
		private global::System.Windows.Forms.TextBox tbAddPowerPerStatusPoint_;

		// Token: 0x0400005E RID: 94
		private global::System.Windows.Forms.TextBox tbAddCaptureLevelPerStatusPoint_;

		// Token: 0x0400005F RID: 95
		private global::System.Windows.Forms.Label LStatusPointPerLevel;

		// Token: 0x04000060 RID: 96
		private global::System.Windows.Forms.TextBox tbAddMaxHPPerHPRank_;

		// Token: 0x04000061 RID: 97
		private global::System.Windows.Forms.Label LAddMaxInventoryWeightPerStatusPoint;

		// Token: 0x04000062 RID: 98
		private global::System.Windows.Forms.TextBox tbAddWorkSpeedPerWorkSpeedRank_;

		// Token: 0x04000063 RID: 99
		private global::System.Windows.Forms.TextBox tbAddDefencePerDefenceRank_;

		// Token: 0x04000064 RID: 100
		private global::System.Windows.Forms.Label LAddWorkSpeedPerWorkSpeedRank;

		// Token: 0x04000065 RID: 101
		private global::System.Windows.Forms.TextBox tbAddAttackPerAttackRank_;

		// Token: 0x04000066 RID: 102
		private global::System.Windows.Forms.Label LAddCaptureLevelPerStatusPoint;

		// Token: 0x04000067 RID: 103
		private global::System.Windows.Forms.Label LAddWorkSpeedPerStatusPoint;

		// Token: 0x04000068 RID: 104
		private global::System.Windows.Forms.Label LAddMaxHPPerHPRank;

		// Token: 0x04000069 RID: 105
		private global::System.Windows.Forms.Label LAddAttackPerAttackRank;

		// Token: 0x0400006A RID: 106
		private global::System.Windows.Forms.Label LAddDefencePerDefenceRank;

		// Token: 0x0400006B RID: 107
		private global::System.Windows.Forms.GroupBox gbXP;

		// Token: 0x0400006C RID: 108
		private global::System.Windows.Forms.Button GetXPButton;

		// Token: 0x0400006D RID: 109
		private global::System.Windows.Forms.Label LBuildXP;

		// Token: 0x0400006E RID: 110
		private global::System.Windows.Forms.Button SetXPButton;

		// Token: 0x0400006F RID: 111
		private global::System.Windows.Forms.TextBox tbBuildXP_;

		// Token: 0x04000070 RID: 112
		private global::System.Windows.Forms.TextBox tbCraftXP_;

		// Token: 0x04000071 RID: 113
		private global::System.Windows.Forms.Label LCraftXP;

		// Token: 0x04000072 RID: 114
		private global::System.Windows.Forms.TextBox tbPickupItemOnLevelExp_;

		// Token: 0x04000073 RID: 115
		private global::System.Windows.Forms.Label LPickupItemOnLevelExp;

		// Token: 0x04000074 RID: 116
		private global::System.Windows.Forms.TextBox tbMapObjectDestroyProceedExp_;

		// Token: 0x04000075 RID: 117
		private global::System.Windows.Forms.Label LMapObjectDestroyProceedExp;

		// Token: 0x04000076 RID: 118
		internal global::System.Windows.Forms.CheckBox RarePalAppearanceBox;

		// Token: 0x04000077 RID: 119
		internal global::System.Windows.Forms.CheckBox InstaFarmBox;

		// Token: 0x04000078 RID: 120
		internal global::System.Windows.Forms.CheckBox CatchRateBox;

		// Token: 0x04000079 RID: 121
		private global::System.Windows.Forms.GroupBox groupBox4;

		// Token: 0x0400007A RID: 122
		private global::System.Windows.Forms.GroupBox groupBox7;

		// Token: 0x0400007B RID: 123
		private global::System.Windows.Forms.Button SetPalInstanceID;

		// Token: 0x0400007C RID: 124
		private global::System.Windows.Forms.Button GetPalInstanceID;

		// Token: 0x0400007D RID: 125
		private global::System.Windows.Forms.GroupBox groupBox5;

		// Token: 0x0400007E RID: 126
		private global::System.Windows.Forms.Button SetPalAttackButton;

		// Token: 0x0400007F RID: 127
		private global::System.Windows.Forms.Label label5;

		// Token: 0x04000080 RID: 128
		private global::System.Windows.Forms.TextBox tbEquipWazaAttackSlot1_;

		// Token: 0x04000081 RID: 129
		private global::System.Windows.Forms.Label label4;

		// Token: 0x04000082 RID: 130
		private global::System.Windows.Forms.TextBox tbEquipWazaAttackSlot2_;

		// Token: 0x04000083 RID: 131
		private global::System.Windows.Forms.TextBox tbEquipWazaAttackSlot3_;

		// Token: 0x04000084 RID: 132
		private global::System.Windows.Forms.Button GetPalAttackButton;

		// Token: 0x04000085 RID: 133
		private global::System.Windows.Forms.Label label6;

		// Token: 0x04000086 RID: 134
		private global::System.Windows.Forms.GroupBox groupBox6;

		// Token: 0x04000087 RID: 135
		private global::System.Windows.Forms.TextBox tbSPSupport_;

		// Token: 0x04000088 RID: 136
		private global::System.Windows.Forms.Label label10;

		// Token: 0x04000089 RID: 137
		private global::System.Windows.Forms.Button SetPalStatsButton;

		// Token: 0x0400008A RID: 138
		private global::System.Windows.Forms.TextBox tbSPRankCraftSpeed_;

		// Token: 0x0400008B RID: 139
		private global::System.Windows.Forms.Label label9;

		// Token: 0x0400008C RID: 140
		private global::System.Windows.Forms.TextBox tbSPRankDefence_;

		// Token: 0x0400008D RID: 141
		private global::System.Windows.Forms.Label label8;

		// Token: 0x0400008E RID: 142
		private global::System.Windows.Forms.TextBox tbSPRankAttack_;

		// Token: 0x0400008F RID: 143
		private global::System.Windows.Forms.Label label7;

		// Token: 0x04000090 RID: 144
		private global::System.Windows.Forms.Button GetPalStatsButton;

		// Token: 0x04000091 RID: 145
		private global::System.Windows.Forms.Button SetBaseStatsButton;

		// Token: 0x04000092 RID: 146
		private global::System.Windows.Forms.Button GetBaseStatsButton;

		// Token: 0x04000093 RID: 147
		private global::System.Windows.Forms.TextBox tbInstallDinstanceFromOwner_;

		// Token: 0x04000094 RID: 148
		private global::System.Windows.Forms.Label label11;

		// Token: 0x04000095 RID: 149
		private global::System.Windows.Forms.GroupBox groupBox1;

		// Token: 0x04000096 RID: 150
		private global::System.Windows.Forms.Label label2;

		// Token: 0x04000097 RID: 151
		private global::System.Windows.Forms.Label label3;

		// Token: 0x04000098 RID: 152
		private global::System.Windows.Forms.Label label12;

		// Token: 0x04000099 RID: 153
		internal global::System.Windows.Forms.Button BaseResetBuildRange;

		// Token: 0x0400009A RID: 154
		internal global::System.Windows.Forms.Button BaseInfBuildRange;

		// Token: 0x0400009B RID: 155
		internal global::System.Windows.Forms.Button GiveWoodButton;

		// Token: 0x0400009C RID: 156
		internal global::System.Windows.Forms.Button GiveGoldButton;

		// Token: 0x0400009D RID: 157
		internal global::System.Windows.Forms.Button GiveSoulsButton;

		// Token: 0x0400009E RID: 158
		internal global::System.Windows.Forms.Button SetInvStatsButton;

		// Token: 0x0400009F RID: 159
		internal global::System.Windows.Forms.Button GetInvStatsButton;

		// Token: 0x040000A0 RID: 160
		internal global::System.Windows.Forms.Button HealPlayerButton;

		// Token: 0x040000A1 RID: 161
		internal global::System.Windows.Forms.Button PalSanityButton;

		// Token: 0x040000A2 RID: 162
		internal global::System.Windows.Forms.Button SetRarePalButton;

		// Token: 0x040000A3 RID: 163
		internal global::System.Windows.Forms.Button PalMaxHPButton;

		// Token: 0x040000A4 RID: 164
		internal global::System.Windows.Forms.Button PalMaxLevelButton;

		// Token: 0x040000A5 RID: 165
		internal global::System.Windows.Forms.Button PalFemaleButton;

		// Token: 0x040000A6 RID: 166
		internal global::System.Windows.Forms.Button PalMaleButton;

		// Token: 0x040000A7 RID: 167
		internal global::System.Windows.Forms.Button PalMaxStomachButton;

		// Token: 0x040000A8 RID: 168
		private global::System.Windows.Forms.GroupBox groupBox2;

		// Token: 0x040000A9 RID: 169
		private global::System.Windows.Forms.GroupBox groupBox8;

		// Token: 0x040000AA RID: 170
		private global::System.Windows.Forms.GroupBox groupBox9;

		// Token: 0x040000AB RID: 171
		internal global::System.Windows.Forms.CheckBox EggHatchBox;
	}
}
