﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace PalHaxv1_1
{
	// Token: 0x02000010 RID: 16
	public static class ConfigurationManager
	{
		// Token: 0x06000245 RID: 581 RVA: 0x00010172 File Offset: 0x0000E372
		public static Keybinds LoadKeybinds(string filePath)
		{
			if (File.Exists(filePath))
			{
				return JsonConvert.DeserializeObject<Keybinds>(File.ReadAllText(filePath));
			}
			return null;
		}
	}
}
