﻿namespace PalHaxv1_1
{
	// Token: 0x02000015 RID: 21
	public partial class Overlay : global::System.Windows.Forms.Form
	{
		// Token: 0x06000287 RID: 647 RVA: 0x00011041 File Offset: 0x0000F241
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000288 RID: 648 RVA: 0x00011060 File Offset: 0x0000F260
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			this.onTickMods = new global::System.Windows.Forms.Timer(this.components);
			this.ConnectionText = new global::System.Windows.Forms.Label();
			this.ConnectionPanel = new global::System.Windows.Forms.Panel();
			this.LSpoofPositionKey = new global::System.Windows.Forms.Label();
			this.LFlymodeKey = new global::System.Windows.Forms.Label();
			this.LSpeedhackKey = new global::System.Windows.Forms.Label();
			this.LSuperJumpKey = new global::System.Windows.Forms.Label();
			this.ConnectionPanel.SuspendLayout();
			base.SuspendLayout();
			this.onTickMods.Tick += new global::System.EventHandler(this.onTickMods_Tick);
			this.ConnectionText.AutoSize = true;
			this.ConnectionText.BackColor = global::System.Drawing.Color.Transparent;
			this.ConnectionText.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ConnectionText.ForeColor = global::System.Drawing.Color.FromArgb(128, 255, 128);
			this.ConnectionText.Location = new global::System.Drawing.Point(4, 1);
			this.ConnectionText.Name = "ConnectionText";
			this.ConnectionText.Size = new global::System.Drawing.Size(53, 12);
			this.ConnectionText.TabIndex = 0;
			this.ConnectionText.Text = "????????";
			this.ConnectionPanel.BackColor = global::System.Drawing.Color.Black;
			this.ConnectionPanel.Controls.Add(this.ConnectionText);
			this.ConnectionPanel.Location = new global::System.Drawing.Point(4, 2);
			this.ConnectionPanel.Name = "ConnectionPanel";
			this.ConnectionPanel.Size = new global::System.Drawing.Size(288, 17);
			this.ConnectionPanel.TabIndex = 2;
			this.LSpoofPositionKey.AutoSize = true;
			this.LSpoofPositionKey.BackColor = global::System.Drawing.Color.Black;
			this.LSpoofPositionKey.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LSpoofPositionKey.ForeColor = global::System.Drawing.Color.Red;
			this.LSpoofPositionKey.Location = new global::System.Drawing.Point(5, 22);
			this.LSpoofPositionKey.Name = "LSpoofPositionKey";
			this.LSpoofPositionKey.Size = new global::System.Drawing.Size(87, 12);
			this.LSpoofPositionKey.TabIndex = 3;
			this.LSpoofPositionKey.Text = "Spoof Position : ";
			this.LFlymodeKey.AutoSize = true;
			this.LFlymodeKey.BackColor = global::System.Drawing.Color.Black;
			this.LFlymodeKey.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LFlymodeKey.ForeColor = global::System.Drawing.Color.Red;
			this.LFlymodeKey.Location = new global::System.Drawing.Point(5, 34);
			this.LFlymodeKey.Name = "LFlymodeKey";
			this.LFlymodeKey.Size = new global::System.Drawing.Size(67, 12);
			this.LFlymodeKey.TabIndex = 4;
			this.LFlymodeKey.Text = "Flymode-- : ";
			this.LSpeedhackKey.AutoSize = true;
			this.LSpeedhackKey.BackColor = global::System.Drawing.Color.Black;
			this.LSpeedhackKey.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LSpeedhackKey.ForeColor = global::System.Drawing.Color.Red;
			this.LSpeedhackKey.Location = new global::System.Drawing.Point(5, 46);
			this.LSpeedhackKey.Name = "LSpeedhackKey";
			this.LSpeedhackKey.Size = new global::System.Drawing.Size(83, 12);
			this.LSpeedhackKey.TabIndex = 5;
			this.LSpeedhackKey.Text = "Speedhack--  : ";
			this.LSuperJumpKey.AutoSize = true;
			this.LSuperJumpKey.BackColor = global::System.Drawing.Color.Black;
			this.LSuperJumpKey.Font = new global::System.Drawing.Font("Verdana", 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LSuperJumpKey.ForeColor = global::System.Drawing.Color.Red;
			this.LSuperJumpKey.Location = new global::System.Drawing.Point(5, 58);
			this.LSuperJumpKey.Name = "LSuperJumpKey";
			this.LSuperJumpKey.Size = new global::System.Drawing.Size(86, 12);
			this.LSuperJumpKey.TabIndex = 6;
			this.LSuperJumpKey.Text = "Super Jump--  : ";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			base.ClientSize = new global::System.Drawing.Size(362, 77);
			base.Controls.Add(this.LSuperJumpKey);
			base.Controls.Add(this.LSpeedhackKey);
			base.Controls.Add(this.LFlymodeKey);
			base.Controls.Add(this.LSpoofPositionKey);
			base.Controls.Add(this.ConnectionPanel);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Overlay";
			base.Opacity = 0.8;
			this.Text = "Overlay";
			base.TopMost = true;
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.Overlay_FormClosing);
			base.Load += new global::System.EventHandler(this.Overlay_Load);
			this.ConnectionPanel.ResumeLayout(false);
			this.ConnectionPanel.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400018B RID: 395
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400018C RID: 396
		private global::System.Windows.Forms.Timer onTickMods;

		// Token: 0x0400018D RID: 397
		private global::System.Windows.Forms.Label ConnectionText;

		// Token: 0x0400018E RID: 398
		private global::System.Windows.Forms.Panel ConnectionPanel;

		// Token: 0x0400018F RID: 399
		private global::System.Windows.Forms.Label LSpoofPositionKey;

		// Token: 0x04000190 RID: 400
		private global::System.Windows.Forms.Label LFlymodeKey;

		// Token: 0x04000191 RID: 401
		private global::System.Windows.Forms.Label LSpeedhackKey;

		// Token: 0x04000192 RID: 402
		private global::System.Windows.Forms.Label LSuperJumpKey;
	}
}
