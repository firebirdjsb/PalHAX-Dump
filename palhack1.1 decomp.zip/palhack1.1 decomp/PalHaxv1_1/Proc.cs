﻿using System;
using System.Diagnostics;

namespace PalHaxv1_1
{
	// Token: 0x02000007 RID: 7
	public class Proc
	{
		// Token: 0x17000004 RID: 4
		// (get) Token: 0x060000A9 RID: 169 RVA: 0x0000CF0C File Offset: 0x0000B10C
		// (set) Token: 0x060000AA RID: 170 RVA: 0x0000CF14 File Offset: 0x0000B114
		public Process Process { get; set; }

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x060000AB RID: 171 RVA: 0x0000CF1D File Offset: 0x0000B11D
		// (set) Token: 0x060000AC RID: 172 RVA: 0x0000CF25 File Offset: 0x0000B125
		public IntPtr Handle { get; set; }

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x060000AD RID: 173 RVA: 0x0000CF2E File Offset: 0x0000B12E
		// (set) Token: 0x060000AE RID: 174 RVA: 0x0000CF36 File Offset: 0x0000B136
		public bool Is64Bit { get; set; }

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x060000AF RID: 175 RVA: 0x0000CF3F File Offset: 0x0000B13F
		// (set) Token: 0x060000B0 RID: 176 RVA: 0x0000CF47 File Offset: 0x0000B147
		public ProcessModule MainModule { get; set; }
	}
}
