﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

// Token: 0x02000002 RID: 2
public class GlobalKeyboardHook : IDisposable
{
	// Token: 0x14000001 RID: 1
	// (add) Token: 0x06000001 RID: 1 RVA: 0x00002048 File Offset: 0x00000248
	// (remove) Token: 0x06000002 RID: 2 RVA: 0x00002080 File Offset: 0x00000280
	public event EventHandler<KeyEventArgs> KeyDown;

	// Token: 0x14000002 RID: 2
	// (add) Token: 0x06000003 RID: 3 RVA: 0x000020B8 File Offset: 0x000002B8
	// (remove) Token: 0x06000004 RID: 4 RVA: 0x000020F0 File Offset: 0x000002F0
	public event EventHandler<KeyEventArgs> KeyUp;

	// Token: 0x06000005 RID: 5 RVA: 0x00002125 File Offset: 0x00000325
	public GlobalKeyboardHook()
	{
		this.keyboardProc = new GlobalKeyboardHook.LowLevelKeyboardProc(this.HookCallback);
		this.hookId = this.SetHook(this.keyboardProc);
	}

	// Token: 0x06000006 RID: 6 RVA: 0x0000215C File Offset: 0x0000035C
	public void Dispose()
	{
		this.Unhook();
	}

	// Token: 0x06000007 RID: 7 RVA: 0x00002164 File Offset: 0x00000364
	public void Unhook()
	{
		if (this.hookId != IntPtr.Zero)
		{
			GlobalKeyboardHook.UnhookWindowsHookEx(this.hookId);
			this.hookId = IntPtr.Zero;
		}
	}

	// Token: 0x06000008 RID: 8 RVA: 0x00002190 File Offset: 0x00000390
	private IntPtr SetHook(GlobalKeyboardHook.LowLevelKeyboardProc proc)
	{
		IntPtr result;
		using (Process currentProcess = Process.GetCurrentProcess())
		{
			using (ProcessModule mainModule = currentProcess.MainModule)
			{
				result = GlobalKeyboardHook.SetWindowsHookEx(13, proc, GlobalKeyboardHook.GetModuleHandle(mainModule.ModuleName), 0U);
			}
		}
		return result;
	}

	// Token: 0x06000009 RID: 9 RVA: 0x000021F4 File Offset: 0x000003F4
	private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
	{
		if (nCode >= 0 && (wParam == (IntPtr)256 || wParam == (IntPtr)260))
		{
			KeyEventArgs keyEventArgs = new KeyEventArgs((Keys)Marshal.ReadInt32(lParam));
			EventHandler<KeyEventArgs> keyDown = this.KeyDown;
			if (keyDown != null)
			{
				keyDown(this, keyEventArgs);
			}
			if (keyEventArgs.Handled)
			{
				return (IntPtr)1;
			}
		}
		else if (nCode >= 0 && (wParam == (IntPtr)257 || wParam == (IntPtr)261))
		{
			KeyEventArgs keyEventArgs2 = new KeyEventArgs((Keys)Marshal.ReadInt32(lParam));
			EventHandler<KeyEventArgs> keyUp = this.KeyUp;
			if (keyUp != null)
			{
				keyUp(this, keyEventArgs2);
			}
			if (keyEventArgs2.Handled)
			{
				return (IntPtr)1;
			}
		}
		return GlobalKeyboardHook.CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
	}

	// Token: 0x0600000A RID: 10
	[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern IntPtr SetWindowsHookEx(int idHook, GlobalKeyboardHook.LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

	// Token: 0x0600000B RID: 11
	[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool UnhookWindowsHookEx(IntPtr hhk);

	// Token: 0x0600000C RID: 12
	[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

	// Token: 0x0600000D RID: 13
	[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern IntPtr GetModuleHandle(string lpModuleName);

	// Token: 0x04000001 RID: 1
	private const int WH_KEYBOARD_LL = 13;

	// Token: 0x04000002 RID: 2
	private const int WM_KEYDOWN = 256;

	// Token: 0x04000003 RID: 3
	private const int WM_KEYUP = 257;

	// Token: 0x04000004 RID: 4
	private const int WM_SYSKEYDOWN = 260;

	// Token: 0x04000005 RID: 5
	private const int WM_SYSKEYUP = 261;

	// Token: 0x04000006 RID: 6
	private GlobalKeyboardHook.LowLevelKeyboardProc keyboardProc;

	// Token: 0x04000007 RID: 7
	private IntPtr hookId = IntPtr.Zero;

	// Token: 0x02000019 RID: 25
	// (Invoke) Token: 0x06000299 RID: 665
	private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
}
