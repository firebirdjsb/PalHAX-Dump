﻿using System;

namespace PalHaxv1_1
{
	// Token: 0x02000009 RID: 9
	internal static class Addresses
	{
		// Token: 0x06000206 RID: 518 RVA: 0x0000E698 File Offset: 0x0000C898
		private static string ReadAddress(string offset)
		{
			return Signatures.MemLib.ReadLong(offset, "").ToString("X2");
		}

		// Token: 0x0200002F RID: 47
		public static class UWorld
		{
			// Token: 0x170000C1 RID: 193
			// (get) Token: 0x060002AA RID: 682 RVA: 0x00011E42 File Offset: 0x00010042
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Signatures.UWorld_BaseAddress);
				}
			}
		}

		// Token: 0x02000030 RID: 48
		public static class PersistentLevel
		{
			// Token: 0x170000C2 RID: 194
			// (get) Token: 0x060002AB RID: 683 RVA: 0x00011E4E File Offset: 0x0001004E
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UWorld.Address + "+30");
				}
			}
		}

		// Token: 0x02000031 RID: 49
		public static class GameState
		{
			// Token: 0x170000C3 RID: 195
			// (get) Token: 0x060002AC RID: 684 RVA: 0x00011E64 File Offset: 0x00010064
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UWorld.Address + "+158");
				}
			}
		}

		// Token: 0x02000032 RID: 50
		public static class BaseCampReplicator
		{
			// Token: 0x170000C4 RID: 196
			// (get) Token: 0x060002AD RID: 685 RVA: 0x00011E7A File Offset: 0x0001007A
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.GameState.Address + "+2E8");
				}
			}
		}

		// Token: 0x02000033 RID: 51
		public static class RepInfoArrayItems
		{
			// Token: 0x170000C5 RID: 197
			// (get) Token: 0x060002AE RID: 686 RVA: 0x00011E90 File Offset: 0x00010090
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.BaseCampReplicator.Address + "+130");
				}
			}
		}

		// Token: 0x02000034 RID: 52
		public static class BaseCamp
		{
			// Token: 0x170000C6 RID: 198
			// (get) Token: 0x060002AF RID: 687 RVA: 0x00011EA6 File Offset: 0x000100A6
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.RepInfoArrayItems.Address + "+20");
				}
			}
		}

		// Token: 0x02000035 RID: 53
		public static class WorldSettings
		{
			// Token: 0x170000C7 RID: 199
			// (get) Token: 0x060002B0 RID: 688 RVA: 0x00011EBC File Offset: 0x000100BC
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PersistentLevel.Address + "+298");
				}
			}
		}

		// Token: 0x02000036 RID: 54
		public static class UGameInstance
		{
			// Token: 0x170000C8 RID: 200
			// (get) Token: 0x060002B1 RID: 689 RVA: 0x00011ED2 File Offset: 0x000100D2
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UWorld.Address + "+1B8");
				}
			}
		}

		// Token: 0x02000037 RID: 55
		public static class ItemIDManager
		{
			// Token: 0x170000C9 RID: 201
			// (get) Token: 0x060002B2 RID: 690 RVA: 0x00011EE8 File Offset: 0x000100E8
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UGameInstance.Address + "+438");
				}
			}
		}

		// Token: 0x02000038 RID: 56
		public static class ULocalPlayers
		{
			// Token: 0x170000CA RID: 202
			// (get) Token: 0x060002B3 RID: 691 RVA: 0x00011EFE File Offset: 0x000100FE
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UGameInstance.Address + "+38");
				}
			}
		}

		// Token: 0x02000039 RID: 57
		public static class ULocalPlayer
		{
			// Token: 0x170000CB RID: 203
			// (get) Token: 0x060002B4 RID: 692 RVA: 0x00011F14 File Offset: 0x00010114
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.ULocalPlayers.Address + "+0");
				}
			}
		}

		// Token: 0x0200003A RID: 58
		public static class APalPlayerController
		{
			// Token: 0x170000CC RID: 204
			// (get) Token: 0x060002B5 RID: 693 RVA: 0x00011F2A File Offset: 0x0001012A
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.ULocalPlayer.Address + "+30");
				}
			}
		}

		// Token: 0x0200003B RID: 59
		public static class APalCharacter
		{
			// Token: 0x170000CD RID: 205
			// (get) Token: 0x060002B6 RID: 694 RVA: 0x00011F40 File Offset: 0x00010140
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.APalPlayerController.Address + "+338");
				}
			}
		}

		// Token: 0x0200003C RID: 60
		public static class BuilderComponent
		{
			// Token: 0x170000CE RID: 206
			// (get) Token: 0x060002B7 RID: 695 RVA: 0x00011F56 File Offset: 0x00010156
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.APalCharacter.Address + "+808");
				}
			}
		}

		// Token: 0x0200003D RID: 61
		public static class UPalGameSetting
		{
			// Token: 0x170000CF RID: 207
			// (get) Token: 0x060002B8 RID: 696 RVA: 0x00011F6C File Offset: 0x0001016C
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UGameInstance.Address + "+3C8");
				}
			}
		}

		// Token: 0x0200003E RID: 62
		public static class PalEggRankInfoArray
		{
			// Token: 0x170000D0 RID: 208
			// (get) Token: 0x060002B9 RID: 697 RVA: 0x00011F82 File Offset: 0x00010182
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UPalGameSetting.Address + "+14C0");
				}
			}
		}

		// Token: 0x0200003F RID: 63
		public static class PalEggHatchingSpeedRateByTemperature
		{
			// Token: 0x170000D1 RID: 209
			// (get) Token: 0x060002BA RID: 698 RVA: 0x00011F98 File Offset: 0x00010198
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UPalGameSetting.Address + "+1520");
				}
			}
		}

		// Token: 0x02000040 RID: 64
		public static class CaptureJudgeRateArray
		{
			// Token: 0x170000D2 RID: 210
			// (get) Token: 0x060002BB RID: 699 RVA: 0x00011FAE File Offset: 0x000101AE
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UPalGameSetting.Address + "+D20");
				}
			}
		}

		// Token: 0x02000041 RID: 65
		public static class BodyTemperatureStomachDecreaseRateArray
		{
			// Token: 0x170000D3 RID: 211
			// (get) Token: 0x060002BC RID: 700 RVA: 0x00011FC4 File Offset: 0x000101C4
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UPalGameSetting.Address + "+128");
				}
			}
		}

		// Token: 0x02000042 RID: 66
		public static class BodyTemperatureSlipDamagePercent
		{
			// Token: 0x170000D4 RID: 212
			// (get) Token: 0x060002BD RID: 701 RVA: 0x00011FDA File Offset: 0x000101DA
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UPalGameSetting.Address + "+D8");
				}
			}
		}

		// Token: 0x02000043 RID: 67
		public static class APalPlayerState
		{
			// Token: 0x170000D5 RID: 213
			// (get) Token: 0x060002BE RID: 702 RVA: 0x00011FF0 File Offset: 0x000101F0
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.APalCharacter.Address + "+2B0");
				}
			}
		}

		// Token: 0x02000044 RID: 68
		public static class UPalPlayerInventoryData
		{
			// Token: 0x170000D6 RID: 214
			// (get) Token: 0x060002BF RID: 703 RVA: 0x00012006 File Offset: 0x00010206
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.APalPlayerState.Address + "+540");
				}
			}
		}

		// Token: 0x02000045 RID: 69
		public static class PlayerInventoryMultiHelper
		{
			// Token: 0x170000D7 RID: 215
			// (get) Token: 0x060002C0 RID: 704 RVA: 0x0001201C File Offset: 0x0001021C
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.UPalPlayerInventoryData.Address + "+160");
				}
			}
		}

		// Token: 0x02000046 RID: 70
		public static class PlayerInventoryContainersItemArray
		{
			// Token: 0x170000D8 RID: 216
			// (get) Token: 0x060002C1 RID: 705 RVA: 0x00012032 File Offset: 0x00010232
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PlayerInventoryMultiHelper.Address + "+38");
				}
			}
		}

		// Token: 0x02000047 RID: 71
		public static class PlayerInventoryContainers1
		{
			// Token: 0x170000D9 RID: 217
			// (get) Token: 0x060002C2 RID: 706 RVA: 0x00012048 File Offset: 0x00010248
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PlayerInventoryContainersItemArray.Address + "+0");
				}
			}
		}

		// Token: 0x02000048 RID: 72
		public static class PlayerInventoryItemSlotArray
		{
			// Token: 0x170000DA RID: 218
			// (get) Token: 0x060002C3 RID: 707 RVA: 0x0001205E File Offset: 0x0001025E
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PlayerInventoryContainers1.Address + "+60");
				}
			}
		}

		// Token: 0x02000049 RID: 73
		public static class PlayerInventoryItemSlot1
		{
			// Token: 0x170000DB RID: 219
			// (get) Token: 0x060002C4 RID: 708 RVA: 0x00012074 File Offset: 0x00010274
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PlayerInventoryItemSlotArray.Address + "+0");
				}
			}
		}

		// Token: 0x0200004A RID: 74
		public static class PlayerInventoryItemSlot2
		{
			// Token: 0x170000DC RID: 220
			// (get) Token: 0x060002C5 RID: 709 RVA: 0x0001208A File Offset: 0x0001028A
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PlayerInventoryItemSlotArray.Address + "+8");
				}
			}
		}

		// Token: 0x0200004B RID: 75
		public static class PlayerInventoryItemSlot3
		{
			// Token: 0x170000DD RID: 221
			// (get) Token: 0x060002C6 RID: 710 RVA: 0x000120A0 File Offset: 0x000102A0
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PlayerInventoryItemSlotArray.Address + "+10");
				}
			}
		}

		// Token: 0x0200004C RID: 76
		public static class PlayerInventoryItemSlot4
		{
			// Token: 0x170000DE RID: 222
			// (get) Token: 0x060002C7 RID: 711 RVA: 0x000120B6 File Offset: 0x000102B6
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PlayerInventoryItemSlotArray.Address + "+18");
				}
			}
		}

		// Token: 0x0200004D RID: 77
		public static class PlayerInventoryItemSlot5
		{
			// Token: 0x170000DF RID: 223
			// (get) Token: 0x060002C8 RID: 712 RVA: 0x000120CC File Offset: 0x000102CC
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PlayerInventoryItemSlotArray.Address + "+20");
				}
			}
		}

		// Token: 0x0200004E RID: 78
		public static class UCharacterMovementComponent
		{
			// Token: 0x170000E0 RID: 224
			// (get) Token: 0x060002C9 RID: 713 RVA: 0x000120E2 File Offset: 0x000102E2
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.APalCharacter.Address + "+320");
				}
			}
		}

		// Token: 0x0200004F RID: 79
		public static class PalCharacterParameterComponent
		{
			// Token: 0x170000E1 RID: 225
			// (get) Token: 0x060002CA RID: 714 RVA: 0x000120F8 File Offset: 0x000102F8
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.APalCharacter.Address + "+628");
				}
			}
		}

		// Token: 0x02000050 RID: 80
		public static class BP_OtomoPalHolderComponent
		{
			// Token: 0x170000E2 RID: 226
			// (get) Token: 0x060002CB RID: 715 RVA: 0x0001210E File Offset: 0x0001030E
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.APalPlayerController.Address + "+D18");
				}
			}
		}

		// Token: 0x02000051 RID: 81
		public static class CharacterInventoryPals
		{
			// Token: 0x170000E3 RID: 227
			// (get) Token: 0x060002CC RID: 716 RVA: 0x00012124 File Offset: 0x00010324
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.BP_OtomoPalHolderComponent.Address + "+100");
				}
			}
		}

		// Token: 0x02000052 RID: 82
		public static class CharacterInventoryPalsSlotArray
		{
			// Token: 0x170000E4 RID: 228
			// (get) Token: 0x060002CD RID: 717 RVA: 0x0001213A File Offset: 0x0001033A
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.CharacterInventoryPals.Address + "+80");
				}
			}
		}

		// Token: 0x02000053 RID: 83
		public static class CharacterInventoryPalsSlot1
		{
			// Token: 0x170000E5 RID: 229
			// (get) Token: 0x060002CE RID: 718 RVA: 0x00012150 File Offset: 0x00010350
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.CharacterInventoryPalsSlotArray.Address + "+0");
				}
			}
		}

		// Token: 0x02000054 RID: 84
		public static class CharacterInventoryPalsSlot1Handle
		{
			// Token: 0x170000E6 RID: 230
			// (get) Token: 0x060002CF RID: 719 RVA: 0x00012166 File Offset: 0x00010366
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.CharacterInventoryPalsSlot1.Address + "+50");
				}
			}
		}

		// Token: 0x02000055 RID: 85
		public static class OtomoPal
		{
			// Token: 0x170000E7 RID: 231
			// (get) Token: 0x060002D0 RID: 720 RVA: 0x0001217C File Offset: 0x0001037C
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PalCharacterParameterComponent.Address + "+F0");
				}
			}
		}

		// Token: 0x02000056 RID: 86
		public static class OtomoPalCharacterParamComponent
		{
			// Token: 0x170000E8 RID: 232
			// (get) Token: 0x060002D1 RID: 721 RVA: 0x00012192 File Offset: 0x00010392
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.OtomoPal.Address + "+628");
				}
			}
		}

		// Token: 0x02000057 RID: 87
		public static class OtomoPalIndividualParameter
		{
			// Token: 0x170000E9 RID: 233
			// (get) Token: 0x060002D2 RID: 722 RVA: 0x000121A8 File Offset: 0x000103A8
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.OtomoPalCharacterParamComponent.Address + "+108");
				}
			}
		}

		// Token: 0x02000058 RID: 88
		public static class SaveParameterEquipWaza
		{
			// Token: 0x170000EA RID: 234
			// (get) Token: 0x060002D3 RID: 723 RVA: 0x000121BE File Offset: 0x000103BE
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.OtomoPalIndividualParameter.Address + "+2C8");
				}
			}
		}

		// Token: 0x02000059 RID: 89
		public static class PalIndividiualParameter
		{
			// Token: 0x170000EB RID: 235
			// (get) Token: 0x060002D4 RID: 724 RVA: 0x000121D4 File Offset: 0x000103D4
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PalCharacterParameterComponent.Address + "+108");
				}
			}
		}

		// Token: 0x0200005A RID: 90
		public static class PalShooterComponent
		{
			// Token: 0x170000EC RID: 236
			// (get) Token: 0x060002D5 RID: 725 RVA: 0x000121EA File Offset: 0x000103EA
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.APalCharacter.Address + "+7F8");
				}
			}
		}

		// Token: 0x0200005B RID: 91
		public static class PalHasWeapon
		{
			// Token: 0x170000ED RID: 237
			// (get) Token: 0x060002D6 RID: 726 RVA: 0x00012200 File Offset: 0x00010400
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PalShooterComponent.Address + "+470");
				}
			}
		}

		// Token: 0x0200005C RID: 92
		public static class PalownItemDataDynamicData
		{
			// Token: 0x170000EE RID: 238
			// (get) Token: 0x060002D7 RID: 727 RVA: 0x00012216 File Offset: 0x00010416
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PalHasWeapon.Address + "+4A0");
				}
			}
		}

		// Token: 0x0200005D RID: 93
		public static class PalownItemDataStaticData
		{
			// Token: 0x170000EF RID: 239
			// (get) Token: 0x060002D8 RID: 728 RVA: 0x0001222C File Offset: 0x0001042C
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.PalHasWeapon.Address + "+498");
				}
			}
		}

		// Token: 0x0200005E RID: 94
		public static class UPalTechnologyData
		{
			// Token: 0x170000F0 RID: 240
			// (get) Token: 0x060002D9 RID: 729 RVA: 0x00012242 File Offset: 0x00010442
			public static string Address
			{
				get
				{
					return Addresses.ReadAddress(Addresses.APalPlayerState.Address + "+550");
				}
			}
		}
	}
}
