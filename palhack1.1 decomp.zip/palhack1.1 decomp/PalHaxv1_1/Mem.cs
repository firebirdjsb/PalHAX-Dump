﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PalHaxv1_1
{
	// Token: 0x02000004 RID: 4
	public class Mem
	{
		// Token: 0x0600003D RID: 61 RVA: 0x0000A5DC File Offset: 0x000087DC
		public UIntPtr VirtualQueryEx(IntPtr hProcess, UIntPtr lpAddress, out Imps.MEMORY_BASIC_INFORMATION lpBuffer)
		{
			if (this.mProc.Is64Bit || IntPtr.Size == 8)
			{
				Imps.MEMORY_BASIC_INFORMATION64 memory_BASIC_INFORMATION = default(Imps.MEMORY_BASIC_INFORMATION64);
				UIntPtr result = Imps.Native_VirtualQueryEx(hProcess, lpAddress, out memory_BASIC_INFORMATION, new UIntPtr((uint)Marshal.SizeOf<Imps.MEMORY_BASIC_INFORMATION64>(memory_BASIC_INFORMATION)));
				lpBuffer.BaseAddress = memory_BASIC_INFORMATION.BaseAddress;
				lpBuffer.AllocationBase = memory_BASIC_INFORMATION.AllocationBase;
				lpBuffer.AllocationProtect = memory_BASIC_INFORMATION.AllocationProtect;
				lpBuffer.RegionSize = (long)memory_BASIC_INFORMATION.RegionSize;
				lpBuffer.State = memory_BASIC_INFORMATION.State;
				lpBuffer.Protect = memory_BASIC_INFORMATION.Protect;
				lpBuffer.Type = memory_BASIC_INFORMATION.Type;
				return result;
			}
			Imps.MEMORY_BASIC_INFORMATION32 memory_BASIC_INFORMATION2 = default(Imps.MEMORY_BASIC_INFORMATION32);
			UIntPtr result2 = Imps.Native_VirtualQueryEx(hProcess, lpAddress, out memory_BASIC_INFORMATION2, new UIntPtr((uint)Marshal.SizeOf<Imps.MEMORY_BASIC_INFORMATION32>(memory_BASIC_INFORMATION2)));
			lpBuffer.BaseAddress = memory_BASIC_INFORMATION2.BaseAddress;
			lpBuffer.AllocationBase = memory_BASIC_INFORMATION2.AllocationBase;
			lpBuffer.AllocationProtect = memory_BASIC_INFORMATION2.AllocationProtect;
			lpBuffer.RegionSize = (long)((ulong)memory_BASIC_INFORMATION2.RegionSize);
			lpBuffer.State = memory_BASIC_INFORMATION2.State;
			lpBuffer.Protect = memory_BASIC_INFORMATION2.Protect;
			lpBuffer.Type = memory_BASIC_INFORMATION2.Type;
			return result2;
		}

		// Token: 0x0600003E RID: 62 RVA: 0x0000A6E0 File Offset: 0x000088E0
		public bool OpenProcess(int pid, out string FailReason)
		{
			if (pid <= 0)
			{
				FailReason = "OpenProcess given proc ID 0.";
				return false;
			}
			if (this.mProc.Process != null && this.mProc.Process.Id == pid)
			{
				FailReason = "mProc.Process is null";
				return true;
			}
			bool result;
			try
			{
				this.mProc.Process = Process.GetProcessById(pid);
				if (this.mProc.Process != null && !this.mProc.Process.Responding)
				{
					FailReason = "Process is not responding or null.";
					result = false;
				}
				else
				{
					this.mProc.Handle = Imps.OpenProcess(2035711U, true, pid);
					if (this.mProc.Handle == IntPtr.Zero)
					{
						int lastWin32Error = Marshal.GetLastWin32Error();
						this.mProc = null;
						FailReason = "failed opening a handle to the target process(GetLastWin32ErrorCode: " + lastWin32Error.ToString() + ")";
						result = false;
					}
					else
					{
						bool flag;
						this.mProc.Is64Bit = (Environment.Is64BitOperatingSystem && Imps.IsWow64Process(this.mProc.Handle, out flag) && !flag);
						this.mProc.MainModule = this.mProc.Process.MainModule;
						FailReason = "";
						result = true;
					}
				}
			}
			catch (Exception ex)
			{
				string str = "OpenProcess has crashed. ";
				Exception ex2 = ex;
				FailReason = str + ((ex2 != null) ? ex2.ToString() : null);
				result = false;
			}
			return result;
		}

		// Token: 0x0600003F RID: 63 RVA: 0x0000A840 File Offset: 0x00008A40
		public bool OpenProcess(string proc, out string FailReason)
		{
			return this.OpenProcess(this.GetProcIdFromName(proc), out FailReason);
		}

		// Token: 0x06000040 RID: 64 RVA: 0x0000A850 File Offset: 0x00008A50
		public bool OpenProcess(string proc)
		{
			string text;
			return this.OpenProcess(this.GetProcIdFromName(proc), out text);
		}

		// Token: 0x06000041 RID: 65 RVA: 0x0000A86C File Offset: 0x00008A6C
		public bool OpenProcess(int pid)
		{
			string text;
			return this.OpenProcess(pid, out text);
		}

		// Token: 0x06000042 RID: 66 RVA: 0x0000A882 File Offset: 0x00008A82
		public void SetFocus()
		{
			Imps.SetForegroundWindow(this.mProc.Process.MainWindowHandle);
		}

		// Token: 0x06000043 RID: 67 RVA: 0x0000A89C File Offset: 0x00008A9C
		public int GetProcIdFromName(string name)
		{
			Process[] processes = Process.GetProcesses();
			if (name.ToLower().Contains(".exe"))
			{
				name = name.Replace(".exe", "");
			}
			if (name.ToLower().Contains(".bin"))
			{
				name = name.Replace(".bin", "");
			}
			foreach (Process process in processes)
			{
				if (process.ProcessName.Equals(name, StringComparison.CurrentCultureIgnoreCase))
				{
					return process.Id;
				}
			}
			return 0;
		}

		// Token: 0x06000044 RID: 68 RVA: 0x0000A920 File Offset: 0x00008B20
		public string LoadCode(string name, string iniFile)
		{
			StringBuilder stringBuilder = new StringBuilder(1024);
			if (!string.IsNullOrEmpty(iniFile))
			{
				if (File.Exists(iniFile))
				{
					Imps.GetPrivateProfileString("codes", name, "", stringBuilder, (uint)stringBuilder.Capacity, iniFile);
				}
			}
			else
			{
				stringBuilder.Append(name);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000045 RID: 69 RVA: 0x0000A974 File Offset: 0x00008B74
		private int LoadIntCode(string name, string path)
		{
			int result;
			try
			{
				int num = Convert.ToInt32(this.LoadCode(name, path), 16);
				if (num >= 0)
				{
					result = num;
				}
				else
				{
					result = 0;
				}
			}
			catch
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x06000046 RID: 70 RVA: 0x0000A9B4 File Offset: 0x00008BB4
		public void ThreadStartClient(string func, string name)
		{
			using (NamedPipeClientStream namedPipeClientStream = new NamedPipeClientStream(name))
			{
				if (!namedPipeClientStream.IsConnected)
				{
					namedPipeClientStream.Connect();
				}
				using (StreamWriter streamWriter = new StreamWriter(namedPipeClientStream))
				{
					if (!streamWriter.AutoFlush)
					{
						streamWriter.AutoFlush = true;
					}
					streamWriter.WriteLine(func);
				}
			}
		}

		// Token: 0x06000047 RID: 71 RVA: 0x0000AA28 File Offset: 0x00008C28
		public bool ChangeProtection(string code, Imps.MemoryProtection newProtection, out Imps.MemoryProtection oldProtection, string file = "")
		{
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || this.mProc.Handle == IntPtr.Zero)
			{
				oldProtection = (Imps.MemoryProtection)0U;
				return false;
			}
			return Imps.VirtualProtectEx(this.mProc.Handle, code2, (IntPtr)(this.mProc.Is64Bit ? 8 : 4), newProtection, out oldProtection);
		}

		// Token: 0x06000048 RID: 72 RVA: 0x0000AA94 File Offset: 0x00008C94
		public UIntPtr GetCode(string name, string path = "", int size = 8)
		{
			if (this.mProc == null)
			{
				return UIntPtr.Zero;
			}
			if (this.mProc.Is64Bit)
			{
				if (size == 8)
				{
					size = 16;
				}
				return this.Get64BitCode(name, path, size);
			}
			string text;
			if (!string.IsNullOrEmpty(path))
			{
				text = this.LoadCode(name, path);
			}
			else
			{
				text = name;
			}
			if (string.IsNullOrEmpty(text))
			{
				return UIntPtr.Zero;
			}
			if (text.Contains(" "))
			{
				text = text.Replace(" ", string.Empty);
			}
			if (!text.Contains("+") && !text.Contains(","))
			{
				try
				{
					return new UIntPtr(Convert.ToUInt32(text, 16));
				}
				catch
				{
					return UIntPtr.Zero;
				}
			}
			string text2 = text;
			if (text.Contains("+"))
			{
				text2 = text.Substring(text.IndexOf('+') + 1);
			}
			byte[] array = new byte[size];
			if (text2.Contains(','))
			{
				List<int> list = new List<int>();
				foreach (string text3 in text2.Split(new char[]
				{
					','
				}))
				{
					string text4 = text3;
					if (text3.Contains("0x"))
					{
						text4 = text3.Replace("0x", "");
					}
					int num;
					if (!text3.Contains("-"))
					{
						num = int.Parse(text4, NumberStyles.AllowHexSpecifier);
					}
					else
					{
						text4 = text4.Replace("-", "");
						num = int.Parse(text4, NumberStyles.AllowHexSpecifier);
						num *= -1;
					}
					list.Add(num);
				}
				int[] array3 = list.ToArray();
				if (text.Contains("base") || text.Contains("main"))
				{
					Imps.ReadProcessMemory(this.mProc.Handle, (UIntPtr)((ulong)((long)((int)this.mProc.MainModule.BaseAddress + array3[0]))), array, (UIntPtr)((ulong)((long)size)), IntPtr.Zero);
				}
				else if (!text.Contains("base") && !text.Contains("main") && text.Contains("+"))
				{
					string[] array4 = text.Split(new char[]
					{
						'+'
					});
					IntPtr value = IntPtr.Zero;
					if (!array4[0].ToLower().Contains(".dll") && !array4[0].ToLower().Contains(".exe") && !array4[0].ToLower().Contains(".bin"))
					{
						string text5 = array4[0];
						if (text5.Contains("0x"))
						{
							text5 = text5.Replace("0x", "");
						}
						value = (IntPtr)int.Parse(text5, NumberStyles.HexNumber);
					}
					else
					{
						try
						{
							value = this.GetModuleAddressByName(array4[0]);
						}
						catch
						{
						}
					}
					Imps.ReadProcessMemory(this.mProc.Handle, (UIntPtr)((ulong)((long)((int)value + array3[0]))), array, (UIntPtr)((ulong)((long)size)), IntPtr.Zero);
				}
				else
				{
					Imps.ReadProcessMemory(this.mProc.Handle, (UIntPtr)((ulong)((long)array3[0])), array, (UIntPtr)((ulong)((long)size)), IntPtr.Zero);
				}
				uint num2 = BitConverter.ToUInt32(array, 0);
				UIntPtr uintPtr = (UIntPtr)0UL;
				for (int j = 1; j < array3.Length; j++)
				{
					uintPtr = new UIntPtr(Convert.ToUInt32((long)((ulong)num2 + (ulong)((long)array3[j]))));
					Imps.ReadProcessMemory(this.mProc.Handle, uintPtr, array, (UIntPtr)((ulong)((long)size)), IntPtr.Zero);
					num2 = BitConverter.ToUInt32(array, 0);
				}
				return uintPtr;
			}
			int num3 = Convert.ToInt32(text2, 16);
			IntPtr value2 = IntPtr.Zero;
			if (text.ToLower().Contains("base") || text.ToLower().Contains("main"))
			{
				value2 = this.mProc.MainModule.BaseAddress;
			}
			else
			{
				if (!text.ToLower().Contains("base") && !text.ToLower().Contains("main") && text.Contains("+"))
				{
					string[] array5 = text.Split(new char[]
					{
						'+'
					});
					if (!array5[0].ToLower().Contains(".dll") && !array5[0].ToLower().Contains(".exe") && !array5[0].ToLower().Contains(".bin"))
					{
						string text6 = array5[0];
						if (text6.Contains("0x"))
						{
							text6 = text6.Replace("0x", "");
						}
						value2 = (IntPtr)int.Parse(text6, NumberStyles.HexNumber);
						goto IL_4D0;
					}
					try
					{
						value2 = this.GetModuleAddressByName(array5[0]);
						goto IL_4D0;
					}
					catch
					{
						goto IL_4D0;
					}
				}
				value2 = this.GetModuleAddressByName(text.Split(new char[]
				{
					'+'
				})[0]);
			}
			IL_4D0:
			return (UIntPtr)((ulong)((long)((int)value2 + num3)));
		}

		// Token: 0x06000049 RID: 73 RVA: 0x0000AFAC File Offset: 0x000091AC
		public IntPtr GetModuleAddressByName(string name)
		{
			return this.mProc.Process.Modules.Cast<ProcessModule>().SingleOrDefault((ProcessModule m) => string.Equals(m.ModuleName, name, StringComparison.OrdinalIgnoreCase)).BaseAddress;
		}

		// Token: 0x0600004A RID: 74 RVA: 0x0000AFF4 File Offset: 0x000091F4
		public UIntPtr Get64BitCode(string name, string path = "", int size = 16)
		{
			string text;
			if (!string.IsNullOrEmpty(path))
			{
				text = this.LoadCode(name, path);
			}
			else
			{
				text = name;
			}
			if (string.IsNullOrEmpty(text))
			{
				return UIntPtr.Zero;
			}
			if (text.Contains(" "))
			{
				text.Replace(" ", string.Empty);
			}
			string text2 = text;
			if (text.Contains("+"))
			{
				text2 = text.Substring(text.IndexOf('+') + 1);
			}
			byte[] array = new byte[size];
			if (!text.Contains("+") && !text.Contains(","))
			{
				try
				{
					return new UIntPtr(Convert.ToUInt64(text, 16));
				}
				catch
				{
					return UIntPtr.Zero;
				}
			}
			if (text2.Contains(','))
			{
				List<long> list = new List<long>();
				foreach (string text3 in text2.Split(new char[]
				{
					','
				}))
				{
					string text4 = text3;
					if (text3.Contains("0x"))
					{
						text4 = text3.Replace("0x", "");
					}
					long num;
					if (!text3.Contains("-"))
					{
						num = long.Parse(text4, NumberStyles.AllowHexSpecifier);
					}
					else
					{
						text4 = text4.Replace("-", "");
						num = long.Parse(text4, NumberStyles.AllowHexSpecifier);
						num *= -1L;
					}
					list.Add(num);
				}
				long[] array3 = list.ToArray();
				if (text.Contains("base") || text.Contains("main"))
				{
					Imps.ReadProcessMemory(this.mProc.Handle, (UIntPtr)((ulong)((long)this.mProc.MainModule.BaseAddress + array3[0])), array, (UIntPtr)((ulong)((long)size)), IntPtr.Zero);
				}
				else if (!text.Contains("base") && !text.Contains("main") && text.Contains("+"))
				{
					string[] array4 = text.Split(new char[]
					{
						'+'
					});
					IntPtr value = IntPtr.Zero;
					if (!array4[0].ToLower().Contains(".dll") && !array4[0].ToLower().Contains(".exe") && !array4[0].ToLower().Contains(".bin"))
					{
						value = (IntPtr)long.Parse(array4[0], NumberStyles.HexNumber);
					}
					else
					{
						try
						{
							value = this.GetModuleAddressByName(array4[0]);
						}
						catch
						{
						}
					}
					Imps.ReadProcessMemory(this.mProc.Handle, (UIntPtr)((ulong)((long)value + array3[0])), array, (UIntPtr)((ulong)((long)size)), IntPtr.Zero);
				}
				else
				{
					Imps.ReadProcessMemory(this.mProc.Handle, (UIntPtr)((ulong)array3[0]), array, (UIntPtr)((ulong)((long)size)), IntPtr.Zero);
				}
				long num2 = BitConverter.ToInt64(array, 0);
				UIntPtr uintPtr = (UIntPtr)0UL;
				for (int j = 1; j < array3.Length; j++)
				{
					uintPtr = new UIntPtr(Convert.ToUInt64(num2 + array3[j]));
					Imps.ReadProcessMemory(this.mProc.Handle, uintPtr, array, (UIntPtr)((ulong)((long)size)), IntPtr.Zero);
					num2 = BitConverter.ToInt64(array, 0);
				}
				return uintPtr;
			}
			long num3 = Convert.ToInt64(text2, 16);
			IntPtr value2 = IntPtr.Zero;
			if (text.Contains("base") || text.Contains("main"))
			{
				value2 = this.mProc.MainModule.BaseAddress;
			}
			else
			{
				if (!text.Contains("base") && !text.Contains("main") && text.Contains("+"))
				{
					string[] array5 = text.Split(new char[]
					{
						'+'
					});
					if (!array5[0].ToLower().Contains(".dll") && !array5[0].ToLower().Contains(".exe") && !array5[0].ToLower().Contains(".bin"))
					{
						string text5 = array5[0];
						if (text5.Contains("0x"))
						{
							text5 = text5.Replace("0x", "");
						}
						value2 = (IntPtr)long.Parse(text5, NumberStyles.HexNumber);
						goto IL_467;
					}
					try
					{
						value2 = this.GetModuleAddressByName(array5[0]);
						goto IL_467;
					}
					catch
					{
						goto IL_467;
					}
				}
				value2 = this.GetModuleAddressByName(text.Split(new char[]
				{
					'+'
				})[0]);
			}
			IL_467:
			return (UIntPtr)((ulong)((long)value2 + num3));
		}

		// Token: 0x0600004B RID: 75 RVA: 0x0000B4A4 File Offset: 0x000096A4
		public void CloseProcess()
		{
			IntPtr handle = this.mProc.Handle;
			Imps.CloseHandle(this.mProc.Handle);
			this.mProc = null;
		}

		// Token: 0x0600004C RID: 76 RVA: 0x0000B4CC File Offset: 0x000096CC
		public bool InjectDll(string strDllName)
		{
			if (this.mProc.Process == null)
			{
				return false;
			}
			using (IEnumerator enumerator = this.mProc.Process.Modules.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (((ProcessModule)enumerator.Current).ModuleName.StartsWith("inject", StringComparison.InvariantCultureIgnoreCase))
					{
						return false;
					}
				}
			}
			if (!this.mProc.Process.Responding)
			{
				return false;
			}
			int num = strDllName.Length + 1;
			UIntPtr uintPtr = Imps.VirtualAllocEx(this.mProc.Handle, (UIntPtr)null, (uint)num, 12288U, 4U);
			IntPtr intPtr;
			Imps.WriteProcessMemory(this.mProc.Handle, uintPtr, strDllName, (UIntPtr)((ulong)((long)num)), out intPtr);
			UIntPtr procAddress = Imps.GetProcAddress(Imps.GetModuleHandle("kernel32.dll"), "LoadLibraryA");
			IntPtr intPtr2 = Imps.CreateRemoteThread(this.mProc.Handle, (IntPtr)null, 0U, procAddress, uintPtr, 0U, out intPtr);
			int num2 = Imps.WaitForSingleObject(intPtr2, 10000);
			if ((long)num2 == 128L || (long)num2 == 258L)
			{
				Imps.CloseHandle(intPtr2);
				return false;
			}
			Imps.VirtualFreeEx(this.mProc.Handle, uintPtr, (UIntPtr)0UL, 32768U);
			Imps.CloseHandle(intPtr2);
			return true;
		}

		// Token: 0x0600004D RID: 77 RVA: 0x0000B63C File Offset: 0x0000983C
		public UIntPtr CreateCodeCave(string code, byte[] newBytes, int replaceCount, int size = 4096, string file = "")
		{
			if (replaceCount < 5)
			{
				return UIntPtr.Zero;
			}
			UIntPtr code2 = this.GetCode(code, file, 8);
			UIntPtr uintPtr = UIntPtr.Zero;
			UIntPtr uintPtr2 = code2;
			int num = 0;
			while (num < 10 && uintPtr == UIntPtr.Zero)
			{
				uintPtr = Imps.VirtualAllocEx(this.mProc.Handle, this.FindFreeBlockForRegion(uintPtr2, (uint)size), (uint)size, 12288U, 64U);
				if (uintPtr == UIntPtr.Zero)
				{
					uintPtr2 = UIntPtr.Add(uintPtr2, 65536);
				}
				num++;
			}
			if (uintPtr == UIntPtr.Zero)
			{
				uintPtr = Imps.VirtualAllocEx(this.mProc.Handle, UIntPtr.Zero, (uint)size, 12288U, 64U);
			}
			int num2 = (replaceCount > 5) ? (replaceCount - 5) : 0;
			int value = (int)((ulong)uintPtr - (ulong)code2 - 5UL);
			byte[] array = new byte[5 + num2];
			array[0] = 233;
			BitConverter.GetBytes(value).CopyTo(array, 1);
			for (int i = 5; i < array.Length; i++)
			{
				array[i] = 144;
			}
			byte[] array2 = new byte[5 + newBytes.Length];
			int value2 = (int)((ulong)code2 + (ulong)((long)array.Length) - ((ulong)uintPtr + (ulong)((long)newBytes.Length)) - 5UL);
			newBytes.CopyTo(array2, 0);
			array2[newBytes.Length] = 233;
			BitConverter.GetBytes(value2).CopyTo(array2, newBytes.Length + 1);
			this.WriteBytes(uintPtr, array2);
			this.WriteBytes(code2, array);
			return uintPtr;
		}

		// Token: 0x0600004E RID: 78 RVA: 0x0000B7A8 File Offset: 0x000099A8
		private UIntPtr FindFreeBlockForRegion(UIntPtr baseAddress, uint size)
		{
			UIntPtr uintPtr = UIntPtr.Subtract(baseAddress, 1879048192);
			UIntPtr value = UIntPtr.Add(baseAddress, 1879048192);
			UIntPtr uintPtr2 = UIntPtr.Zero;
			UIntPtr uintPtr3 = UIntPtr.Zero;
			Imps.SYSTEM_INFO system_INFO;
			Imps.GetSystemInfo(out system_INFO);
			if (this.mProc.Is64Bit)
			{
				if ((ulong)uintPtr > (ulong)system_INFO.maximumApplicationAddress || (ulong)uintPtr < (ulong)system_INFO.minimumApplicationAddress)
				{
					uintPtr = system_INFO.minimumApplicationAddress;
				}
				if ((ulong)value < (ulong)system_INFO.minimumApplicationAddress || (ulong)value > (ulong)system_INFO.maximumApplicationAddress)
				{
					value = system_INFO.maximumApplicationAddress;
				}
			}
			else
			{
				uintPtr = system_INFO.minimumApplicationAddress;
				value = system_INFO.maximumApplicationAddress;
			}
			UIntPtr uintPtr4 = uintPtr;
			Imps.MEMORY_BASIC_INFORMATION memory_BASIC_INFORMATION;
			while (this.VirtualQueryEx(this.mProc.Handle, uintPtr4, out memory_BASIC_INFORMATION).ToUInt64() != 0UL)
			{
				if ((ulong)memory_BASIC_INFORMATION.BaseAddress > (ulong)value)
				{
					return UIntPtr.Zero;
				}
				if (memory_BASIC_INFORMATION.State == 65536U && memory_BASIC_INFORMATION.RegionSize > (long)((ulong)size))
				{
					if ((ulong)memory_BASIC_INFORMATION.BaseAddress % (ulong)system_INFO.allocationGranularity > 0UL)
					{
						uintPtr3 = memory_BASIC_INFORMATION.BaseAddress;
						int num = (int)((ulong)system_INFO.allocationGranularity - (ulong)uintPtr3 % (ulong)system_INFO.allocationGranularity);
						if (memory_BASIC_INFORMATION.RegionSize - (long)num >= (long)((ulong)size))
						{
							uintPtr3 = UIntPtr.Add(uintPtr3, num);
							if ((ulong)uintPtr3 < (ulong)baseAddress)
							{
								uintPtr3 = UIntPtr.Add(uintPtr3, (int)(memory_BASIC_INFORMATION.RegionSize - (long)num - (long)((ulong)size)));
								if ((ulong)uintPtr3 > (ulong)baseAddress)
								{
									uintPtr3 = baseAddress;
								}
								uintPtr3 = UIntPtr.Subtract(uintPtr3, (int)((ulong)uintPtr3 % (ulong)system_INFO.allocationGranularity));
							}
							if (Math.Abs((long)((ulong)uintPtr3 - (ulong)baseAddress)) < Math.Abs((long)((ulong)uintPtr2 - (ulong)baseAddress)))
							{
								uintPtr2 = uintPtr3;
							}
						}
					}
					else
					{
						uintPtr3 = memory_BASIC_INFORMATION.BaseAddress;
						if ((ulong)uintPtr3 < (ulong)baseAddress)
						{
							uintPtr3 = UIntPtr.Add(uintPtr3, (int)(memory_BASIC_INFORMATION.RegionSize - (long)((ulong)size)));
							if ((ulong)uintPtr3 > (ulong)baseAddress)
							{
								uintPtr3 = baseAddress;
							}
							uintPtr3 = UIntPtr.Subtract(uintPtr3, (int)((ulong)uintPtr3 % (ulong)system_INFO.allocationGranularity));
						}
						if (Math.Abs((long)((ulong)uintPtr3 - (ulong)baseAddress)) < Math.Abs((long)((ulong)uintPtr2 - (ulong)baseAddress)))
						{
							uintPtr2 = uintPtr3;
						}
					}
				}
				if (memory_BASIC_INFORMATION.RegionSize % (long)((ulong)system_INFO.allocationGranularity) > 0L)
				{
					memory_BASIC_INFORMATION.RegionSize += (long)((ulong)system_INFO.allocationGranularity - (ulong)(memory_BASIC_INFORMATION.RegionSize % (long)((ulong)system_INFO.allocationGranularity)));
				}
				UIntPtr value2 = uintPtr4;
				uintPtr4 = new UIntPtr((ulong)memory_BASIC_INFORMATION.BaseAddress + (ulong)memory_BASIC_INFORMATION.RegionSize);
				if ((ulong)uintPtr4 >= (ulong)value)
				{
					return uintPtr2;
				}
				if ((ulong)value2 >= (ulong)uintPtr4)
				{
					return uintPtr2;
				}
			}
			return uintPtr2;
		}

		// Token: 0x0600004F RID: 79 RVA: 0x0000BA88 File Offset: 0x00009C88
		public static void SuspendProcess(int pid)
		{
			Process processById = Process.GetProcessById(pid);
			if (processById.ProcessName == string.Empty)
			{
				return;
			}
			foreach (object obj in processById.Threads)
			{
				ProcessThread processThread = (ProcessThread)obj;
				IntPtr intPtr = Imps.OpenThread(Imps.ThreadAccess.SUSPEND_RESUME, false, (uint)processThread.Id);
				if (!(intPtr == IntPtr.Zero))
				{
					Imps.SuspendThread(intPtr);
					Imps.CloseHandle(intPtr);
				}
			}
		}

		// Token: 0x06000050 RID: 80 RVA: 0x0000BB20 File Offset: 0x00009D20
		public static void ResumeProcess(int pid)
		{
			Process processById = Process.GetProcessById(pid);
			if (processById.ProcessName == string.Empty)
			{
				return;
			}
			foreach (object obj in processById.Threads)
			{
				ProcessThread processThread = (ProcessThread)obj;
				IntPtr intPtr = Imps.OpenThread(Imps.ThreadAccess.SUSPEND_RESUME, false, (uint)processThread.Id);
				if (!(intPtr == IntPtr.Zero))
				{
					int num;
					do
					{
						num = Imps.ResumeThread(intPtr);
					}
					while (num > 0);
					Imps.CloseHandle(intPtr);
				}
			}
		}

		// Token: 0x06000051 RID: 81 RVA: 0x0000BBC4 File Offset: 0x00009DC4
		private Task PutTaskDelay(int delay)
		{
			Mem.<PutTaskDelay>d__21 <PutTaskDelay>d__;
			<PutTaskDelay>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<PutTaskDelay>d__.delay = delay;
			<PutTaskDelay>d__.<>1__state = -1;
			<PutTaskDelay>d__.<>t__builder.Start<Mem.<PutTaskDelay>d__21>(ref <PutTaskDelay>d__);
			return <PutTaskDelay>d__.<>t__builder.Task;
		}

		// Token: 0x06000052 RID: 82 RVA: 0x0000BC08 File Offset: 0x00009E08
		private void AppendAllBytes(string path, byte[] bytes)
		{
			using (FileStream fileStream = new FileStream(path, FileMode.Append))
			{
				fileStream.Write(bytes, 0, bytes.Length);
			}
		}

		// Token: 0x06000053 RID: 83 RVA: 0x0000BC44 File Offset: 0x00009E44
		public byte[] FileToBytes(string path, bool dontDelete = false)
		{
			byte[] result = File.ReadAllBytes(path);
			if (!dontDelete)
			{
				File.Delete(path);
			}
			return result;
		}

		// Token: 0x06000054 RID: 84 RVA: 0x0000BC55 File Offset: 0x00009E55
		public string MSize()
		{
			if (this.mProc.Is64Bit)
			{
				return "x16";
			}
			return "x8";
		}

		// Token: 0x06000055 RID: 85 RVA: 0x0000BC70 File Offset: 0x00009E70
		public static string ByteArrayToHexString(byte[] ba)
		{
			StringBuilder stringBuilder = new StringBuilder(ba.Length * 2);
			int num = 1;
			foreach (byte b in ba)
			{
				if (num == 16)
				{
					stringBuilder.AppendFormat("{0:x2}{1}", b, Environment.NewLine);
					num = 0;
				}
				else
				{
					stringBuilder.AppendFormat("{0:x2} ", b);
				}
				num++;
			}
			return stringBuilder.ToString().ToUpper();
		}

		// Token: 0x06000056 RID: 86 RVA: 0x0000BCE4 File Offset: 0x00009EE4
		public static string ByteArrayToString(byte[] ba)
		{
			StringBuilder stringBuilder = new StringBuilder(ba.Length * 2);
			foreach (byte b in ba)
			{
				stringBuilder.AppendFormat("{0:x2} ", b);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000057 RID: 87 RVA: 0x0000BD28 File Offset: 0x00009F28
		public ulong GetMinAddress()
		{
			Imps.SYSTEM_INFO system_INFO;
			Imps.GetSystemInfo(out system_INFO);
			return (ulong)system_INFO.minimumApplicationAddress;
		}

		// Token: 0x06000058 RID: 88 RVA: 0x0000BD48 File Offset: 0x00009F48
		public bool DumpMemory(string file = "dump.dmp")
		{
			Imps.SYSTEM_INFO system_INFO = default(Imps.SYSTEM_INFO);
			Imps.GetSystemInfo(out system_INFO);
			UIntPtr minimumApplicationAddress = system_INFO.minimumApplicationAddress;
			long num = (long)((ulong)minimumApplicationAddress);
			long num2 = this.mProc.Process.VirtualMemorySize64 + num;
			if (File.Exists(file))
			{
				File.Delete(file);
			}
			Imps.MEMORY_BASIC_INFORMATION memory_BASIC_INFORMATION = default(Imps.MEMORY_BASIC_INFORMATION);
			while (num < num2)
			{
				this.VirtualQueryEx(this.mProc.Handle, minimumApplicationAddress, out memory_BASIC_INFORMATION);
				byte[] array = new byte[memory_BASIC_INFORMATION.RegionSize];
				UIntPtr nSize = (UIntPtr)((ulong)memory_BASIC_INFORMATION.RegionSize);
				UIntPtr lpBaseAddress = (UIntPtr)((ulong)memory_BASIC_INFORMATION.BaseAddress);
				Imps.ReadProcessMemory(this.mProc.Handle, lpBaseAddress, array, nSize, IntPtr.Zero);
				this.AppendAllBytes(file, array);
				num += memory_BASIC_INFORMATION.RegionSize;
				minimumApplicationAddress = new UIntPtr((ulong)num);
			}
			return true;
		}

		// Token: 0x06000059 RID: 89 RVA: 0x0000BE20 File Offset: 0x0000A020
		public void GetThreads()
		{
			if (this.mProc.Process == null)
			{
				return;
			}
			foreach (object obj in this.mProc.Process.Threads)
			{
				ProcessThread processThread = (ProcessThread)obj;
			}
		}

		// Token: 0x0600005A RID: 90 RVA: 0x0000BE8C File Offset: 0x0000A08C
		public static IntPtr GetThreadStartAddress(int threadId)
		{
			IntPtr intPtr = Imps.OpenThread(Imps.ThreadAccess.QUERY_INFORMATION, false, (uint)threadId);
			if (intPtr == IntPtr.Zero)
			{
				throw new Win32Exception();
			}
			IntPtr intPtr2 = Marshal.AllocHGlobal(IntPtr.Size);
			IntPtr result;
			try
			{
				int num = Imps.NtQueryInformationThread(intPtr, Imps.ThreadInfoClass.ThreadQuerySetWin32StartAddress, intPtr2, IntPtr.Size, IntPtr.Zero);
				if (num != 0)
				{
					throw new Win32Exception(string.Format("NtQueryInformationThread failed; NTSTATUS = {0:X8}", num));
				}
				result = Marshal.ReadIntPtr(intPtr2);
			}
			finally
			{
				Imps.CloseHandle(intPtr);
				Marshal.FreeHGlobal(intPtr2);
			}
			return result;
		}

		// Token: 0x0600005B RID: 91 RVA: 0x0000BF18 File Offset: 0x0000A118
		public bool SuspendThreadByID(int ThreadID)
		{
			using (IEnumerator enumerator = this.mProc.Process.Threads.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (((ProcessThread)enumerator.Current).Id == ThreadID)
					{
						IntPtr intPtr = Imps.OpenThread(Imps.ThreadAccess.SUSPEND_RESUME, false, (uint)ThreadID);
						if (intPtr == IntPtr.Zero)
						{
							break;
						}
						if (Imps.SuspendThread(intPtr) == -1)
						{
							Imps.CloseHandle(intPtr);
							break;
						}
						Imps.CloseHandle(intPtr);
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x0600005C RID: 92 RVA: 0x0000BFB4 File Offset: 0x0000A1B4
		public Task<List<long>> AoBScan(string search, bool writable = false, bool executable = true, string file = "")
		{
			return this.AoBScan(0L, long.MaxValue, search, writable, executable, file);
		}

		// Token: 0x0600005D RID: 93 RVA: 0x0000BFCC File Offset: 0x0000A1CC
		public Task<List<long>> AoBScan(string search, bool readable, bool writable, bool executable, string file = "")
		{
			return this.AoBScan(0L, long.MaxValue, search, readable, writable, executable, file);
		}

		// Token: 0x0600005E RID: 94 RVA: 0x0000BFE6 File Offset: 0x0000A1E6
		public Task<List<long>> AoBScan(long start, long end, string search, bool writable = false, bool executable = true, string file = "")
		{
			return this.AoBScan(start, end, search, false, writable, executable, file);
		}

		// Token: 0x0600005F RID: 95 RVA: 0x0000BFF8 File Offset: 0x0000A1F8
		public Task<List<long>> AoBScan(long start, long end, string search, bool readable, bool writable, bool executable, string file = "")
		{
			return Task.Run<List<long>>(delegate()
			{
				List<MemoryRegionResult> list = new List<MemoryRegionResult>();
				string[] array = this.LoadCode(search, file).Split(new char[]
				{
					' '
				});
				byte[] aobPattern = new byte[array.Length];
				byte[] mask = new byte[array.Length];
				for (int i = 0; i < array.Length; i++)
				{
					string text = array[i];
					if (text == "??" || (text.Length == 1 && text == "?"))
					{
						mask[i] = 0;
						array[i] = "0x00";
					}
					else if (char.IsLetterOrDigit(text[0]) && text[1] == '?')
					{
						mask[i] = 240;
						array[i] = text[0].ToString() + "0";
					}
					else if (char.IsLetterOrDigit(text[1]) && text[0] == '?')
					{
						mask[i] = 15;
						array[i] = "0" + text[1].ToString();
					}
					else
					{
						mask[i] = byte.MaxValue;
					}
				}
				for (int j = 0; j < array.Length; j++)
				{
					aobPattern[j] = (Convert.ToByte(array[j], 16) & mask[j]);
				}
				Imps.SYSTEM_INFO system_INFO = default(Imps.SYSTEM_INFO);
				Imps.GetSystemInfo(out system_INFO);
				UIntPtr minimumApplicationAddress = system_INFO.minimumApplicationAddress;
				UIntPtr maximumApplicationAddress = system_INFO.maximumApplicationAddress;
				if (start < (long)minimumApplicationAddress.ToUInt64())
				{
					start = (long)minimumApplicationAddress.ToUInt64();
				}
				if (end > (long)maximumApplicationAddress.ToUInt64())
				{
					end = (long)maximumApplicationAddress.ToUInt64();
				}
				UIntPtr uintPtr = new UIntPtr((ulong)start);
				Imps.MEMORY_BASIC_INFORMATION memory_BASIC_INFORMATION = default(Imps.MEMORY_BASIC_INFORMATION);
				while (this.VirtualQueryEx(this.mProc.Handle, uintPtr, out memory_BASIC_INFORMATION).ToUInt64() != 0UL && uintPtr.ToUInt64() < (ulong)end && uintPtr.ToUInt64() + (ulong)memory_BASIC_INFORMATION.RegionSize > uintPtr.ToUInt64())
				{
					bool flag = memory_BASIC_INFORMATION.State == 4096U;
					flag &= (memory_BASIC_INFORMATION.BaseAddress.ToUInt64() < maximumApplicationAddress.ToUInt64());
					flag &= ((memory_BASIC_INFORMATION.Protect & 256U) == 0U);
					flag &= ((memory_BASIC_INFORMATION.Protect & 1U) == 0U);
					flag &= (memory_BASIC_INFORMATION.Type == 131072U || memory_BASIC_INFORMATION.Type == 16777216U);
					if (flag)
					{
						bool flag2 = (memory_BASIC_INFORMATION.Protect & 2U) > 0U;
						bool flag3 = (memory_BASIC_INFORMATION.Protect & 4U) > 0U || (memory_BASIC_INFORMATION.Protect & 8U) > 0U || (memory_BASIC_INFORMATION.Protect & 64U) > 0U || (memory_BASIC_INFORMATION.Protect & 128U) > 0U;
						bool flag4 = (memory_BASIC_INFORMATION.Protect & 16U) > 0U || (memory_BASIC_INFORMATION.Protect & 32U) > 0U || (memory_BASIC_INFORMATION.Protect & 64U) > 0U || (memory_BASIC_INFORMATION.Protect & 128U) > 0U;
						flag2 &= readable;
						flag3 &= writable;
						flag4 &= executable;
						flag &= (flag2 || flag3 || flag4);
					}
					if (!flag)
					{
						uintPtr = new UIntPtr(memory_BASIC_INFORMATION.BaseAddress.ToUInt64() + (ulong)memory_BASIC_INFORMATION.RegionSize);
					}
					else
					{
						MemoryRegionResult item2 = new MemoryRegionResult
						{
							CurrentBaseAddress = uintPtr,
							RegionSize = memory_BASIC_INFORMATION.RegionSize,
							RegionBase = memory_BASIC_INFORMATION.BaseAddress
						};
						uintPtr = new UIntPtr(memory_BASIC_INFORMATION.BaseAddress.ToUInt64() + (ulong)memory_BASIC_INFORMATION.RegionSize);
						if (list.Count > 0)
						{
							MemoryRegionResult memoryRegionResult = list[list.Count - 1];
							if ((ulong)memoryRegionResult.RegionBase + (ulong)memoryRegionResult.RegionSize == (ulong)memory_BASIC_INFORMATION.BaseAddress)
							{
								list[list.Count - 1] = new MemoryRegionResult
								{
									CurrentBaseAddress = memoryRegionResult.CurrentBaseAddress,
									RegionBase = memoryRegionResult.RegionBase,
									RegionSize = memoryRegionResult.RegionSize + memory_BASIC_INFORMATION.RegionSize
								};
								continue;
							}
						}
						list.Add(item2);
					}
				}
				ConcurrentBag<long> bagResult = new ConcurrentBag<long>();
				Parallel.ForEach<MemoryRegionResult>(list, delegate(MemoryRegionResult item, ParallelLoopState parallelLoopState, long index)
				{
					foreach (long item3 in this.CompareScan(item, aobPattern, mask))
					{
						bagResult.Add(item3);
					}
				});
				return bagResult.ToList<long>();
			});
		}

		// Token: 0x06000060 RID: 96 RVA: 0x0000C058 File Offset: 0x0000A258
		public Task<long> AoBScan(string code, long end, string search, string file = "")
		{
			Mem.<AoBScan>d__36 <AoBScan>d__;
			<AoBScan>d__.<>t__builder = AsyncTaskMethodBuilder<long>.Create();
			<AoBScan>d__.<>4__this = this;
			<AoBScan>d__.code = code;
			<AoBScan>d__.end = end;
			<AoBScan>d__.search = search;
			<AoBScan>d__.file = file;
			<AoBScan>d__.<>1__state = -1;
			<AoBScan>d__.<>t__builder.Start<Mem.<AoBScan>d__36>(ref <AoBScan>d__);
			return <AoBScan>d__.<>t__builder.Task;
		}

		// Token: 0x06000061 RID: 97 RVA: 0x0000C0BC File Offset: 0x0000A2BC
		private unsafe long[] CompareScan(MemoryRegionResult item, byte[] aobPattern, byte[] mask)
		{
			if (mask.Length != aobPattern.Length)
			{
				throw new ArgumentException("aobPattern.Length != mask.Length");
			}
			IntPtr intPtr = Marshal.AllocHGlobal((int)item.RegionSize);
			ulong num;
			Imps.ReadProcessMemory(this.mProc.Handle, item.CurrentBaseAddress, intPtr, (UIntPtr)((ulong)item.RegionSize), out num);
			int num2 = 0 - aobPattern.Length;
			List<long> list = new List<long>();
			do
			{
				num2 = this.FindPattern((byte*)intPtr.ToPointer(), (int)num, aobPattern, mask, num2 + aobPattern.Length);
				if (num2 >= 0)
				{
					list.Add((long)((ulong)item.CurrentBaseAddress + (ulong)((long)num2)));
				}
			}
			while (num2 != -1);
			Marshal.FreeHGlobal(intPtr);
			return list.ToArray();
		}

		// Token: 0x06000062 RID: 98 RVA: 0x0000C160 File Offset: 0x0000A360
		private unsafe int FindPattern(byte* body, int bodyLength, byte[] pattern, byte[] masks, int start = 0)
		{
			int result = -1;
			if (bodyLength <= 0 || pattern.Length == 0 || start > bodyLength - pattern.Length || pattern.Length > bodyLength)
			{
				return result;
			}
			for (int i = start; i <= bodyLength - pattern.Length; i++)
			{
				if ((body[i] & masks[0]) == (pattern[0] & masks[0]))
				{
					bool flag = true;
					for (int j = pattern.Length - 1; j >= 1; j--)
					{
						if ((body[i + j] & masks[j]) != (pattern[j] & masks[j]))
						{
							flag = false;
							break;
						}
					}
					if (flag)
					{
						result = i;
						break;
					}
				}
			}
			return result;
		}

		// Token: 0x06000063 RID: 99 RVA: 0x0000C1E0 File Offset: 0x0000A3E0
		public string CutString(string str)
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (char c in str)
			{
				if (c < ' ' || c > '~')
				{
					break;
				}
				stringBuilder.Append(c);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000064 RID: 100 RVA: 0x0000C228 File Offset: 0x0000A428
		public bool ReadBytes(IntPtr handle, IntPtr address, int length, out byte[] buffer)
		{
			buffer = new byte[length];
			int num = 0;
			if (!Mem.Kernel32.ReadProcessMemory(handle, address, buffer, length, ref num) || num != length)
			{
				buffer = null;
				return false;
			}
			return true;
		}

		// Token: 0x06000065 RID: 101 RVA: 0x0000C25C File Offset: 0x0000A45C
		public float ReadFloat(string code, string file = "", bool round = true)
		{
			byte[] array = new byte[4];
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return 0f;
			}
			float result;
			try
			{
				if (Imps.ReadProcessMemory(this.mProc.Handle, code2, array, (UIntPtr)4UL, IntPtr.Zero))
				{
					float num = BitConverter.ToSingle(array, 0);
					float num2 = num;
					if (round)
					{
						num2 = (float)Math.Round((double)num, 2);
					}
					result = num2;
				}
				else
				{
					result = 0f;
				}
			}
			catch
			{
				result = 0f;
			}
			return result;
		}

		// Token: 0x06000066 RID: 102 RVA: 0x0000C300 File Offset: 0x0000A500
		public bool WriteFloat(string code, float value, string file = "")
		{
			byte[] bytes = BitConverter.GetBytes(value);
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return false;
			}
			bool result;
			try
			{
				result = Imps.WriteProcessMemory(this.mProc.Handle, code2, bytes, (UIntPtr)((ulong)((long)bytes.Length)), IntPtr.Zero);
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000067 RID: 103 RVA: 0x0000C378 File Offset: 0x0000A578
		public string ReadString(string code, string file = "", int length = 32, bool zeroTerminated = true, Encoding stringEncoding = null)
		{
			if (stringEncoding == null)
			{
				stringEncoding = Encoding.UTF8;
			}
			byte[] array = new byte[length];
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return "";
			}
			if (!Imps.ReadProcessMemory(this.mProc.Handle, code2, array, (UIntPtr)((ulong)((long)length)), IntPtr.Zero))
			{
				return "";
			}
			if (!zeroTerminated)
			{
				return stringEncoding.GetString(array);
			}
			return stringEncoding.GetString(array).Split(new char[1])[0];
		}

		// Token: 0x06000068 RID: 104 RVA: 0x0000C40C File Offset: 0x0000A60C
		public double ReadDouble(string code, string file = "", bool round = true)
		{
			byte[] array = new byte[8];
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return 0.0;
			}
			double result;
			try
			{
				if (Imps.ReadProcessMemory(this.mProc.Handle, code2, array, (UIntPtr)8UL, IntPtr.Zero))
				{
					double num = BitConverter.ToDouble(array, 0);
					double num2 = num;
					if (round)
					{
						num2 = Math.Round(num, 2);
					}
					result = num2;
				}
				else
				{
					result = 0.0;
				}
			}
			catch
			{
				result = 0.0;
			}
			return result;
		}

		// Token: 0x06000069 RID: 105 RVA: 0x0000C4BC File Offset: 0x0000A6BC
		public void WriteDouble(string code, double value, string file = "")
		{
			byte[] bytes = BitConverter.GetBytes(value);
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return;
			}
			try
			{
				Imps.WriteProcessMemory(this.mProc.Handle, code2, bytes, (UIntPtr)8UL, IntPtr.Zero);
			}
			catch
			{
			}
		}

		// Token: 0x0600006A RID: 106 RVA: 0x0000C52C File Offset: 0x0000A72C
		public int ReadUIntPtr(UIntPtr code)
		{
			byte[] array = new byte[4];
			if (Imps.ReadProcessMemory(this.mProc.Handle, code, array, (UIntPtr)4UL, IntPtr.Zero))
			{
				return BitConverter.ToInt32(array, 0);
			}
			return 0;
		}

		// Token: 0x0600006B RID: 107 RVA: 0x0000C56C File Offset: 0x0000A76C
		public int ReadInt(string code, string file = "")
		{
			byte[] array = new byte[4];
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return 0;
			}
			if (Imps.ReadProcessMemory(this.mProc.Handle, code2, array, (UIntPtr)4UL, IntPtr.Zero))
			{
				return BitConverter.ToInt32(array, 0);
			}
			return 0;
		}

		// Token: 0x0600006C RID: 108 RVA: 0x0000C5D4 File Offset: 0x0000A7D4
		public long ReadLong(string code, string file = "")
		{
			byte[] array = new byte[16];
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return 0L;
			}
			if (Imps.ReadProcessMemory(this.mProc.Handle, code2, array, (UIntPtr)8UL, IntPtr.Zero))
			{
				return BitConverter.ToInt64(array, 0);
			}
			return 0L;
		}

		// Token: 0x0600006D RID: 109 RVA: 0x0000C63C File Offset: 0x0000A83C
		public uint ReadUInt(string code, string file = "")
		{
			byte[] array = new byte[4];
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return 0U;
			}
			if (Imps.ReadProcessMemory(this.mProc.Handle, code2, array, (UIntPtr)4UL, IntPtr.Zero))
			{
				return BitConverter.ToUInt32(array, 0);
			}
			return 0U;
		}

		// Token: 0x0600006E RID: 110 RVA: 0x0000C6A4 File Offset: 0x0000A8A4
		public int Read2Byte(string code, string file = "")
		{
			byte[] array = new byte[4];
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return 0;
			}
			if (Imps.ReadProcessMemory(this.mProc.Handle, code2, array, (UIntPtr)2UL, IntPtr.Zero))
			{
				return BitConverter.ToInt32(array, 0);
			}
			return 0;
		}

		// Token: 0x0600006F RID: 111 RVA: 0x0000C70C File Offset: 0x0000A90C
		public int ReadByte(string code, string file = "")
		{
			byte[] array = new byte[1];
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return 0;
			}
			if (Imps.ReadProcessMemory(this.mProc.Handle, code2, array, (UIntPtr)1UL, IntPtr.Zero))
			{
				return (int)array[0];
			}
			return 0;
		}

		// Token: 0x06000070 RID: 112 RVA: 0x0000C770 File Offset: 0x0000A970
		public bool[] ReadBits(string code, string file = "")
		{
			byte[] array = new byte[1];
			UIntPtr code2 = this.GetCode(code, file, 8);
			bool[] array2 = new bool[8];
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return array2;
			}
			if (!Imps.ReadProcessMemory(this.mProc.Handle, code2, array, (UIntPtr)1UL, IntPtr.Zero))
			{
				return array2;
			}
			if (!BitConverter.IsLittleEndian)
			{
				throw new Exception("Should be little endian");
			}
			for (int i = 0; i < 8; i++)
			{
				array2[i] = Convert.ToBoolean((int)array[0] & 1 << i);
			}
			return array2;
		}

		// Token: 0x06000071 RID: 113 RVA: 0x0000C808 File Offset: 0x0000AA08
		public T ReadMemory<T>(string address, string file = "")
		{
			object obj = null;
			switch (Type.GetTypeCode(typeof(T)))
			{
			case TypeCode.Byte:
				obj = this.ReadByte(address, file);
				break;
			case TypeCode.Int32:
				obj = this.ReadInt(address, file);
				break;
			case TypeCode.UInt32:
				obj = this.ReadUInt(address, file);
				break;
			case TypeCode.Int64:
				obj = this.ReadLong(address, file);
				break;
			case TypeCode.Double:
				obj = this.ReadDouble(address, file, true);
				break;
			case TypeCode.Decimal:
				obj = this.ReadFloat(address, file, true);
				break;
			case TypeCode.String:
				obj = this.ReadString(address, file, 32, true, null);
				break;
			}
			if (obj != null)
			{
				return (T)((object)Convert.ChangeType(obj, typeof(T)));
			}
			return default(T);
		}

		// Token: 0x06000072 RID: 114 RVA: 0x0000C8F8 File Offset: 0x0000AAF8
		public bool FreezeValue(string address, string type, string value, string file = "")
		{
			CancellationTokenSource cts = new CancellationTokenSource();
			if (this.FreezeTokenSrcs.ContainsKey(address))
			{
				try
				{
					this.FreezeTokenSrcs[address].Cancel();
					CancellationTokenSource cancellationTokenSource;
					this.FreezeTokenSrcs.TryRemove(address, out cancellationTokenSource);
				}
				catch
				{
					return false;
				}
			}
			this.FreezeTokenSrcs.TryAdd(address, cts);
			Task.Factory.StartNew(delegate()
			{
				while (!cts.Token.IsCancellationRequested)
				{
					this.WriteMemory(address, type, value, file, null, true);
					Thread.Sleep(25);
				}
			}, cts.Token);
			return true;
		}

		// Token: 0x06000073 RID: 115 RVA: 0x0000C9CC File Offset: 0x0000ABCC
		public void UnfreezeValue(string address)
		{
			try
			{
				ConcurrentDictionary<string, CancellationTokenSource> freezeTokenSrcs = this.FreezeTokenSrcs;
				lock (freezeTokenSrcs)
				{
					this.FreezeTokenSrcs[address].Cancel();
					CancellationTokenSource cancellationTokenSource;
					this.FreezeTokenSrcs.TryRemove(address, out cancellationTokenSource);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000074 RID: 116 RVA: 0x0000CA38 File Offset: 0x0000AC38
		public bool WriteMemory(string code, string type, string write, string file = "", Encoding stringEncoding = null, bool RemoveWriteProtection = true)
		{
			byte[] array = new byte[4];
			int num = 4;
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (code2 == UIntPtr.Zero || code2.ToUInt64() < 65536UL)
			{
				return false;
			}
			if (type.ToLower() == "float")
			{
				write = Convert.ToString(float.Parse(write, CultureInfo.InvariantCulture));
				array = BitConverter.GetBytes(Convert.ToSingle(write));
				num = 4;
			}
			else if (type.ToLower() == "int")
			{
				array = BitConverter.GetBytes(Convert.ToInt32(write));
				num = 4;
			}
			else if (type.ToLower() == "byte")
			{
				array = new byte[]
				{
					Convert.ToByte(write, 16)
				};
				num = 1;
			}
			else if (type.ToLower() == "2bytes")
			{
				array = new byte[]
				{
					(byte)(Convert.ToInt32(write) % 256),
					(byte)(Convert.ToInt32(write) / 256)
				};
				num = 2;
			}
			else if (type.ToLower() == "bytes")
			{
				if (write.Contains(",") || write.Contains(" "))
				{
					string[] array2;
					if (write.Contains(","))
					{
						array2 = write.Split(new char[]
						{
							','
						});
					}
					else
					{
						array2 = write.Split(new char[]
						{
							' '
						});
					}
					int num2 = array2.Count<string>();
					array = new byte[num2];
					for (int i = 0; i < num2; i++)
					{
						array[i] = Convert.ToByte(array2[i], 16);
					}
					num = array2.Count<string>();
				}
				else
				{
					array = new byte[]
					{
						Convert.ToByte(write, 16)
					};
					num = 1;
				}
			}
			else if (type.ToLower() == "double")
			{
				array = BitConverter.GetBytes(Convert.ToDouble(write));
				num = 8;
			}
			else if (type.ToLower() == "long")
			{
				array = BitConverter.GetBytes(Convert.ToInt64(write));
				num = 8;
			}
			else if (type.ToLower() == "string")
			{
				if (stringEncoding == null)
				{
					array = Encoding.UTF8.GetBytes(write);
				}
				else
				{
					array = stringEncoding.GetBytes(write);
				}
				num = array.Length;
			}
			Imps.MemoryProtection newProtection = (Imps.MemoryProtection)0U;
			if (RemoveWriteProtection)
			{
				this.ChangeProtection(code, Imps.MemoryProtection.ExecuteReadWrite, out newProtection, file);
			}
			bool result = Imps.WriteProcessMemory(this.mProc.Handle, code2, array, (UIntPtr)((ulong)((long)num)), IntPtr.Zero);
			if (RemoveWriteProtection)
			{
				Imps.MemoryProtection memoryProtection;
				this.ChangeProtection(code, newProtection, out memoryProtection, file);
			}
			return result;
		}

		// Token: 0x06000075 RID: 117 RVA: 0x0000CCB0 File Offset: 0x0000AEB0
		public bool WriteMove(string code, string type, string write, int MoveQty, string file = "", int SlowDown = 0)
		{
			byte[] lpBuffer = new byte[4];
			int num = 4;
			UIntPtr code2 = this.GetCode(code, file, 8);
			if (type == "float")
			{
				lpBuffer = new byte[write.Length];
				lpBuffer = BitConverter.GetBytes(Convert.ToSingle(write));
				num = write.Length;
			}
			else if (type == "int")
			{
				lpBuffer = BitConverter.GetBytes(Convert.ToInt32(write));
				num = 4;
			}
			else if (type == "double")
			{
				lpBuffer = BitConverter.GetBytes(Convert.ToDouble(write));
				num = 8;
			}
			else if (type == "long")
			{
				lpBuffer = BitConverter.GetBytes(Convert.ToInt64(write));
				num = 8;
			}
			else if (type == "byte")
			{
				lpBuffer = new byte[]
				{
					Convert.ToByte(write, 16)
				};
				num = 1;
			}
			else if (type == "string")
			{
				lpBuffer = new byte[write.Length];
				lpBuffer = Encoding.UTF8.GetBytes(write);
				num = write.Length;
			}
			UIntPtr lpBaseAddress = UIntPtr.Add(code2, MoveQty);
			Thread.Sleep(SlowDown);
			return Imps.WriteProcessMemory(this.mProc.Handle, lpBaseAddress, lpBuffer, (UIntPtr)((ulong)((long)num)), IntPtr.Zero);
		}

		// Token: 0x06000076 RID: 118 RVA: 0x0000CDD8 File Offset: 0x0000AFD8
		public void WriteBytes(string code, byte[] write, string file = "")
		{
			UIntPtr code2 = this.GetCode(code, file, 8);
			Imps.WriteProcessMemory(this.mProc.Handle, code2, write, (UIntPtr)((ulong)((long)write.Length)), IntPtr.Zero);
		}

		// Token: 0x06000077 RID: 119 RVA: 0x0000CE10 File Offset: 0x0000B010
		public void WriteBits(string code, bool[] bits, string file = "")
		{
			if (bits.Length != 8)
			{
				throw new ArgumentException("Not enough bits for a whole byte", "bits");
			}
			byte[] array = new byte[1];
			UIntPtr code2 = this.GetCode(code, file, 8);
			for (int i = 0; i < 8; i++)
			{
				if (bits[i])
				{
					byte[] array2 = array;
					int num = 0;
					array2[num] |= (byte)(1 << i);
				}
			}
			Imps.WriteProcessMemory(this.mProc.Handle, code2, array, (UIntPtr)1UL, IntPtr.Zero);
		}

		// Token: 0x06000078 RID: 120 RVA: 0x0000CE88 File Offset: 0x0000B088
		public void WriteBytes(UIntPtr address, byte[] write)
		{
			IntPtr intPtr;
			Imps.WriteProcessMemory(this.mProc.Handle, address, write, (UIntPtr)((ulong)((long)write.Length)), out intPtr);
		}

		// Token: 0x040000AC RID: 172
		public Proc mProc = new Proc();

		// Token: 0x040000AD RID: 173
		private ConcurrentDictionary<string, CancellationTokenSource> FreezeTokenSrcs = new ConcurrentDictionary<string, CancellationTokenSource>();

		// Token: 0x0200001A RID: 26
		public class Kernel32
		{
			// Token: 0x0600029C RID: 668
			[DllImport("kernel32.dll", SetLastError = true)]
			public static extern bool ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, [Out] byte[] lpBuffer, int nSize, ref int lpNumberOfBytesRead);
		}
	}
}
