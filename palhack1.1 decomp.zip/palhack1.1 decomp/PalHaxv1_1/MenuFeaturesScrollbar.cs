﻿using System;
using System.Windows.Forms;

namespace PalHaxv1_1
{
	// Token: 0x02000012 RID: 18
	public static class MenuFeaturesScrollbar
	{
		// Token: 0x06000257 RID: 599 RVA: 0x00010319 File Offset: 0x0000E519
		public static void SpeedBar_ValueChanged(object sender, EventArgs e)
		{
			Offsets.CustomTimeDilation = (float)((TrackBar)sender).Value;
		}

		// Token: 0x06000258 RID: 600 RVA: 0x0001032C File Offset: 0x0000E52C
		public static void SpeedBar2_ValueChanged(object sender, EventArgs e)
		{
			Offsets.TimeDilation = (float)((TrackBar)sender).Value;
		}
	}
}
