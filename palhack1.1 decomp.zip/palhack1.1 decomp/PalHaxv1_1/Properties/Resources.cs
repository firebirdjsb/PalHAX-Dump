﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace PalHaxv1_1.Properties
{
	// Token: 0x02000017 RID: 23
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x06000291 RID: 657 RVA: 0x0001168E File Offset: 0x0000F88E
		internal Resources()
		{
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x06000292 RID: 658 RVA: 0x00011696 File Offset: 0x0000F896
		

		// Token: 0x04000193 RID: 403
		private static ResourceManager resourceMan;

		// Token: 0x04000194 RID: 404
		private static CultureInfo resourceCulture;
	}
}
