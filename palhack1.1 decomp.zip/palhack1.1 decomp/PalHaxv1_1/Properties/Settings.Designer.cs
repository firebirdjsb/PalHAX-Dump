﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace PalHaxv1_1.Properties
{
	// Token: 0x02000018 RID: 24
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000295 RID: 661 RVA: 0x000116D1 File Offset: 0x0000F8D1
		public static Settings Default
		{
			get
			{
				return Settings.defaultInstance;
			}
		}

		// Token: 0x04000195 RID: 405
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());
	}
}
