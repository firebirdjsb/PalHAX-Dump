﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalHaxv1_1
{
    public partial class Overlay : Form
    {
        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(Keys vKey);

        public Overlay()
        {
            InitializeComponent();
            Initialize();
            cancellationTokenSource = new CancellationTokenSource();
            Task.Run(async () =>
            {
                await UpdateProcessStatus(cancellationTokenSource.Token);
            });
        }

        private void Initialize()
        {
            LoadKeybinds();
            SetupUI();
            SetupKeyboardHook();
            SetupCheatMenu();
            StartProcessStatusUpdate();
            SetCulture();
            StartTimer();
        }

        private void SetupUI()
        {
            BackColor = Color.Wheat;
            TransparencyKey = Color.Wheat;
            FormBorderStyle = FormBorderStyle.None;
            TopMost = true;
            Imps.SetWindowLong(Handle, -20, Imps.GetWindowLong(Handle, -20) | 32768 | 32);
            DoubleBuffered = true;
            Screen primaryScreen = Screen.PrimaryScreen;
            Location = new Point(primaryScreen.WorkingArea.Left, primaryScreen.WorkingArea.Top);
            ConnectionText.ForeColor = Color.Red;
            UpdateConnectionStatusWithDateTime();
            ConnectionPanel.BorderStyle = BorderStyle.FixedSingle;
            ConnectionPanel.Controls.Add(ConnectionText);
            Controls.Add(ConnectionPanel);
        }

        private void LoadKeybinds()
        {
            keybinds = ConfigurationManager.LoadKeybinds("Keybinds.json");
            UpdateKeybindLabels();
        }

        private void UpdateKeybindLabels()
        {
            LSpoofPositionKey.Text = "Spoof Position: " + keybinds.SpoofPosition;
            LFlymodeKey.Text = "Flymode: " + keybinds.Flymode;
            LSpeedhackKey.Text = "Speedhack: " + keybinds.Speedhack;
            LSuperJumpKey.Text = "Super Jump: " + keybinds.SuperJump;
        }

        private void SetupKeyboardHook()
        {
            keyboardHook = new GlobalKeyboardHook();
            keyboardHook.KeyDown += GlobalKeyDown;
            keyboardHook.KeyUp += GlobalKeyUp;
        }

        private void SetupCheatMenu()
        {
            cheatMenuForm = new CheatMenu();
            cheatMenuForm.Hide();
            cheatMenuForm.ShowWatermarkToggled += CheatMenuForm_ShowWatermarkToggled;
            cheatMenuForm.ShowHotkeyToggled += CheatMenuForm_ShowHotkeyToggled;
            cheatMenuForm.SpoofPositionToggled += (sender, isChecked) =>
            {
                UpdateLabelColor(LSpoofPositionKey, isChecked);
            };
            cheatMenuForm.FlymodeToggled += (sender, isChecked) =>
            {
                UpdateLabelColor(LFlymodeKey, isChecked);
            };
            cheatMenuForm.SpeedhackToggled += (sender, isChecked) =>
            {
                UpdateLabelColor(LSpeedhackKey, isChecked);
            };
            cheatMenuForm.SuperJumpToggled += (sender, isChecked) =>
            {
                UpdateLabelColor(LSuperJumpKey, isChecked);
            };
        }

        private void StartProcessStatusUpdate()
        {
            cancellationTokenSource?.Dispose();
            cancellationTokenSource = new CancellationTokenSource();
            Task.Run(async () =>
            {
                await UpdateProcessStatus(cancellationTokenSource.Token);
            });
        }

        private void SetCulture()
        {
            CultureInfo cultureInfo = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentCulture = cultureInfo;
            Thread.CurrentThread.CurrentUICulture = cultureInfo;
        }

        private void StartTimer()
        {
            onTickMods.Start();
        }

        private void UpdateLabelColor(Label label, bool isChecked)
        {
            label.ForeColor = isChecked ? Color.Green : Color.Red;
        }

        private void ToggleCheatMenuForm()
        {
            if (cheatMenuForm.Visible)
            {
                cheatMenuForm.Hide();
                return;
            }
            cheatMenuForm.Show();
            Cursor.Position = cheatMenuForm.PointToScreen(new Point(cheatMenuForm.Width / 2, cheatMenuForm.Height / 2));
        }

        private new void Update()
        {
            UpdateConnectionStatusWithDateTime();
        }

        private async Task UpdateProcessStatus(CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                UpdateConnectionStatusWithDateTime();
                await Task.Delay(1000, cancellationToken);
            }
        }

        private void UpdateConnectionStatusWithDateTime()
        {
            string statusText = Bools.IsProcessOpen ? $"{HackVersion} - - Unknowncheats.me - - {DateTime.Now} - -" : "-ERROR-";
            if (ConnectionText.Text != statusText)
            {
                Invoke(new Action(() =>
                {
                    ConnectionText.Text = statusText;
                    ConnectionText.ForeColor = Bools.IsProcessOpen ? Color.Cyan : Color.Red;
                    Size size = TextRenderer.MeasureText(ConnectionText.Text, ConnectionText.Font);
                    ConnectionPanel.Size = new Size(size.Width + 6, size.Height + 6);
                    int x = (ConnectionPanel.Width - size.Width) / 2;
                    int y = (ConnectionPanel.Height - size.Height) / 2;
                    ConnectionText.Location = new Point(x, y);
                }));
            }
        }

        private async Task AttemptOpenProcessAsync()
        {
            while (!Bools.IsProcessOpen)
            {
                // Attempt to open the process
                await Task.Delay(1000);
            }
        }

        private void GlobalKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.ToString() == keybinds.ExitCheat)
            {
                ExitApplication();
                return;
            }
            if (e.KeyCode.ToString() == keybinds.ShowMenu)
            {
                ToggleCheatMenuForm();
                return;
            }
            if (e.KeyCode.ToString() == keybinds.SpoofPosition)
            {
                ToggleSpoofPositionCheckbox();
                return;
            }
            if (e.KeyCode.ToString() == keybinds.Flymode)
            {
                ToggleFlymodeCheckbox();
                return;
            }
            if (e.KeyCode.ToString() == keybinds.Speedhack)
            {
                ToggleSpeedhackCheckbox();
                return;
            }
            if (e.KeyCode.ToString() == keybinds.SuperJump)
            {
                ToggleSuperJumpCheckbox();
            }
        }

        private void ExitApplication()
        {
            Close();
        }

        private void GlobalKeyUp(object sender, KeyEventArgs e)
        {
        }

        private void ToggleSpoofPositionCheckbox()
        {
            cheatMenuForm?.ToggleSpoofPositionCheckbox();
        }

        private void ToggleFlymodeCheckbox()
        {
            cheatMenuForm?.ToggleFlymodeCheckbox();
        }

        private void ToggleSpeedhackCheckbox()
        {
            cheatMenuForm?.ToggleSpeedhackCheckbox();
        }

        private void ToggleSuperJumpCheckbox()
        {
            cheatMenuForm?.ToggleSuperJumpCheckbox();
        }

        private void CheatMenuForm_ShowWatermarkToggled(object sender, bool isChecked)
        {
            ConnectionPanel.Visible = isChecked;
        }

        private void CheatMenuForm_ShowHotkeyToggled(object sender, bool isChecked)
        {
            LSpoofPositionKey.Visible = isChecked;
            LFlymodeKey.Visible = isChecked;
            LSpeedhackKey.Visible = isChecked;
            LSuperJumpKey.Visible = isChecked;
        }

        private void Overlay_Load(object sender, EventArgs e)
        {
            onTickMods.Start();
        }

        private void onTickMods_Tick(object sender, EventArgs e)
        {
            Update();
            TimeSpan.FromSeconds(2.0);
            HandleFlymode();
        }

        private void HandleFlymode()
        {
            if (cheatMenuForm != null && cheatMenuForm.IsFlymodeEnabled())
            {
                Offsets.VelocityZ = 0.0;
                Offsets.AirControl = 100f;
                if (GetAsyncKeyState(Keys.Space) < 0)
                {
                    Offsets.VelocityZ = 850.0;
                    return;
                }
                if (GetAsyncKeyState(Keys.LControlKey) < 0)
                {
                    Offsets.VelocityZ = -850.0;
                }
            }
        }

        private void Overlay_FormClosing(object sender, FormClosingEventArgs e)
        {
            keyboardHook.Dispose();
            cancellationTokenSource?.Cancel();
            cancellationTokenSource?.Dispose();
            exitEvent.Set();
            onTickMods.Stop();
        }

        private static readonly string[] TargetProcessNames = new string[]
        {
            "Palworld-Win64-Shipping",
            "Palworld-WinGDK-Shipping"
        };

        private const string HackVersion = "PalHax v1.1";
        private const string ErrorStatusText = "-ERROR-";
        private readonly ManualResetEvent exitEvent = new ManualResetEvent(false);
        private Keybinds keybinds;
        private Process currentGameProcess;
        private CheatMenu cheatMenuForm;
        private GlobalKeyboardHook keyboardHook;
        private CancellationTokenSource cancellationTokenSource;
    }
}
