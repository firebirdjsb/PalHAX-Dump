﻿using System;

namespace PalHaxv1_1
{
	// Token: 0x0200000C RID: 12
	public static class MenuFeaturesCheckbox
	{
		// Token: 0x06000217 RID: 535 RVA: 0x0000E7C0 File Offset: 0x0000C9C0
		public static void HandleSpoofPositionCheckbox(bool isChecked)
		{
			if (isChecked)
			{
				MenuFeaturesCheckbox.originalReplicateMovementValue = new byte?(Offsets.bReplicateMovement);
				Offsets.bReplicateMovement = 0;
				return;
			}
			if (MenuFeaturesCheckbox.originalReplicateMovementValue != null)
			{
				Offsets.bReplicateMovement = MenuFeaturesCheckbox.originalReplicateMovementValue.Value;
				MenuFeaturesCheckbox.originalReplicateMovementValue = null;
			}
		}

		// Token: 0x06000218 RID: 536 RVA: 0x0000E80C File Offset: 0x0000CA0C
		public static void HandleCarryWeightCheckbox(bool isChecked)
		{
			if (isChecked)
			{
				MenuFeaturesCheckbox.originalNowItemWeightValue = Offsets.NowItemWeight;
				MenuFeaturesCheckbox.originalMaxInventoryWeightValue = Offsets.MaxInventoryWeight;
				Bools.originalValuesStored = true;
				Offsets.NowItemWeight = 0f;
				Offsets.MaxInventoryWeight = 2.1474836E+09f;
				return;
			}
			if (Bools.originalValuesStored)
			{
				Offsets.NowItemWeight = MenuFeaturesCheckbox.originalNowItemWeightValue;
				Offsets.MaxInventoryWeight = MenuFeaturesCheckbox.originalMaxInventoryWeightValue;
				Bools.originalValuesStored = false;
			}
		}

		// Token: 0x06000219 RID: 537 RVA: 0x0000E86C File Offset: 0x0000CA6C
		public static void HandleSpeedhackCheckbox(bool isChecked)
		{
			int num = isChecked ? 2600 : 350;
			Offsets.MaxWalkSpeed = (float)num;
			Offsets.MaxWalkSpeedCrouched = (float)num;
			Offsets.MaxSwimSpeed = (float)num;
			Offsets.MaxFlySpeed = (float)num;
			Offsets.MaxCustomMovementSpeed = (float)num;
			Offsets.MaxAcceleration = (float)(isChecked ? 4096 : 2048);
			Offsets.FatigueMaxSpeed = (float)(isChecked ? 2500 : 100);
			Offsets.SprintMaxSpeed = (float)(isChecked ? 3600 : 500);
			Offsets.SprintMaxAcceleration = (float)(isChecked ? 2048 : 1024);
			Offsets.ClimbMaxSpeed = (float)(isChecked ? 2000 : 100);
			Offsets.RollingMaxSpeed = (float)(isChecked ? 15000 : 5000);
			Offsets.SlidingMaxSpeed = (float)(isChecked ? 6000 : 1500);
			Offsets.SlidingStartSpeed = (float)(isChecked ? 6000 : 500);
		}

		// Token: 0x0600021A RID: 538 RVA: 0x0000E94C File Offset: 0x0000CB4C
		public static void HandleSuperJumpCheckbox(bool isChecked)
		{
			Offsets.JumpZVelocity = (float)(isChecked ? 2500 : 700);
		}

		// Token: 0x0600021B RID: 539 RVA: 0x0000E963 File Offset: 0x0000CB63
		public static void HandleGodmodeCheckbox(bool isChecked)
		{
			Offsets.bIsEnableMuteki = ((isChecked > false) ? 1 : 0);
		}

		// Token: 0x0600021C RID: 540 RVA: 0x0000E96E File Offset: 0x0000CB6E
		public static void HandleNeverWantedCheckbox(bool isChecked)
		{
			Offsets.CrimeStateMaintainDurationBaseDefault = (float)(isChecked ? 0 : 5);
		}

		// Token: 0x0600021D RID: 541 RVA: 0x0000E980 File Offset: 0x0000CB80
		public static void HandleBodyTemperatureDamageCheckbox(bool isChecked)
		{
			Offsets.BodyTemperatureStomachDecreaceRate1 = (isChecked ? 0f : 1.5f);
			Offsets.BodyTemperatureStomachDecreaceRate2 = (float)(isChecked ? 0 : 0);
			Offsets.BodyTemperatureStomachDecreaceRate3 = (float)(isChecked ? 0 : 2);
			Offsets.BodyTemperatureSlipDamagePercent1 = (isChecked ? 0f : 0.33f);
			Offsets.BodyTemperatureSlipDamagePercent2 = (float)(isChecked ? 0 : 0);
			Offsets.BodyTemperatureSlipDamagePercent3 = !isChecked;
		}

		// Token: 0x0600021E RID: 542 RVA: 0x0000E9E8 File Offset: 0x0000CBE8
		public static void HandleNoStomachCheckbox(bool isChecked)
		{
			Offsets.StarvationDecreaseHPPercentperSecond = (float)(isChecked ? 0 : 3);
			Offsets.StomachDecreaceperSecondMonster = (isChecked ? 0f : 0.025f);
			Offsets.StomachDecreaceperSecondPlayer = (isChecked ? 0f : 0.05f);
			Offsets.StomachDecreaceAutoHealing = (float)(isChecked ? 0 : 2);
			Offsets.StomachDecreaceWorkingRate = (float)(isChecked ? 0 : 2);
			Offsets.HungerStartStomachValue = (isChecked ? 0 : 30);
			Offsets.StomachDecreaceRateGroundRideSprint = (float)(isChecked ? 0 : 2);
			Offsets.StomachDecreaceRateWaterRide = (float)(isChecked ? 0 : 3);
			Offsets.StomachDecreaceRateWaterRideSprint = (float)(isChecked ? 0 : 5);
			Offsets.StomachDecreaceRateFlyRide = (float)(isChecked ? 0 : 3);
			Offsets.StomachDecreaceRateFlyRideSprint = (float)(isChecked ? 0 : 5);
		}

		// Token: 0x0600021F RID: 543 RVA: 0x0000EA92 File Offset: 0x0000CC92
		public static void HandleHealthRegenCheckbox(bool isChecked)
		{
			Offsets.AutoHPRegenePercentperSecond = (isChecked ? 100f : 0.3f);
			Offsets.AutoHPRegenePercentperSecondSleeping = (float)(isChecked ? 100 : 1);
		}

		// Token: 0x06000220 RID: 544 RVA: 0x0000EAB6 File Offset: 0x0000CCB6
		public static void HandleShieldRegenCheckbox(bool isChecked)
		{
			Offsets.PlayerShieldRecoverStartTime = (float)(isChecked ? 0 : 25);
			Offsets.PlayerShieldRecoverPercentPerSecond = (float)(isChecked ? 100 : 20);
		}

		// Token: 0x06000221 RID: 545 RVA: 0x0000EAD5 File Offset: 0x0000CCD5
		public static void HandleAIChaseCheckbox(bool isChecked)
		{
			Offsets.CombatEndDistance1 = (float)(isChecked ? 214748364 : 200);
			Offsets.CombatEndDistance2 = (float)(isChecked ? 214748364 : 100);
			Offsets.CombatEndDistance3 = (float)(isChecked ? 214748364 : 50);
		}

		// Token: 0x06000222 RID: 546 RVA: 0x0000EB10 File Offset: 0x0000CD10
		public static void HandleAIIgnoreCheckbox(bool isChecked)
		{
			Offsets.CombatEndDistance1 = (float)(isChecked ? 0 : 200);
			Offsets.CombatEndDistance2 = (float)(isChecked ? 0 : 100);
			Offsets.CombatEndDistance3 = (float)(isChecked ? 0 : 50);
		}

		// Token: 0x06000223 RID: 547 RVA: 0x0000EB3F File Offset: 0x0000CD3F
		public static void HandleOneHitCheckbox(bool isChecked)
		{
			Offsets.AttackUp = (isChecked ? 214748364 : 0);
			Offsets.DefenseUp = (isChecked ? 214748364 : 0);
		}

		// Token: 0x06000224 RID: 548 RVA: 0x0000EB64 File Offset: 0x0000CD64
		public static void HandleNoStaminaCheckbox(bool isChecked)
		{
			Offsets.ClimbingStaminaMove = (float)(isChecked ? 0 : 10);
			Offsets.ClimbingStaminaJump = (float)(isChecked ? 0 : 10);
			Offsets.FlyHoverSP = (isChecked ? 0f : 0.1f);
			Offsets.FlyHorizonSP = (isChecked ? 0f : 2.5f);
			Offsets.FlyHorizonDashSP = (float)(isChecked ? 0 : 10);
			Offsets.FlyVerticalSP = (float)(isChecked ? 0 : 5);
			Offsets.JumpSP = (isChecked ? 0 : 10);
			Offsets.StepSP = (isChecked ? 0 : 30);
			Offsets.MeleeAttackSP = (isChecked ? 0 : 5);
			Offsets.SprintSP = (float)(isChecked ? 0 : 7);
			Offsets.GliderSP = (float)(isChecked ? 0 : 15);
			Offsets.SwimmingSPIdle = (isChecked ? 0f : 1.5f);
			Offsets.SwimmingSPSwim = (isChecked ? 0f : 1.5f);
			Offsets.SwimmingSPDashSwim = (float)(isChecked ? 0 : 3);
			Offsets.RideWazaStaminaRate = (isChecked ? 0f : 0.3f);
		}

		// Token: 0x06000225 RID: 549 RVA: 0x0000EC5A File Offset: 0x0000CE5A
		public static void HandleNoRespawnDelayCheckbox(bool isChecked)
		{
			Offsets.BlockRespawnTime = (isChecked ? 0.1f : 5f);
		}

		// Token: 0x06000226 RID: 550 RVA: 0x0000EC70 File Offset: 0x0000CE70
		public static void HandleRarePalAppearanceCheckbox(bool isChecked)
		{
			Offsets.RarePalAppearanceProbability = (isChecked ? 100f : 0.1f);
			Offsets.BossOrRarePal_TalentMin = (isChecked ? 100 : 50);
			Offsets.CharacterMaxRank = (isChecked ? 100 : 50);
			Offsets.RarePal_LevelMultiply = (isChecked ? 100f : 1.5f);
		}

		// Token: 0x06000227 RID: 551 RVA: 0x0000ECC1 File Offset: 0x0000CEC1
		public static void HandleInstaFarmCheckbox(bool isChecked)
		{
			Offsets.DamageValueMinMapObject = (isChecked ? 214748364 : 1);
		}

		// Token: 0x06000228 RID: 552 RVA: 0x0000ECD3 File Offset: 0x0000CED3
		public static void HandleCatchRateCheckbox(bool isChecked)
		{
			Offsets.CaptureJudgeRate1 = (isChecked ? 0f : 0.1f);
			Offsets.CaptureJudgeRate2 = (isChecked ? 0f : 0.1f);
			Offsets.CaptureJudgeRate3 = (isChecked ? 0f : 0.1f);
		}

		// Token: 0x06000229 RID: 553 RVA: 0x0000ED14 File Offset: 0x0000CF14
		public static void HandleEggHatchCheckbox(bool isChecked)
		{
			Offsets.PalRarity1 = (isChecked ? 99 : 5);
			Offsets.EggScale1 = (isChecked ? 5f : 0.69f);
			Offsets.HatchingSpeedDivisionRate1 = (float)(isChecked ? 99999 : 12);
			Offsets.PalRarity2 = (isChecked ? 99 : 4);
			Offsets.EggScale2 = (isChecked ? 5f : 0.89f);
			Offsets.HatchingSpeedDivisionRate2 = (float)(isChecked ? 99999 : 12);
			Offsets.PalRarity3 = (isChecked ? 99 : 6);
			Offsets.EggScale3 = (isChecked ? 5f : 1.1f);
			Offsets.HatchingSpeedDivisionRate3 = (float)(isChecked ? 99999 : 2);
			Offsets.PalRarity4 = (isChecked ? 99 : 7);
			Offsets.EggScale4 = (isChecked ? 5f : 1.5f);
			Offsets.HatchingSpeedDivisionRate4 = (float)(isChecked ? 99999 : 2);
			Offsets.PalRarity5 = (isChecked ? 99 : 99);
			Offsets.EggScale5 = (isChecked ? 5f : 1.5f);
			Offsets.HatchingSpeedDivisionRate5 = (float)(isChecked ? 99999 : 2);
			Offsets.PalEggTempHatchRate1 = (isChecked ? 99999f : 0.75f);
			Offsets.PalEggTempHatchRate2 = (isChecked ? 99999f : 0.75f);
			Offsets.PalEggTempHatchRate3 = (isChecked ? 99999f : 0.75f);
			Offsets.PalEggTempHatchRate4 = (isChecked ? 99999f : 0.75f);
			Offsets.PalEggTempHatchRate5 = (isChecked ? 99999f : 0.75f);
			Offsets.PalEggTempHatchRate6 = (float)(isChecked ? 99999 : 1);
			Offsets.PalEggTempHatchRate7 = (float)(isChecked ? 99999 : 1);
			Offsets.PalEggTempHatchRate8 = (isChecked ? 99999f : 1.5f);
			Offsets.PalEggTempHatchRate9 = (float)(isChecked ? 99999 : 2);
		}

		// Token: 0x04000178 RID: 376
		private static byte? originalReplicateMovementValue;

		// Token: 0x04000179 RID: 377
		private static float originalNowItemWeightValue;

		// Token: 0x0400017A RID: 378
		private static float originalMaxInventoryWeightValue;
	}
}
