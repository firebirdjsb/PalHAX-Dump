﻿using System;

namespace PalHaxv1_1
{
	// Token: 0x02000013 RID: 19
	internal static class PropertyAccessors
	{
		// Token: 0x06000259 RID: 601 RVA: 0x0001033F File Offset: 0x0000E53F
		public static float ReadFloatProperty(string baseAddress, string offset)
		{
			return Signatures.MemLib.ReadFloat(baseAddress + "+" + offset, "", true);
		}

		// Token: 0x0600025A RID: 602 RVA: 0x0001035D File Offset: 0x0000E55D
		public static void WriteFloatProperty(string baseAddress, string offset, float value)
		{
			Signatures.MemLib.WriteMemory(baseAddress + "+" + offset, "float", value.ToString(), "", null, true);
		}

		// Token: 0x0600025B RID: 603 RVA: 0x00010389 File Offset: 0x0000E589
		public static int ReadIntProperty(string baseAddress, string offset)
		{
			return Signatures.MemLib.ReadInt(baseAddress + "+" + offset, "");
		}

		// Token: 0x0600025C RID: 604 RVA: 0x000103A6 File Offset: 0x0000E5A6
		public static void WriteIntProperty(string baseAddress, string offset, int value)
		{
			Signatures.MemLib.WriteMemory(baseAddress + "+" + offset, "int", value.ToString(), "", null, true);
		}

		// Token: 0x0600025D RID: 605 RVA: 0x000103D2 File Offset: 0x0000E5D2
		public static byte ReadByteProperty(string baseAddress, string offset)
		{
			return (byte)Signatures.MemLib.ReadByte(baseAddress + "+" + offset, "");
		}

		// Token: 0x0600025E RID: 606 RVA: 0x000103F0 File Offset: 0x0000E5F0
		public static void WriteByteProperty(string baseAddress, string offset, byte value)
		{
			string write = value.ToString("X2");
			Signatures.MemLib.WriteMemory(baseAddress + "+" + offset, "byte", write, "", null, true);
		}

		// Token: 0x0600025F RID: 607 RVA: 0x0001042E File Offset: 0x0000E62E
		public static uint ReadUIntProperty(string baseAddress, string offset)
		{
			return Signatures.MemLib.ReadUInt(baseAddress + "+" + offset, "");
		}

		// Token: 0x06000260 RID: 608 RVA: 0x0001044C File Offset: 0x0000E64C
		public static void WriteUIntProperty(string baseAddress, string offset, uint value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			Signatures.MemLib.WriteBytes(baseAddress + "+" + offset, bytes, "");
		}

		// Token: 0x06000261 RID: 609 RVA: 0x0001047C File Offset: 0x0000E67C
		public static double ReadDoubleProperty(string baseAddress, string offset)
		{
			return Signatures.MemLib.ReadDouble(baseAddress + "+" + offset, "", true);
		}

		// Token: 0x06000262 RID: 610 RVA: 0x0001049A File Offset: 0x0000E69A
		public static void WriteDoubleProperty(string baseAddress, string offset, double value)
		{
			Signatures.MemLib.WriteDouble(baseAddress + "+" + offset, value, "");
		}
	}
}
