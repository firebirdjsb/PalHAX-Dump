﻿using System;

namespace PalHaxv1_1
{
	// Token: 0x0200000B RID: 11
	internal static class Bools
	{
		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x0600020F RID: 527 RVA: 0x0000E781 File Offset: 0x0000C981
		// (set) Token: 0x06000210 RID: 528 RVA: 0x0000E788 File Offset: 0x0000C988
		public static bool IsProcessOpen { get; set; }

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x06000211 RID: 529 RVA: 0x0000E790 File Offset: 0x0000C990
		// (set) Token: 0x06000212 RID: 530 RVA: 0x0000E797 File Offset: 0x0000C997
		public static bool addressesScanned { get; set; }

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x06000213 RID: 531 RVA: 0x0000E79F File Offset: 0x0000C99F
		// (set) Token: 0x06000214 RID: 532 RVA: 0x0000E7A6 File Offset: 0x0000C9A6
		public static bool isDragging { get; set; }

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x06000215 RID: 533 RVA: 0x0000E7AE File Offset: 0x0000C9AE
		// (set) Token: 0x06000216 RID: 534 RVA: 0x0000E7B5 File Offset: 0x0000C9B5
		public static bool originalValuesStored { get; set; }
	}
}
