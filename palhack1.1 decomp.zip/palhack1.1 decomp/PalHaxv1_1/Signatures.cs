﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace PalHaxv1_1
{
	// Token: 0x0200000A RID: 10
	internal class Signatures
	{
		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x06000207 RID: 519 RVA: 0x0000E6C2 File Offset: 0x0000C8C2
		// (set) Token: 0x06000208 RID: 520 RVA: 0x0000E6C9 File Offset: 0x0000C8C9
		public static string UWorld_BaseAddress { get; private set; }

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x06000209 RID: 521 RVA: 0x0000E6D1 File Offset: 0x0000C8D1
		// (set) Token: 0x0600020A RID: 522 RVA: 0x0000E6D8 File Offset: 0x0000C8D8
		public static string UWorld_AssemblyAddress { get; private set; }

		// Token: 0x0600020B RID: 523 RVA: 0x0000E6E0 File Offset: 0x0000C8E0
		public static Task ConnectToWorldAsync()
		{
			Signatures.<ConnectToWorldAsync>d__10 <ConnectToWorldAsync>d__;
			<ConnectToWorldAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ConnectToWorldAsync>d__.<>1__state = -1;
			<ConnectToWorldAsync>d__.<>t__builder.Start<Signatures.<ConnectToWorldAsync>d__10>(ref <ConnectToWorldAsync>d__);
			return <ConnectToWorldAsync>d__.<>t__builder.Task;
		}

		// Token: 0x0600020C RID: 524 RVA: 0x0000E71C File Offset: 0x0000C91C
		private static Task UpdateMemoryAddressesAsync(string name, string pattern)
		{
			Signatures.<UpdateMemoryAddressesAsync>d__11 <UpdateMemoryAddressesAsync>d__;
			<UpdateMemoryAddressesAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<UpdateMemoryAddressesAsync>d__.name = name;
			<UpdateMemoryAddressesAsync>d__.pattern = pattern;
			<UpdateMemoryAddressesAsync>d__.<>1__state = -1;
			<UpdateMemoryAddressesAsync>d__.<>t__builder.Start<Signatures.<UpdateMemoryAddressesAsync>d__11>(ref <UpdateMemoryAddressesAsync>d__);
			return <UpdateMemoryAddressesAsync>d__.<>t__builder.Task;
		}

		// Token: 0x04000170 RID: 368
		public static Process CURRENTGAME_PROCESS = null;

		// Token: 0x04000171 RID: 369
		public static Mem MemLib = new Mem();
	}
}
