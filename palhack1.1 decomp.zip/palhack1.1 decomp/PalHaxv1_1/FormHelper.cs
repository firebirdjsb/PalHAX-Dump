﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Windows.Forms;

namespace PalHaxv1_1
{
	// Token: 0x0200000E RID: 14
	public static class FormHelper
	{
		// Token: 0x06000234 RID: 564 RVA: 0x0000FF48 File Offset: 0x0000E148
		public static void SetRoundedFormAppearance(Form form, int cornerRadius)
		{
			form.FormBorderStyle = FormBorderStyle.None;
			form.TopMost = true;
			FormHelper.SetDoubleBuffered(form);
			form.Paint += delegate(object sender, PaintEventArgs e)
			{
				FormHelper.DrawRoundedBorder(sender as Form, e.Graphics, cornerRadius);
			};
		}

		// Token: 0x06000235 RID: 565 RVA: 0x0000FF88 File Offset: 0x0000E188
		private static void SetDoubleBuffered(Form form)
		{
			typeof(Form).InvokeMember("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.SetProperty, null, form, new object[]
			{
				true
			});
		}

		// Token: 0x06000236 RID: 566 RVA: 0x0000FFC0 File Offset: 0x0000E1C0
		private static void DrawRoundedBorder(Form form, Graphics graphics, int cornerRadius)
		{
			using (Pen pen = new Pen(Color.Cyan, 3f))
			{
				graphics.DrawPath(pen, FormHelper.CreateRoundedRectanglePath(form.ClientRectangle, cornerRadius));
			}
			using (GraphicsPath graphicsPath = FormHelper.CreateRoundedRectanglePath(form.ClientRectangle, cornerRadius))
			{
				form.Region = new Region(graphicsPath);
			}
		}

		// Token: 0x06000237 RID: 567 RVA: 0x00010040 File Offset: 0x0000E240
		private static GraphicsPath CreateRoundedRectanglePath(Rectangle rectangle, int cornerRadius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			int num = cornerRadius * 2;
			int num2 = cornerRadius * 2;
			graphicsPath.AddArc(new Rectangle(rectangle.X, rectangle.Y, num, num2), 180f, 90f);
			graphicsPath.AddArc(new Rectangle(rectangle.Right - num - 1, rectangle.Y, num, num2), 270f, 90f);
			graphicsPath.AddArc(new Rectangle(rectangle.Right - num - 1, rectangle.Bottom - num2 - 1, num, num2), 0f, 90f);
			graphicsPath.AddArc(new Rectangle(rectangle.X, rectangle.Bottom - num2 - 1, num, num2), 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}
	}
}
